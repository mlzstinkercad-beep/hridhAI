"""Triple-tap distress pattern state machine.

Consumes verified structural-tap ImpactEvents, groups them into bursts,
and fires a DistressAlert when >=3 verified taps land inside the
pattern window. Includes inter-tap cadence analysis (min/mean/gap CV)
so briefings can report the rhythm - an involuntary tapping casualty
tends to have a high gap coefficient of variation, a deliberate SOS
signaller a low one.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field

import numpy as np

from .config import (PATTERN_TRIPLE, TAP_WINDOW_S, PATTERN_QUADRUPLE,
                     PATTERN_RESET_S)
from .classifier import ImpactEvent


@dataclass
class DistressAlert:
    t_trigger: float
    n_taps: int
    avg_conf: float
    min_conf: float
    cadence_s: tuple                    # (min, mean, cv) inter-tap gaps
    tap_times: list = field(default_factory=list)


class PatternEngine:
    def __init__(self, window_s=TAP_WINDOW_S, need=PATTERN_TRIPLE,
                 cooldown_s=PATTERN_RESET_S):
        self.window_s = window_s
        self.need = need
        self.cooldown_s = cooldown_s
        self.taps: list[ImpactEvent] = []
        self.last_alert_t = -1e9
        self.total_taps = 0
        self.total_alerts = 0

    def register_tap(self, ev: ImpactEvent) -> DistressAlert | None:
        self.total_taps += 1
        now = ev.t_mono
        # drop taps outside window
        self.taps = [t for t in self.taps if (now - t.t_mono) <= self.window_s]
        self.taps.append(ev)
        if len(self.taps) < self.need:
            return None
        if (now - self.last_alert_t) < self.cooldown_s:
            return None
        gaps = np.diff([t.t_mono for t in self.taps])
        confs = [t.confidence for t in self.taps]
        alert = DistressAlert(
            t_trigger=now,
            n_taps=len(self.taps),
            avg_conf=float(np.mean(confs)),
            min_conf=float(np.min(confs)),
            cadence_s=(float(np.min(gaps)), float(np.mean(gaps)),
                       float(np.std(gaps) / np.mean(gaps))) if len(gaps) else (0, 0, 0),
            tap_times=[t.t_mono for t in self.taps],
        )
        self.total_alerts += 1
        self.last_alert_t = now
        self.taps = []                   # re-arm clean
        return alert

    @property
    def escalation_level(self) -> int:
        """0 none | 1 triple | 2 quadruple+ (priority escalation)."""
        if not self.total_alerts:
            return 0
        return 2 if self.total_alerts >= PATTERN_QUADRUPLE else 1

    def snapshot(self) -> dict:
        # stream time of the newest tap (or 0 when idle)
        now = self.taps[-1].t_mono if self.taps else 0.0
        n_active = sum(1 for t in self.taps if (now - t.t_mono) <= self.window_s)
        return {"taps_in_window": n_active, "need": self.need,
                "window_s": self.window_s,
                "total_taps": self.total_taps, "total_alerts": self.total_alerts}
