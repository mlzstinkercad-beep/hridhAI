"""Physics-modelled synthetic corpus generator for ECHO-AI (v3: voice-aware).

Generates labeled training audio simulating a post-collapse environment:

POSITIVES  "structural_tap"
    A knuckle/heavy-object strike transmitted through concrete+rebar.
    Model: modal resonances of a damped plate (3-6 modes, 120-2400 Hz,
    Q 8-25) * exponentially decaying excitation, followed by a
    reverberant tail (stochastic late reverb, RT60 0.3-1.2 s) plus
    rain/urban ambient bed. Taps are placed in bursts of 2-5 with
    realistic inter-tap jitter (0.3-0.9 s, log-normal) to mirror the
    triple-tap SOS pattern.
    v3: a fraction of positives ALSO carries a distant human-voice bed
    (shouting/babble) so the model learns "taps survive shouting" —
    the classifier must find the strike, not merely "quiet clip".

NEGATIVES  a mix of three regimes
    - "ambient_noise"   rain, wind, distant machinery, room tone
                        (filtered noise beds with slow modulation)
    - "surface_clatter" light surface impacts NOT transmitted through
                        structure: shorter decay, higher centroid
    - "human_voice"     v3: shouting / talking / crowd babble WITHOUT
                        structural taps. Pitch-synchronised harmonic
                        stacks (f0 95-300 Hz) with formant emphasis,
                        f0 jitter, syllable envelopes, 1-4 talkers.

Every clip is peak-normalised then given a random gain so the classifier
cannot cheat on absolute level. 0.4 s per clip @ 44.1 kHz.
"""
from __future__ import annotations

import numpy as np

from .config import SAMPLE_RATE, CORPUS_SECONDS_PER_EXAMPLE, CORPUS_TAPS_PER_POSITIVE

# fraction of positive clips that additionally carry a voice bed
VOICE_IN_POSITIVE_P = 0.35


def _rng(seed):
    return np.random.default_rng(seed)


def _ambient(rng, n, kind="urban"):
    """Slow-modulated ambient noise bed."""
    t = np.arange(n) / SAMPLE_RATE
    # coloured noise: 1/f^alpha shape via FFT
    spec = (rng.standard_normal(n // 2 + 1) + 1j * rng.standard_normal(n // 2 + 1))
    f = np.fft.rfftfreq(n, 1.0 / SAMPLE_RATE)
    alpha = {"urban": 1.0, "rain": 0.7, "wind": 1.4, "machinery": 0.5}[kind]
    spec = spec / ((f + 30.0) ** (alpha / 2))
    bed = np.fft.irfft(spec, n) * 8.0
    # slow amplitude modulation (gusts / passing sources)
    lfo = 0.5 + 0.5 * np.sin(2 * np.pi * rng.uniform(0.1, 0.8) * t + rng.uniform(0, 6.28))
    bed = bed * lfo
    if kind == "machinery":  # add harmonic drone
        f0 = rng.uniform(45, 110)
        bed += 0.4 * np.sin(2 * np.pi * f0 * t) + 0.15 * np.sin(2 * np.pi * 2 * f0 * t)
    return bed / (np.max(np.abs(bed)) + 1e-9)


def _voice_segment(rng, dur_s, n_voices=1, shout=False):
    """Pitch-synchronised harmonic voice synthesis (talker / shouter).

    Per voice: fundamental f0 with vibrato + drift (shouters pitch up),
    harmonics k*f0 with 1/k amplitudes shaped by 3 formant resonances,
    syllabic amplitude envelope (2-5 Hz). Shouting raises intensity,
    adds brightness and tightens harmonics; babble overlaps talkers.
    """
    n = int(dur_s * SAMPLE_RATE)
    t = np.arange(n) / SAMPLE_RATE
    out = np.zeros(n)
    for v in range(n_voices):
        f0 = rng.uniform(95, 180) if not shout else rng.uniform(140, 300)
        drift = np.cumsum(rng.standard_normal(n)) * 0.8
        vib = 0.03 * np.sin(2 * np.pi * rng.uniform(4, 7) * t)
        f0_t = f0 * (1 + vib + np.clip(drift, -0.25, 0.35) / max(f0, 1))
        # syllable envelope: 2-5 pseudo-random on/off bursts per second
        syl_rate = rng.uniform(2.2, 5.0)
        syl_phase = rng.random(n)
        env = (np.sin(2 * np.pi * syl_rate * t + rng.uniform(0, 6)) >
               rng.uniform(-0.6, 0.1)).astype(np.float64)
        env = env * (0.6 + 0.4 * np.sin(2 * np.pi * syl_rate * 2 * t))
        phase = 2 * np.pi * np.cumsum(f0_t) / SAMPLE_RATE
        voice = np.zeros(n)
        n_harm = int(min(24, (6000.0 / f0)))
        formants = sorted(rng.uniform(400, 3200, size=3))
        for k in range(1, n_harm + 1):
            fk = f0_t * k
            amp = 1.0 / (k ** (0.8 if shout else 1.1))
            # formant emphasis: boost harmonics near the 3 formants
            for fm in formants:
                amp *= 1.0 + 2.2 * np.exp(-((fk - fm) / 300.0) ** 2)
            voice += amp * np.sin(k * phase + rng.uniform(0, 6.28))
        # breath noise between harmonics (more when not shouting)
        voice += 0.05 * rng.standard_normal(n) * (1.0 if not shout else 0.4)
        out += voice * env
    out = out / (np.max(np.abs(out)) + 1e-9)
    return out


def _modal_strike(rng, decay_modes=None):
    """One strike on a damped concrete/plate structure -> waveform.

    Spectral shape calibrated to real ESC-50 door-knock measurements
    (centroid ~1.4 kHz, flatness ~0.08): two dominant ringing low modes
    (90-220 Hz, Q 15-40) carry most energy, mid bending modes are -10 dB,
    high partials negligible, attack click very quiet.
    """
    n_modes = rng.integers(4, 8)
    freqs = np.concatenate([
        rng.uniform(90, 220, size=2),                   # dominant ringing modes
        rng.uniform(300, 1000, size=n_modes - 3),       # plate bending modes
        rng.uniform(1200, 2600, size=1),                # weak metallic partial
    ])
    qs = np.concatenate([rng.uniform(15, 40, size=2),   # long ring on lows
                          rng.uniform(8, 20, size=n_modes - 2)])
    amps = np.concatenate([
        rng.uniform(0.8, 1.0, size=2),                 # lows dominate
        rng.uniform(0.2, 0.45, size=n_modes - 3),      # mids -10 dB
        [rng.uniform(0.04, 0.10)],                     # highs faint
    ])
    dur = 0.12 + 0.10 * rng.random()
    n = int(dur * SAMPLE_RATE)
    t = np.arange(n) / SAMPLE_RATE
    strike = np.zeros(n)
    for f0, q, a in zip(freqs, qs, amps):
        w = 2 * np.pi * f0
        strike += a * np.exp(-w * t / (2 * q)) * np.sin(w * t + rng.uniform(0, 6.28))
    # attack transient: very quiet 0.5 ms click
    click_n = int(0.0005 * SAMPLE_RATE)
    strike[:click_n] += 0.06 * rng.standard_normal(click_n)
    return strike


def _reverb_tail(rng, x, rt60):
    """Lowpassed stochastic reverb tail: keeps modal colour, no HF smear
    (real structure-transmitted taps have almost no >3 kHz energy)."""
    from scipy.signal import butter, lfilter
    n_ir = int(rt60 * SAMPLE_RATE)
    ir = rng.standard_normal(n_ir) * np.exp(-3.5 * np.arange(n_ir) / n_ir)
    ir[:: int(0.004 * SAMPLE_RATE)] *= 0.2               # sparse early reflections
    y = np.convolve(x, ir)[: len(x) + n_ir]
    y = y / (np.max(np.abs(y)) + 1e-9)
    b, a = butter(4, 1200.0 / (SAMPLE_RATE / 2), "low")
    return lfilter(b, a, y)


def _light_clatter(rng):
    """Surface impact (glass/plastic/debris) - NOT through structure:
    shorter, brighter, fewer low modes."""
    n_modes = rng.integers(2, 5)
    freqs = np.concatenate([rng.uniform(800, 1600, size=1),
                            rng.uniform(2000, 5500, size=n_modes - 1)])
    dur = 0.02 + 0.05 * rng.random()
    n = int(dur * SAMPLE_RATE)
    t = np.arange(n) / SAMPLE_RATE
    out = np.zeros(n)
    for f0 in freqs:
        q = rng.uniform(4, 14)
        out += rng.uniform(0.4, 1) * np.exp(-2 * np.pi * f0 * t / q) * np.sin(2 * np.pi * f0 * t)
    out[: int(0.0005 * SAMPLE_RATE)] += 0.4 * rng.standard_normal(int(0.0005 * SAMPLE_RATE))
    return out


def _place(dest, sig, pos):
    n = len(sig)
    i0 = int(pos * SAMPLE_RATE)
    i1 = min(i0 + n, len(dest))
    if i1 > i0:
        dest[i0:i1] += sig[: i1 - i0]


def make_structural_tap_clip(rng, n_taps=CORPUS_TAPS_PER_POSITIVE, with_voice=None):
    n = int(CORPUS_SECONDS_PER_EXAMPLE * SAMPLE_RATE)
    # bed well below strike energy: rms ratio ~1:8 (post-collapse room tone)
    clip = _ambient(rng, n, kind=rng.choice(["urban", "rain", "wind", "machinery"])) * rng.uniform(0.01, 0.05)
    # optional distant human bed: shouting/babble WITHOUT swamping the taps
    if with_voice is None:
        with_voice = rng.random() < VOICE_IN_POSITIVE_P
    if with_voice:
        n_voices = int(rng.integers(1, 4))
        voice = _voice_segment(rng, CORPUS_SECONDS_PER_EXAMPLE,
                               n_voices=n_voices, shout=rng.random() < 0.5)
        clip = clip + voice * rng.uniform(0.10, 0.30)     # bed-level voice
    # taps in a burst with realistic SOS cadence (gaps 0.3-0.7 s)
    n_taps = min(n_taps, 5)
    lead_in = rng.uniform(0.05, 0.2)
    positions, pos = [], lead_in
    for k in range(n_taps):
        positions.append(pos)
        pos += rng.uniform(0.30, 0.70) * np.exp(rng.normal(0, 0.12))
    # clamp: keep every tap inside the clip with room for its tail
    span = CORPUS_SECONDS_PER_EXAMPLE - 0.15
    scale = 1.0 if positions[-1] <= span else span / positions[-1]
    positions = [p * scale for p in positions]
    for p in positions:
        strike = _modal_strike(rng) * rng.uniform(0.6, 1.0)
        strike = _reverb_tail(rng, strike, rt60=rng.uniform(0.3, 1.2)) * rng.uniform(0.10, 0.20)
        _place(clip, strike, p)
    # peak-normalise the finished mix (docstring contract), then randomise
    # overall gain so the classifier cannot cheat on absolute level.
    clip = clip / max(np.max(np.abs(clip)), 1e-9)
    clip = clip * rng.uniform(0.5, 1.0)
    return clip, positions


def make_negative_clip(rng, kind=None):
    n = int(CORPUS_SECONDS_PER_EXAMPLE * SAMPLE_RATE)
    if kind is None:
        r = rng.random()
        kind = "ambient_noise" if r < 0.40 else ("surface_clatter" if r < 0.72 else "human_voice")
    if kind == "ambient_noise":      # pure ambient bed, sometimes stronger
        clip = _ambient(rng, n, kind=rng.choice(["urban", "rain", "wind", "machinery"])) * rng.uniform(0.2, 1.0)
        label = "ambient_noise"
    elif kind == "human_voice":      # dominant voice: talking / shouting / babble
        bed = _ambient(rng, n, kind=rng.choice(["urban", "rain", "wind"])) * rng.uniform(0.03, 0.12)
        n_voices = int(rng.integers(1, 5))
        shout = rng.random() < 0.5
        voice = _voice_segment(rng, CORPUS_SECONDS_PER_EXAMPLE,
                               n_voices=n_voices, shout=shout)
        clip = bed + voice * rng.uniform(0.5, 1.0)
        label = "human_voice"
    else:                            # surface clatter bursts
        clip = _ambient(rng, n, kind=rng.choice(["urban", "rain", "wind"])) * rng.uniform(0.05, 0.3)
        for _ in range(rng.integers(1, 5)):
            p = rng.uniform(0.05, 0.9)
            _place(clip, _light_clatter(rng) * rng.uniform(0.5, 1.0), p)
        label = "surface_clatter"
    return clip, label


def generate_corpus(n_per_class=400, seed=7):
    """Yield (audio, label, extra) tuples. Positives may carry voice beds;
    voice negatives come in three regimes (ambient / clatter / voice)."""
    rng = _rng(seed)
    for i in range(n_per_class):
        clip, positions = make_structural_tap_clip(rng)
        yield clip, "structural_tap", {"tap_positions": positions, "idx": i}
    for i in range(n_per_class):
        clip, label = make_negative_clip(rng)
        yield clip, label, {"idx": i}
