"""DSP feature engine for ECHO-AI (v3: 18-dimensional, voice-aware).

Extracts an 18-dimensional acoustic feature vector per analysis frame:
  0-9   MFCC[1..10]            mel-frequency cepstral coefficients
  10    delta-MFCC[1]           short-time cepstral velocity
  11    log spectral centroid   "brightness" (kHz, log scale)
  12    log spectral flatness   Wiener entropy: 0 = tonal, 1 = noise
  13    log zero-crossing rate  sign-change density
  14    log band ratio          2-8 kHz energy / 0.1-1.2 kHz energy
  15    onset density           frame-to-frame energy rise count
  16    log harmonicity         harmonic energy / total energy in
                               80-3000 Hz (voice is ~0.3-0.7; a plate
                               tap is 0.15-0.35; noise < 0.15)
  17    log spectral rolloff    85% energy percentile frequency / 4 kHz

Harmonicity (harmonic-to-total ratio, HTR) and rolloff give the ensemble
dedicated axes to separate voiced shouting (harmonic, 100-400 Hz energy
concentrated, moderate rolloff) from structural taps (few discrete ringing
modes: partial harmonicity, low rolloff) and broadband noise (no harmonic
structure, high rolloff). All features are log/percentile-scaled so a
single ensemble model can weight them uniformly. The extractor is
stateless per clip (the delta term uses an internal first-frame zero
baseline).

VERSION NOTE: the vector layout changed at v3 (16 -> 18). Any model file
trained on v2 must be retrained; the classifier checks the dimension and
refuses stale models (see classifier.py).
"""
from __future__ import annotations

import numpy as np

from .config import SAMPLE_RATE, FFT_SIZE, HOP_SIZE, PRE_EMPHASIS

# ---------------------------------------------------------------- mel ------
_MEL_FMIN, _MEL_FMAX = 40.0, float(SAMPLE_RATE / 2)
_MEL_BINS = 26


def _hz_to_mel(f):
    return 2595.0 * np.log10(1.0 + f / 700.0)


def _mel_to_hz(m):
    return 700.0 * (10.0 ** (m / 2595.0) - 1.0)


def _mel_filter_bank(sr: int, n_fft: int, n_mels: int = _MEL_BINS):
    """Triangular filterbank, cached per (sr, n_fft)."""
    key = (sr, n_fft)
    cached = _MEL_FILTER_CACHE.get(key)
    if cached is not None:
        return cached
    mels = np.linspace(_hz_to_mel(_MEL_FMIN), _hz_to_mel(_MEL_FMAX), n_mels + 2)
    hz = _mel_to_hz(mels)
    freqs = np.fft.rfftfreq(n_fft, 1.0 / sr)
    fbank = np.zeros((n_mels, len(freqs)))
    for m in range(1, n_mels + 1):
        lo, cen, hi = hz[m - 1], hz[m], hz[m + 1]
        up = (freqs - lo) / max(cen - lo, 1e-9)
        dn = (hi - freqs) / max(hi - cen, 1e-9)
        fbank[m - 1] = np.maximum(0.0, np.minimum(up, dn))
    filt = fbank[:, (freqs > 0)]
    # normalise each filter to unit energy (slaney norm)
    filt = filt / np.maximum(filt.sum(axis=1, keepdims=True), 1e-9)
    _MEL_FILTER_CACHE[key] = filt
    return filt


_MEL_FILTER_CACHE: dict = {}
# rfftfreq bins without DC:
_FREQS_NO_DC = np.fft.rfftfreq(FFT_SIZE, 1.0 / SAMPLE_RATE)[1:]
# sub-band masks for harmonicity (voice fundamental region and its multiples)
_HARM_FMIN, _HARM_FMAX = 80.0, 3000.0


def _harmonicity(spec: np.ndarray, freqs: np.ndarray) -> float:
    """Harmonic-to-total energy ratio inside 80-3000 Hz.

    A cheap HTR proxy: spectral peak picking with local prominence, then
    energy at harmonically-related bins vs total. Voiced speech has strong
    pitch-synchronized peaks (HTR 0.3-0.7); a plate strike has a few
    inharmonic ringing modes (0.15-0.35); noise ~<0.15.
    """
    band = (freqs >= _HARM_FMIN) & (freqs >= 0) & (freqs <= _HARM_FMAX)
    sel = np.where(band)[0]
    if sel.size < 8:
        return 0.0
    s = spec[sel]
    if float(np.sum(s)) < 1e-10:
        return 0.0
    thr = float(np.max(s)) * 0.05            # 5% of in-band peak
    peaks = []
    for k in range(1, len(s) - 1):
        if s[k] > s[k - 1] and s[k] >= s[k + 1] and s[k] > thr:
            peaks.append(k)
    if len(peaks) < 2:
        return 0.0
    peak_e = float(np.sum(s[peaks] ** 2))
    total_e = float(np.sum(s ** 2))
    htr = peak_e / max(total_e, 1e-12)
    # f0 estimate: strongest in-band peak below 500 Hz (voice territory)
    low = [k for k in peaks if freqs[sel[k]] < 500.0]
    if low:
        f0 = float(freqs[sel[int(np.argmax(s[low]))]])
    else:
        f0 = float(freqs[sel[peaks[int(np.argmax(s[peaks]))]]])
    # harmonically related peak pairs -> boost
    if f0 > 60.0:
        ratios = [freqs[sel[k]] / f0 for k in peaks]
        n_harm = sum(1 for r in ratios if r > 1.15 and abs(r - round(r)) < 0.22)
        htr = min(1.0, htr + 0.12 * n_harm)
    return float(min(htr, 1.0))


def _rolloff85(spec: np.ndarray) -> float:
    """Frequency below which 85% of spectral energy lives (Hz)."""
    p = spec ** 2
    total = float(np.sum(p))
    if total < 1e-12:
        return 0.0
    c = np.cumsum(p) / total
    idx = int(np.searchsorted(c, 0.85))
    return float(_FREQS_NO_DC[min(idx, len(_FREQS_NO_DC) - 1)])


def _frame_mfcc(frame: np.ndarray):
    """MFCCs of one (pre-emphasised) frame. Drops c0 (loudness)."""
    spec = np.abs(np.fft.rfft(frame * np.hanning(len(frame))))[1:]
    power = spec ** 2
    melspec = _mel_filter_bank(SAMPLE_RATE, FFT_SIZE) @ power
    logmel = np.log(melspec + 1e-10)
    n_mfcc = 10
    dct_m = np.cos(np.pi / _MEL_BINS * (np.arange(_MEL_BINS)[:, None] + 0.5)
                   * np.arange(1, n_mfcc + 1)[None, :]) * np.sqrt(2.0 / _MEL_BINS)
    return dct_m.T @ logmel


def _frame_shape(frame: np.ndarray):
    """Centroid / flatness / ZCR / band-ratio of one RAW frame."""
    spec = np.abs(np.fft.rfft(frame * np.hanning(len(frame))))[1:]
    power = spec ** 2
    total = np.sum(spec)
    if total <= 1e-10:                       # silent frame: no shape
        return 0.0, 0.0, 0.0, 1.0, 0.0, 0.0
    centroid = float(np.sum(_FREQS_NO_DC * spec) / total)
    arith = float(np.mean(spec))
    geo = float(np.exp(np.mean(np.log(spec + 1e-9))))
    flatness = float(min(geo / max(arith, 1e-12), 1.0))   # GM<=AM, clamp 0..1
    zcr = float(np.mean(np.abs(np.diff(np.signbit(frame)))) / 2.0)
    band_lo = (_FREQS_NO_DC >= 100.0) & (_FREQS_NO_DC <= 1200.0)
    band_hi = (_FREQS_NO_DC <= 8000.0) & (_FREQS_NO_DC >= 2000.0)
    e_lo = float(np.sum(power[band_lo]) + 1e-9)
    e_hi = float(np.sum(power[band_hi]) + 1e-9)
    htr = _harmonicity(spec, _FREQS_NO_DC)
    roll = _rolloff85(spec)
    return centroid, flatness, zcr, e_hi / e_lo, htr, roll


def extract_features(x: np.ndarray, sr: int = SAMPLE_RATE) -> dict:
    """Full clip -> {vector (18,), plus raw telemetry for display}.

    Accepts float or int16 arrays; normalises internally.
    """
    x = np.asarray(x, dtype=np.float32).ravel()
    peak = float(np.max(np.abs(x))) if x.size else 0.0
    if peak > 0:
        x = x / peak  # unit peak scale, keeps features level-independent

    # Two parallel paths:
    #   raw signal  -> centroid / flatness / zcr / band-ratio / onset /
    #                  harmonicity / rolloff (pre-emphasis would tilt these
    #                  +20 dB/decade and swamp low-modal tap physics)
    #   pre-emph    -> MFCCs only (standard cepstral practice)
    x_raw = x
    x = np.append(x[0], x[1:] - PRE_EMPHASIS * x[:-1]).astype(np.float32)

    n_fft = FFT_SIZE
    if len(x_raw) < n_fft:
        x_raw = np.pad(x_raw, (0, n_fft - len(x_raw)))
    if len(x) < n_fft:
        x = np.pad(x, (0, n_fft - len(x)))
    L = max(len(x), len(x_raw))

    mfcc_list, cent, flat, zcrs, ratio, htrs, rolls = [], [], [], [], [], [], []
    frame_eng = []
    for start in range(0, L - n_fft + 1, HOP_SIZE):
        f_pre = x[start:start + n_fft]
        f_raw = x_raw[start:start + n_fft]
        m = _frame_mfcc(f_pre)
        c, f_, z, b, h, r = _frame_shape(f_raw)
        mfcc_list.append(m)
        cent.append(c); flat.append(f_); zcrs.append(z); ratio.append(b)
        htrs.append(h); rolls.append(r)
        frame_eng.append(float(np.sum(f_raw ** 2)))
    M = np.asarray(mfcc_list)                       # (T, 10)
    if M.shape[0] == 0:
        M = np.zeros((1, 10))
    cent_a = np.asarray(cent); flat_a = np.asarray(flat)
    zcr_a = np.asarray(zcrs); ratio_a = np.asarray(ratio)
    htr_a = np.asarray(htrs); roll_a = np.asarray(rolls)

    eng = np.asarray(frame_eng) + 1e-12
    T = len(frame_eng)
    if T != M.shape[0]:          # keep shapes aligned in any fallback
        eng = np.resize(eng, M.shape[0]); T = M.shape[0]

    # ---- energy-weighted aggregate: describe the TRANSIENT, not the bed ----
    w = eng / eng.sum()
    mfcc_agg = (M * w[:, None]).sum(axis=0)
    dmfcc1 = float(np.median(np.diff(M[:, 0])) if M.shape[0] > 1 else 0.0)
    cent_v = float((cent_a * w).sum())
    flat_v = float((flat_a * w).sum())
    zcr_v = float((zcr_a * w).sum())
    ratio_v = float((ratio_a * w).sum())
    htr_v = float((htr_a * w).sum())
    roll_v = float((roll_a * w).sum())
    # onset density: fraction of frames whose energy jumps > 6 dB vs previous
    if T > 1:
        onset_density = float(np.mean(np.diff(eng) > 4.0 * eng[:-1]))
    else:
        onset_density = 0.0

    vector = np.array([
        *mfcc_agg,
        dmfcc1,
        np.log10(max(cent_v, 1.0)),
        np.log10(max(flat_v, 1e-4)),
        np.log10(max(zcr_v, 1e-4)),
        np.log10(max(ratio_v, 1e-3)),
        onset_density,
        np.log10(max(htr_v, 1e-3)),
        np.log10(max(roll_v, 10.0)) / np.log10(4000.0),
    ], dtype=np.float32)

    telemetry = {
        "centroid_hz": cent_v, "flatness": flat_v, "zcr": zcr_v,
        "band_ratio": ratio_v, "onset_density": onset_density,
        "harmonicity": htr_v, "rolloff_hz": roll_v,
        "peak": peak, "mfcc1": float(mfcc_agg[0]),
    }
    return {"vector": vector, "telemetry": telemetry}


# keep import-time symbol used above honest
_ = _hz_to_mel, _mel_to_hz
