"""Real-time signal processor: gate -> features -> classify -> pattern.

v3: sub-threshold chunks feed the BEC condensate tracker (ambient
population statistics); classified transients are cross-checked against
the condensate so periodic machinery firing the trigger gets vetoed
("that's the generator, not a survivor"). Human-heavy-tailed ambience
disables the veto automatically - shouting never masks real taps.
"""
from __future__ import annotations

import time
from collections import deque

import numpy as np

from .bec import CondensateTracker
from .classifier import AcousticClassifier, ImpactEvent
from .config import (AI_CONF_MIN, BEC_VETO_WEIGHT, CHUNK_SECONDS,
                     MIN_INTER_TAP_GAP_S, SAMPLE_RATE, TRIGGER_RATIO)
from .features import extract_features
from .pattern import DistressAlert, PatternEngine


class Frame(dict):
    """Per-chunk result passed to UI (dict with attribute-ish access)."""
    __getattr__ = dict.get


class SignalProcessor:
    def __init__(self, classifier: AcousticClassifier | None = None,
                 pattern: PatternEngine | None = None,
                 threshold_ratio=TRIGGER_RATIO,
                 conf_min=AI_CONF_MIN,
                 bec_enabled=True):
        self.classifier = classifier or AcousticClassifier()
        self.pattern = pattern or PatternEngine()
        self.threshold_ratio = threshold_ratio
        self.conf_min = conf_min
        self.bec = CondensateTracker() if bec_enabled else None
        self.peak = 0.0
        self.last_event: ImpactEvent | None = None
        self.last_ev_t = -1e9
        self.tap_logged = False
        self.frames = 0
        self.wave_hist = deque(maxlen=2048)
        self.conf_hist = deque(maxlen=120)
        self._prev_peak = 0.0
        self._prev_below = True

    # ------------------------------------------------------------- main ---
    def process_chunk(self, chunk: np.ndarray, sr=SAMPLE_RATE) -> Frame:
        self.frames += 1
        # stream time: frame_count * chunk duration. Wall-clock is wrong when
        # chunks arrive faster than real time (tests, file replay bursts).
        t_now = self.frames * CHUNK_SECONDS
        x = np.asarray(chunk).ravel()
        if x.dtype == np.int16:
            peak = float(np.max(np.abs(x))) / 32768.0
        else:
            x32 = x.astype(np.float32)
            peak = float(np.max(np.abs(x32)))
        self.peak = peak

        # light denoise for display + classifier input
        disp = x.astype(np.float32)
        if peak > 0:
            disp = disp / (32768.0 if x.dtype == np.int16 else max(np.max(np.abs(disp)), 1e-9))
        self.wave_hist.extend(disp[-1024:])

        ev: ImpactEvent | None = None
        alert: DistressAlert | None = None
        bec_snap = self.bec.snapshot() if self.bec else None
        if peak >= self.threshold_ratio:
            # v3 gating: absolute trigger + debounce only. The rising-edge
            # heuristic was removed - on a loud bed (shouting/machinery) it
            # eats genuine onsets (the bed raises the local floor), and the
            # classifier already rejects bed chunks by confidence (a
            # sustained shout scores far below AI_CONF_MIN). The 0.12 s
            # debounce keeps decay tails from re-triggering.
            self._prev_peak = peak
            self._prev_below = False
            if (t_now - self.last_ev_t) >= MIN_INTER_TAP_GAP_S:
                ev = self.classifier.classify_chunk(disp if x.dtype != np.int16
                                                    else (x.astype(np.float32) / 32768.0), sr)
                ev.t_mono = t_now                        # stream-time stamp
                # ---- BEC veto: machine condensate swallows periodic hits --
                if self.bec is not None:
                    verdict = self.bec.evaluate_transient(ev.feature_vector)
                    ev.bec_info = verdict
                    if verdict["veto"]:
                        self.bec.vetoes += 1
                        ev.confidence *= (1.0 - BEC_VETO_WEIGHT)
                self.last_ev_t = t_now
                self.last_event = ev
                self.conf_hist.append(ev.confidence)
                if ev.label == "structural_tap" and ev.confidence >= self.conf_min:
                    self.tap_logged = True
                    alert = self.pattern.register_tap(ev)      # may be None
                else:
                    self.tap_logged = False
        else:
            self._prev_peak = peak
            self._prev_below = True
            # ---- quiet chunk: feed the BEC ambient population ----------
            if self.bec is not None:
                self.bec.observe_ambient(extract_features(disp)["vector"])
                bec_snap = self.bec.snapshot()
        return Frame(
            frame=self.frames, peak=peak, event=ev, alert=alert,
            tap_verified=bool(ev is not None and ev.label == "structural_tap"
                              and ev.confidence >= self.conf_min),
            wave=np.asarray(self.wave_hist)[-1024:],
            classification=(ev.label if ev else (self.last_event.label if self.last_event else "IDLE")),
            confidence=(ev.confidence if ev else (self.last_event.confidence if self.last_event else 0.0)),
            telemetry=(ev.telemetry if ev else (self.last_event.telemetry if self.last_event else {})),
            pattern=self.pattern.snapshot(),
            bec=bec_snap,
        )
