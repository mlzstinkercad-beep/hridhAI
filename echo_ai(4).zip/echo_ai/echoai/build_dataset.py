"""Build the feature-matrix training dataset (synthetic + ESC-50 real).

Writes data/dataset.npz  with X (n,18), y (n,), class names, and a
source tag (synthetic / esc50) per row so training reports can break
out real-vs-synthetic accuracy. ESC-50 clips are sliced into 1.6 s
windows; only windows whose peak exceeds the trigger ratio are kept
for impact classes (mirrors runtime gating), ambient/voice rows keep
all windows.

v3 additions:
    - 4th class "human_voice" (shouting/talking/babble negatives).
    - NOISE AUGMENTATION: every synthetic clip may be re-mixed with an
      extra noise bed (urban/rain/wind/machinery/voice-babble) at a
      random SNR, producing extra training rows so the classifier sees
      taps under heavy interference instead of only clean beds.
    - --extra-noise-dir: point it at YOUR OWN room recordings (wav/mp3-
      flac anything soundfile reads) and they get mixed in too - this
      is how you specialise the model to a completely noisy room.
    - --profile quick|full|insane: corpus size presets (see README).

v3.1 PARALLEL BUILD: every clip/window is an independent task farmed
out to worker processes (joblib/loky). Each task draws from its OWN
rng stream derived from (seed, stream_tag, class, clip, variant), so
the resulting dataset is BIT-IDENTICAL for any --n-jobs value and any
task arrival order. Same distributions and augmentation probabilities
as the serial v3 build; only the exact random draws differ (new stream
layout). Groups are one per synthetic source clip / esc50 file, as before.
"""
from __future__ import annotations

import csv
import os
from pathlib import Path

import numpy as np
import soundfile as sf
from joblib import Parallel, delayed

from .config import (DATA_DIR, CORPUS_SECONDS_PER_EXAMPLE, SAMPLE_RATE,
                     TRIGGER_RATIO)
from .features import extract_features
from .synth_corpus import (_ambient, _voice_segment, make_negative_clip,
                           make_structural_tap_clip)

CLASSES = ("structural_tap", "ambient_noise", "surface_clatter", "human_voice")

# profile presets: (synthetic clips per class, augment copies per clip)
PROFILES = {
    "quick": (150, 1),      # minutes, smoke-test grade
    "full": (900, 2),       # the recommended default
    "insane": (3500, 3),    # every last point of accuracy
}


def _esc50_rows(esc_dir: Path):
    man = esc_dir / "manifest.csv"
    if not man.exists():
        return []
    with open(man, newline="") as f:
        return [r for r in csv.DictReader(f)]


def _load_extra_noise(extra_dir: Path | None, rng) -> list:
    """User-supplied room recordings -> list of 1.6 s float slices."""
    clips = []
    if not extra_dir:
        return clips
    for path in sorted(Path(extra_dir).glob("*")):
        if path.suffix.lower() not in (".wav", ".flac", ".ogg", ".mp3", ".aiff", ".aif"):
            continue
        try:
            wav, sr = sf.read(path, dtype="float32", always_2d=False)
        except Exception as e:
            print(f"  [skip] {path.name}: {e}")
            continue
        if wav.ndim > 1:
            wav = wav.mean(axis=1)
        if sr != SAMPLE_RATE:                    # crude but effective resample
            n_out = int(len(wav) * SAMPLE_RATE / sr)
            x = np.interp(np.linspace(0, len(wav) - 1, n_out), np.arange(len(wav)), wav)
            wav = x.astype(np.float32)
        win = int(CORPUS_SECONDS_PER_EXAMPLE * SAMPLE_RATE)
        for i in range(0, max(0, len(wav) - win), win // 2):   # 50% overlap
            seg = wav[i:i + win]
            if len(seg) == win and float(np.max(np.abs(seg))) > 0.01:
                clips.append(seg)
    return clips


def _mix_at_snr(signal: np.ndarray, noise: np.ndarray, snr_db: float) -> np.ndarray:
    """Mix noise into signal at the given SNR (relative to signal RMS)."""
    noise = noise[: len(signal)]
    if len(noise) < len(signal):
        noise = np.pad(noise, (0, len(signal) - len(noise)))
    ps = float(np.sqrt(np.mean(signal ** 2))) + 1e-9
    pn = float(np.sqrt(np.mean(noise ** 2))) + 1e-9
    gain = ps / (pn * (10.0 ** (snr_db / 20.0)))
    return signal + noise * gain


def _augment_variant(clip: np.ndarray, rng, extra_noise) -> np.ndarray | None:
    """One augmented remix of a clip, or None (same probabilities as v3:
    35% ambient bed, 25% voice bed, up to 30% user room noise, rest skip)."""
    r = rng.random()
    if r < 0.35:                       # synthetic bed
        bed = _ambient(rng, len(clip), kind=rng.choice(
            ["urban", "rain", "wind", "machinery"]))
    elif r < 0.60:                     # babble voices
        bed = _voice_segment(rng, len(clip) / SAMPLE_RATE,
                             n_voices=int(rng.integers(1, 4)), shout=rng.random() < 0.4)
    elif extra_noise is not None and r < 0.90:   # user's own room
        bed = extra_noise[int(rng.integers(0, len(extra_noise)))].astype(np.float64)
    else:
        return None
    snr = rng.uniform(2.0, 18.0)       # hard to easy
    return _mix_at_snr(np.asarray(clip, dtype=np.float64), bed, snr)


def _synth_clip_rows(class_id, clip_idx, global_idx, n_aug, seed, extra_noise):
    """Generate one synthetic clip + its augmented variants -> feature rows.

    rng stream (seed, 1, class, clip) for the clip itself and
    (seed, 2, class, clip, variant) per augmentation, so rows never
    depend on execution order or worker count. Returns a list of
    (feature_vector, label, src, group) tuples.
    """
    rng = np.random.default_rng([seed, 1, class_id, clip_idx])
    if class_id == 0:                                    # positives first,
        clip, _positions = make_structural_tap_clip(rng)  # as in generate_corpus
        label = "structural_tap"
    else:
        clip, label = make_negative_clip(rng)
    group = f"synth_{global_idx}"                        # one group per source clip
    rows = [(extract_features(clip)["vector"], label, "synthetic", group)]
    for j in range(n_aug):
        vrng = np.random.default_rng([seed, 2, class_id, clip_idx, j])
        variant = _augment_variant(clip, vrng, extra_noise)
        if variant is not None:
            rows.append((extract_features(variant)["vector"], label,
                         "synthetic", group))
    return rows


def _esc50_file_rows(row, file_idx, esc_dir, n_aug, seed, extra_noise):
    """One ESC-50 file -> gated windows + augmented variants -> rows.
    rng stream (seed, 3, file, window, variant) per augmentation."""
    path = esc_dir / "audio" / row["filename"]
    if not path.exists():
        return []
    wav, sr = sf.read(path, dtype="float32", always_2d=False)
    if wav.ndim > 1:
        wav = wav.mean(axis=1)
    if sr != SAMPLE_RATE:
        n_out = int(len(wav) * SAMPLE_RATE / sr)
        wav = np.interp(np.linspace(0, len(wav) - 1, n_out),
                        np.arange(len(wav)), wav).astype(np.float32)
    win = int(CORPUS_SECONDS_PER_EXAMPLE * SAMPLE_RATE)
    n_win = min(6, max(1, len(wav) // win))
    rows = []
    for i in range(n_win):
        seg = wav[i * win:(i + 1) * win]
        if len(seg) < win:
            seg = np.pad(seg, (0, win - len(seg)))
        peak = float(np.max(np.abs(seg)))
        # keep segments that mirror runtime gating
        if row["our_label"] in ("ambient_noise", "human_voice") or peak > TRIGGER_RATIO * 1.4:
            rows.append((extract_features(seg)["vector"], row["our_label"],
                         "esc50", row["filename"]))
            for j in range(n_aug):
                vrng = np.random.default_rng([seed, 3, file_idx, i, j])
                variant = _augment_variant(seg, vrng, extra_noise)
                if variant is not None:
                    rows.append((extract_features(variant)["vector"],
                                 row["our_label"], "esc50", row["filename"]))
    return rows


def build(out_path: Path | None = None, profile="full", seed=7,
          extra_noise_dir: Path | None = None, verbose=True,
          n_per_class_override: int | None = None, n_jobs: int | None = None):
    if profile not in PROFILES:
        raise ValueError(f"profile must be one of {list(PROFILES)}")
    n_per_class, n_aug = PROFILES[profile]
    if n_per_class_override:                    # --n: custom corpus size, keeps
        n_per_class = int(n_per_class_override)  # the profile's augmentation count
    out_path = out_path or (DATA_DIR / "dataset.npz")
    if n_jobs is None:
        n_jobs = max(1, os.cpu_count() or 1)

    # user room noise: stacked once in the parent; joblib memmaps it to workers
    rng = np.random.default_rng(seed)
    extra_list = _load_extra_noise(extra_noise_dir, rng)
    extra_noise = np.stack(extra_list) if extra_list else None
    if extra_list:
        print(f"extra room-noise slices: {len(extra_list)} (from {extra_noise_dir})")
    if verbose and n_jobs > 1:
        print(f"building on {n_jobs} worker processes "
              "(dataset is identical for any worker count)")

    X, y, src, groups = [], [], [], []

    # ---- synthetic (originals + augmented variants, parallel) -------------
    tasks = [delayed(_synth_clip_rows)(c, i, n_per_class * c + i, n_aug,
                                       seed, extra_noise)
             for c in (0, 1)                       # class 0 taps, class 1 negatives
             for i in range(n_per_class)]
    for rows in Parallel(n_jobs=n_jobs)(tasks):
        for vec, label, s, g in rows:
            X.append(vec)
            y.append(label)
            src.append(s)
            groups.append(g)
    if verbose:
        print(f"synthetic rows: {len(X)} ({2 * n_per_class} clips x {1 + n_aug} max variants)")

    # ---- ESC-50 (gated windows + augmentation, parallel) -------------------
    esc_dir = DATA_DIR / "esc50"
    manifest = _esc50_rows(esc_dir)
    esc_tasks = [delayed(_esc50_file_rows)(row, k, esc_dir, n_aug, seed, extra_noise)
                 for k, row in enumerate(manifest)]
    n_esc = 0
    for rows in Parallel(n_jobs=n_jobs)(esc_tasks):
        for vec, label, s, g in rows:
            X.append(vec)
            y.append(label)
            src.append(s)
            groups.append(g)
        n_esc += len(rows)
    if verbose:
        print(f"esc50 rows: {n_esc} (from {len(manifest)} files)")

    X = np.asarray(X, dtype=np.float32)
    y = np.asarray([CLASSES.index(v) for v in y])
    src = np.asarray(src)
    groups = np.asarray(groups)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(out_path, X=X, y=y, src=src, classes=np.asarray(CLASSES),
                        groups=groups, feature_dim=X.shape[1], profile=profile)
    print(f"dataset -> {out_path}  X{X.shape} classes={CLASSES}")
    return out_path


if __name__ == "__main__":
    build()
