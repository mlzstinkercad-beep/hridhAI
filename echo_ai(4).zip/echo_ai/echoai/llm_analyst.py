"""Hybrid LLM analyst layer (optional, API-key based).

Uses the z.ai GLM endpoint via raw HTTPS when ZAI_API_KEY is set.
The local ensemble remains the source of truth; the LLM only writes
narrative augmentation text for briefings and answers operator
questions in the console. Nothing here can block or override the
deterministic pipeline: every call is timeboxed and falls back
gracefully to a canned line.
"""
from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from pathlib import Path

ENDPOINT = "https://api.z.ai/api/paas/v4/chat/completions"
DEFAULT_MODEL = "glm-4-flash"
TIMEOUT_S = 20


class LLMAnalyst:
    def __init__(self, model: str = DEFAULT_MODEL, api_key: str | None = None,
                 enabled: bool = True):
        self.model = model
        self.api_key = api_key or os.environ.get("ZAI_API_KEY", "")
        self.enabled = enabled and bool(self.api_key)
        self.status = "OFFLINE (no ZAI_API_KEY)" if not self.api_key else "READY"

    # ------------------------------------------------------------- calls ---
    def _chat(self, system: str, user: str, max_tokens: int = 400) -> str | None:
        if not self.enabled:
            return None
        payload = {
            "model": self.model,
            "messages": [{"role": "system", "content": system},
                         {"role": "user", "content": user}],
            "temperature": 0.3, "max_tokens": max_tokens,
        }
        req = urllib.request.Request(
            ENDPOINT,
            data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json",
                     "Authorization": f"Bearer {self.api_key}"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=TIMEOUT_S) as r:
                data = json.loads(r.read().decode())
            return data["choices"][0]["message"]["content"].strip()
        except Exception as e:
            self.status = f"ERROR: {type(e).__name__}"
            return None

    # ----------------------------------------------------------- prompts ----
    def augment_briefing(self, briefing: str, telemetry_summary: dict) -> str | None:
        sys = ("You are the AI analyst embedded in a post-disaster acoustic "
               "detection system. Augment the mission briefing below with 3-4 "
               "additional lines of tactical interpretation: survivor-state "
               "inference from cadence, environmental risk, and probe placement "
               "advice. Terse, professional, no headers, no markdown.")
        user = (f"BRIEFING:\n{briefing}\n\nTELEMETRY: {json.dumps(telemetry_summary)}")
        out = self._chat(sys, user)
        if out is None:
            return ("[LLM OFFLINE] Local augmentation: cadence regularity and "
                    "confidence trend indicate a conscious signaller; maintain "
                    "probe line and confirm with reply protocol.")
        return out

    def console_answer(self, question: str, context_summary: str) -> str | None:
        sys = ("You are the mission-support analyst for an acoustic survivor "
               "detection console. Answer the operator's question using the "
               "provided context. Max 80 words, no markdown.")
        out = self._chat(sys, f"CONTEXT: {context_summary}\nQUESTION: {question}")
        if out is None:
            return "[LLM OFFLINE] answer unavailable - rely on local briefing data."
        return out
