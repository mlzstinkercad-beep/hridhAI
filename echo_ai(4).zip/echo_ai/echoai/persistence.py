"""SQLite persistence for taps and distress alerts.

Zero-dependency event log so post-mission review / evidence chains
survive restarts. Every verified tap and every generated briefing
(alert) is stored with full feature vectors and telemetry.
"""
from __future__ import annotations

import sqlite3
import threading
import time
from pathlib import Path

import numpy as np

from .config import LOG_DIR, DB_NAME
from .pattern import DistressAlert

_SCHEMA = """
CREATE TABLE IF NOT EXISTS taps (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts REAL, confidence REAL, label TEXT,
  centroid REAL, flatness REAL, zcr REAL, band_ratio REAL,
  onset_density REAL, peak REAL, vector BLOB
);
CREATE TABLE IF NOT EXISTS alerts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts REAL, n_taps INTEGER, avg_conf REAL, min_conf REAL,
  gmin REAL, gmean REAL, gap_cv REAL, briefing TEXT
);
"""


class EventStore:
    def __init__(self, db_path: Path | None = None):
        db_path = db_path or (LOG_DIR / DB_NAME)
        db_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._db = sqlite3.connect(db_path, check_same_thread=False)
        self._db.executescript(_SCHEMA)
        self._db.commit()

    def log_tap(self, ev) -> int:
        v = np.asarray(ev.feature_vector, dtype=np.float32).tobytes()
        t = ev.telemetry
        with self._lock:
            cur = self._db.execute(
                "INSERT INTO taps (ts,confidence,label,centroid,flatness,zcr,"
                "band_ratio,onset_density,peak,vector) VALUES (?,?,?,?,?,?,?,?,?,?)",
                (time.time(), ev.confidence, ev.label, t.get("centroid_hz"),
                 t.get("flatness"), t.get("zcr"), t.get("band_ratio"),
                 t.get("onset_density"), t.get("peak"), v))
            self._db.commit()
            return cur.lastrowid

    def log_alert(self, alert: DistressAlert, briefing: str) -> int:
        gmin, gmean, cv = alert.cadence_s
        with self._lock:
            cur = self._db.execute(
                "INSERT INTO alerts (ts,n_taps,avg_conf,min_conf,gmin,gmean,gap_cv,"
                "briefing) VALUES (?,?,?,?,?,?,?,?)",
                (time.time(), alert.n_taps, alert.avg_conf, alert.min_conf,
                 gmin, gmean, cv, briefing))
            self._db.commit()
            return cur.lastrowid

    def counts(self) -> dict:
        with self._lock:
            taps = self._db.execute("SELECT COUNT(*) FROM taps").fetchone()[0]
            alerts = self._db.execute("SELECT COUNT(*) FROM alerts").fetchone()[0]
        return {"taps": taps, "alerts": alerts}

    def close(self):
        try:
            self._db.close()
        except Exception:
            pass
