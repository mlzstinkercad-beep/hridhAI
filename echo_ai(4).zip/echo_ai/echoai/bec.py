"""Bose-Einstein-inspired adaptive background tracker ("condensate veto").

WHY IT EXISTS
-------------
A periodic machine (generator knock, fan blade slap, dripping pump) produces
hundreds of near-identical acoustic frames. In feature space that population
collapses onto a single direction, exactly like a Bose-Einstein condensate:
one macroscopically occupied "ground state" amid a thermal cloud of
diversified background noise. Human activity - taps, movement, shouting -
never condenses: it is impulsive, diverse and heavy-tailed.

HONEST PHYSICS MAPPING (what each pitch-term actually is)
    "virtual energy states"      -> the 18 feature coordinates per frame
    "thermal cloud"              -> Ledoit-Wolf covariance bulk; its noise
                                    spectrum follows Marchenko-Pastur law
    "condensation"               -> spiked covariance: the top eigenvalue
                                    lambda1 crosses the BBP bulk edge
                                    lambda+ = sigma^2 (1+sqrt(d/N))^2
    "ground-state occupation"    -> f = lambda1 / sum(lambda)  (variance
                                    fraction held by the dominant direction)
    "rank-1 projector excision"  -> P = I - u1 u1^T  (demo figure / tests)
    "veto"                       -> a classified transient whose features lie
                                    INSIDE the condensate direction is the
                                    machine itself -> confidence down-weighted
    "humans decohere the state"  -> impulsive human activity has heavy-tailed
                                    feature statistics (high excess kurtosis);
                                    the veto only engages on near-Gaussian
                                    (mechanical) ambience, so real taps pass

No training required: this layer is pure streaming statistics. Updating it
costs one 18x18 eigendecomposition every few seconds (microseconds), so it
runs comfortably on the 2013-class target machine and never blocks audio.
"""
from __future__ import annotations

from collections import deque

import numpy as np

from .config import (BEC_KURTOSIS_MAX, BEC_MIN_SAMPLES, BEC_MP_FACTOR,
                     BEC_OCCUPATION_MIN, BEC_PROJECTION_MAX, BEC_UPDATE_EVERY,
                     BEC_WINDOW, BEC_VETO_WEIGHT)


def _excess_kurtosis(x: np.ndarray) -> float:
    """Standardised 4th moment minus 3 (0 for a perfect Gaussian)."""
    x = np.asarray(x, dtype=np.float64)
    if x.size < 8:
        return 0.0
    z = (x - x.mean())
    sd = z.std()
    if sd < 1e-12:
        return 0.0
    z = z / sd
    return float(np.mean(z ** 4) - 3.0)


class CondensateTracker:
    """Streaming BEC monitor over the ambient feature population."""

    def __init__(self, window: int = BEC_WINDOW, min_samples: int = BEC_MIN_SAMPLES,
                 update_every: int = BEC_UPDATE_EVERY, mp_factor: float = BEC_MP_FACTOR,
                 occupation_min: float = BEC_OCCUPATION_MIN,
                 projection_max: float = BEC_PROJECTION_MAX,
                 kurtosis_max: float = BEC_KURTOSIS_MAX,
                 veto_weight: float = BEC_VETO_WEIGHT):
        self.window = window
        self.min_samples = min_samples
        self.update_every = update_every
        self.mp_factor = mp_factor
        self.occupation_min = occupation_min
        self.projection_max = projection_max
        self.kurtosis_max = kurtosis_max
        self.veto_weight = veto_weight
        self._buf: deque = deque(maxlen=window)
        self._since_update = 0
        self._fit: dict | None = None      # cached spectral state
        self.vetoes = 0                    # transients suppressed so far

    # ------------------------------------------------------------ observe --
    def observe_ambient(self, vector: np.ndarray) -> None:
        """Feed one sub-threshold ambient frame into the population."""
        self._buf.append(np.asarray(vector, dtype=np.float64))
        self._since_update += 1
        if self._since_update >= self.update_every and len(self._buf) >= self.min_samples:
            self._since_update = 0
            self._refit()

    def _refit(self) -> None:
        """Recompute the spectral state (LW covariance, eig, MP edge, tails)."""
        X = np.asarray(self._buf)                     # (N, d)
        N, d = X.shape
        mu = X.mean(axis=0)
        Xc = X - mu
        # Ledoit-Wolf shrinkage: robust sample covariance even when N ~ d
        S = (Xc.T @ Xc) / max(N - 1, 1)
        beta = min(N, d) / max(N + d, 1)
        # sklearn-free LW point estimate (same estimator, no import weight):
        #   shrinkage toward scaled identity
        var = np.trace(S) / d
        delta = float(np.sum(S ** 2) / d) if d else 0.0
        pihat = float(np.sum((Xc ** 2).T @ (Xc ** 2)) / (N * (N - 1)) / d) if N > 1 else 0.0
        shrink = 0.0
        denom = (pihat - delta)
        if denom > 1e-12:
            shrink = max(0.0, min(1.0, beta / denom * (pihat - 2.0 * delta + var ** 2)))
        Sigma = (1.0 - shrink) * S + shrink * var * np.eye(d)
        vals, vecs = np.linalg.eigh(Sigma)            # ascending order
        lam1 = float(vals[-1])
        u1 = np.asarray(vecs[:, -1])
        # noise floor: exclude the spike itself when estimating sigma^2
        sigma2 = float((vals[:-1].sum()) / max(d - 1, 1))
        edge = sigma2 * (1.0 + np.sqrt(d / N)) ** 2   # Marchenko-Pastur / BBP
        kurt = float(np.median([_excess_kurtosis(Xc[:, j]) for j in range(d)]))
        self._fit = {
            "N": N, "d": d, "mu": mu, "u1": u1, "lam1": lam1,
            "edge": edge, "ratio": lam1 / max(edge, 1e-12),
            "occupation": lam1 / max(float(vals.sum()), 1e-12),
            "kurtosis": kurt,
        }

    # ----------------------------------------------------------- decisions --
    @property
    def warm(self) -> bool:
        return len(self._buf) >= self.min_samples

    @property
    def condensate(self) -> bool:
        """True when a macroscopic ground state exists (spike above bulk)."""
        f = self._fit
        if not f:
            return False
        return (f["ratio"] >= self.mp_factor
                and f["occupation"] >= self.occupation_min)

    @property
    def humans_present(self) -> bool:
        """Heavy-tailed ambience -> impulsive human activity -> no veto."""
        f = self._fit
        return bool(f and f["kurtosis"] > self.kurtosis_max)

    def evaluate_transient(self, vector: np.ndarray) -> dict:
        """BEC veto decision for one classified transient.

        A transient is vetoed (machine, not survivor) when a condensate is
        locked, ambience is near-Gaussian (mechanical), and the transient's
        feature direction lies inside the ground state's projection ball.
        """
        info = {"veto": False, "reason": "warmup",
                "projection": 0.0, "warm": self.warm}
        if not self.warm or not self._fit:
            return info
        f = self._fit
        info.update(occupation=f["occupation"], ratio=f["ratio"],
                    kurtosis=f["kurtosis"], condensate=self.condensate)
        v = np.asarray(vector, dtype=np.float64) - f["mu"]
        nrm = float(np.linalg.norm(v))
        if nrm < 1e-12:
            return info
        proj = float((v @ f["u1"]) ** 2 / (nrm * nrm))
        info["projection"] = proj
        if not self.condensate:
            info["reason"] = "no-condensate"
            return info
        if self.humans_present:
            info["reason"] = "decohered (heavy tails - humans active)"
            return info
        if proj > self.projection_max:
            info["veto"] = True
            info["reason"] = "ground-state occupation"
        else:
            info["reason"] = "off ground state"
        return info

    def excise(self, vector: np.ndarray) -> np.ndarray:
        """Rank-1 projector P = I - u1 u1^T applied to a raw vector."""
        if not self._fit:
            return np.asarray(vector, dtype=np.float64)
        u1 = self._fit["u1"]
        v = np.asarray(vector, dtype=np.float64)
        return v - float(v @ u1) * u1

    def snapshot(self) -> dict:
        f = self._fit or {}
        return {
            "warm": self.warm,
            "n": len(self._buf),
            "condensate": self.condensate,
            "occupation": f.get("occupation", 0.0),
            "ratio": f.get("ratio", 0.0),          # lambda1 / MP edge
            "kurtosis": f.get("kurtosis", 0.0),
            "humans_present": self.humans_present,
            "vetoes": self.vetoes,
        }


# ------------------------------------------------------------- demo fig --
def make_demo_figure(path, seed: int = 5, n_frames: int = 360):
    """The pitch figure: a machine ramps up and the condensate pops out.

    Panel 1: lambda1 vs the Marchenko-Pastur bulk edge over time (the
    "critical point" where the spike separates is visible).
    Panel 2: ground-state occupation fraction with the condensation
    threshold; after the crossing the population is officially condensed.
    Panel 3: the population in the top-2 eigenbasis before/after the
    rank-1 projector excises the ground state.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.font_manager as fm
    for f in ("/usr/share/fonts/truetype/chinese/NotoSansSC-Regular.ttf",
              "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"):
        try:
            fm.fontManager.addfont(f)
        except Exception:
            pass
    import matplotlib.pyplot as plt
    plt.rcParams["font.sans-serif"] = ["DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False

    rng = np.random.default_rng(seed)
    d = 18
    machine_dir = rng.standard_normal(d)
    machine_dir /= np.linalg.norm(machine_dir)

    lam1s, edges, occs = [], [], []
    X_live: list = []
    for i in range(n_frames):
        # machine weight ramps 0 -> 0.55 after 20% warmup
        w = 0.0 if i < 0.2 * n_frames else 0.55 * (i - 0.2 * n_frames) / (0.8 * n_frames)
        x = rng.standard_normal(d) * 0.9
        if rng.random() < w:
            x += machine_dir * rng.uniform(2.5, 3.5)      # the "bosons"
        X_live.append(x)
        if len(X_live) < 30:            # warmup: spectrum undefined below this
            lam1s.append(np.nan); edges.append(np.nan); occs.append(np.nan)
            continue
        X = np.asarray(X_live[-BEC_WINDOW:])
        N = len(X)
        mu = X.mean(axis=0)
        Xc = X - mu
        S = (Xc.T @ Xc) / (N - 1)
        vals = np.linalg.eigvalsh(S)                     # values only: robust
        lam1 = float(vals[-1])
        sigma2 = float(vals[:-1].sum() / (d - 1))
        edge = sigma2 * (1 + np.sqrt(d / N)) ** 2
        lam1s.append(lam1)
        edges.append(edge)
        occs.append(lam1 / float(vals.sum()))

    t = np.arange(n_frames)
    fig, axes = plt.subplots(1, 3, figsize=(15, 4.4), constrained_layout=True)
    fig.suptitle("Bose-Einstein Condensation in Ambient Feature Space "
                 "(machine ramps up at t=20%)", fontsize=13)

    ax = axes[0]
    ax.plot(t, lam1s, color="#22d3ee", lw=2.2, label=r"$\lambda_1$ (top eigenvalue)")
    ax.plot(t, edges, color="#a78bfa", lw=1.8, ls="--",
            label=r"MP bulk edge $\lambda_+$")
    ax.axvline(0.2 * n_frames, color="#64748b", lw=1, ls=":")
    ax.set_xlabel("ambient frames")
    ax.set_ylabel("eigenvalue")
    ax.set_title("spike separation (BBP critical point)")
    ax.legend(loc="upper left", fontsize=9)

    ax = axes[1]
    ax.plot(t, occs, color="#f59e0b", lw=2.2)
    ax.axhline(BEC_OCCUPATION_MIN, color="#FF5C7A", ls="--", lw=1.5,
               label="condensation threshold")
    ax.fill_between(t, 0, 1, where=np.asarray(occs) > BEC_OCCUPATION_MIN,
                    color="#f59e0b", alpha=0.15, label="CONDENSATE")
    ax.set_xlabel("ambient frames")
    ax.set_ylabel(r"ground-state occupation $f=\lambda_1/\Sigma\lambda$")
    ax.set_title("macroscopic occupation")
    ax.set_ylim(0, 1)
    ax.legend(loc="upper left", fontsize=9)

    ax = axes[2]
    X = np.asarray(X_live)
    vals, vecs = np.linalg.eigh(np.cov(X.T))
    Y = X @ vecs[:, -2:]
    # before: machine cluster glued to the axis; after: rank-1 excised
    u1 = vecs[:, -1]
    X2 = (X - X.mean(axis=0)) @ (np.eye(d) - np.outer(u1, u1))
    vals2, vecs2 = np.linalg.eigh(np.cov(X2.T))
    Y2 = X2 @ vecs2[:, -2:]
    late = t > 0.75 * n_frames
    ax.scatter(Y[late, 0], Y[late, 1], s=6, alpha=0.45, color="#64748b",
               label="thermal cloud")
    ax.scatter(Y[~late, 0], Y[~late, 1], s=4, alpha=0.2, color="#94a3b8")
    ax.scatter(Y2[late, 0], Y2[late, 1], s=6, alpha=0.5, color="#22d3ee",
               label="after rank-1 excision")
    ax.set_xlabel("eigenvector 1")
    ax.set_ylabel("eigenvector 2")
    ax.set_title("rank-1 projector: ground state excised")
    ax.legend(loc="best", fontsize=9)

    fig.savefig(path, dpi=140)
    plt.close(fig)
    return path
