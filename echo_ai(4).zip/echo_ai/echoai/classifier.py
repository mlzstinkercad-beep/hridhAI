"""Runtime acoustic event classification (loads the trained ensemble).

v3: checks the model's feature dimension against the live extractor; a
v2 16-dim model is rejected with a clear error so it can never silently
mis-classify. The DSP fallback (physics prior) stays available.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
from joblib import load

from .config import MODEL_DIR, AI_CONF_MIN, FEATURE_DIM
from .features import extract_features

MODEL_PATH = MODEL_DIR / "model.joblib"


@dataclass
class ImpactEvent:
    """One classified transient."""
    t_mono: float                       # monotonic wall-clock seconds
    confidence: float                   # P(structural_tap) * 100
    label: str
    telemetry: dict
    feature_vector: np.ndarray = field(repr=False, default=None)
    bec_info: dict = field(default_factory=dict)   # v3: veto diagnostics


class AcousticClassifier:
    def __init__(self, model_path: Path = MODEL_PATH):
        self.available = False
        self.bundle = None
        self.last_error = None
        try:
            bundle = load(model_path)
            dims = getattr(bundle["model"], "n_features_in_", None)
            if dims is not None and dims != FEATURE_DIM:
                raise ValueError(
                    f"model expects {dims}-dim features but extractor emits "
                    f"{FEATURE_DIM}; retrain with 'python -m echoai.cli train' "
                    f"(v2 16-dim models are incompatible with v3)")
            self.bundle = bundle
            self.classes = [str(c) for c in bundle["classes"]]
            self.available = True
        except Exception as e:                       # model missing/stale -> DSP fallback
            self.last_error = f"model load failed: {e}"
            self.classes = ["structural_tap", "ambient_noise", "surface_clatter", "human_voice"]
        self.predicts_total = 0

    # ---------------------------------------------------------------- api --
    def classify_chunk(self, chunk: np.ndarray, sr: int = 44100) -> ImpactEvent:
        t_mono = time.monotonic()
        feats = extract_features(chunk, sr)
        vec = feats["vector"]
        if self.available:
            proba = self.bundle["model"].predict_proba(vec.reshape(1, -1))[0]
            idx = int(np.argmax(proba))
            conf = float(proba[self.classes.index("structural_tap")] * 100.0)
            label = self.classes[idx]
            # trust boost: ensemble proba blended with structural-prior heuristic
            tel = feats["telemetry"]
            prior = self._structural_prior(tel)
            conf = 100.0 * (0.75 * (conf / 100.0) + 0.25 * prior)
        else:
            tel = feats["telemetry"]
            conf = 100.0 * self._structural_prior(tel)
            label = "structural_tap" if conf >= AI_CONF_MIN else "ambient_noise"
        self.predicts_total += 1
        return ImpactEvent(t_mono, conf, label, tel, vec)

    def _structural_prior(self, tel: dict) -> float:
        """Legacy-style physics gate as ensemble sanity blend/fallback.

        Calibrated v3 (measured on 590 tap-onset vs 780 shout chunks):
            harmonicity  tap p50=0.70  shout p50=1.00   <- primary cue
            flatness     tap p50=0.20  shout p50=0.10
            centroid     tap p50=2108  shout p50=1915 (weak, tiebreak only)
            zcr          both ~0
        A voice stack is MORE harmonic than a ringing tap (a decaying
        sinusoid keeps some noise floor; a pitch-synchronised stack is
        near-pure). Voice: harm>=0.9 AND flat<=0.15 -> suppressed.
        """
        c = tel["centroid_hz"]; f = tel["flatness"]; h = tel.get("harmonicity", 0.0)
        # voice-likeness in [0,1]: high harmonicity and low flatness
        v_h = min(1.0, max(0.0, (h - 0.78) / 0.12))          # 0.78 -> 0.90
        v_f = min(1.0, max(0.0, (0.18 - f) / 0.08))          # flat<=0.10
        voice_like = v_h * (0.35 + 0.65 * v_f)
        # centroid tiebreak: far above 6.5 kHz leans noise/clatter; the
        # dominant ringing modes of structure-transmitted taps sit at
        # 90-220 Hz fundamentals, so the passband extends down to 300 Hz
        s_c = _band(c, 300.0, 6500.0, 2500.0)
        return float(s_c * (1.0 - 0.85 * voice_like))

    @property
    def info(self) -> dict:
        return {
            "available": self.available,
            "version": (self.bundle or {}).get("version", "fallback"),
            "metrics": (self.bundle or {}).get("metrics", {}),
            "last_error": self.last_error,
            "predicts_total": self.predicts_total,
        }


def _band(v, lo, hi, soft):
    if v < lo:
        return max(0.0, 1.0 - (lo - v) / soft)
    if v > hi:
        return max(0.0, 1.0 - (v - hi) / soft)
    return 1.0
