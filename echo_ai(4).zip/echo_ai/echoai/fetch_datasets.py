"""Fetch real-world labelled audio from the ESC-50 corpus (online files).

ESC-50 (Piczak, 2015): 2000 CC-BY-licensed 5-s environmental recordings,
44.1 kHz mono. We pull a curated subset over plain HTTPS (no archive
download, ~430 KB per file) and map its categories to our classes:

    door_wood_knock, clapping, footsteps        -> structural_tap
      (real impact events on solid surfaces / rhythmic percussive events)
    rain, wind, sea_waves, engine, keyboard_typing,
    breathing, crackling_fire, washing_machine  -> ambient_noise
      (continuous non-impact beds)
    glass_breaking, can_opening, mouse_click   -> surface_clatter
      (short bright surface events, not structure-transmitted)

Files land in data/esc50/audio/ and a manifest CSV in data/esc50/.
Failures are skipped individually (network hiccups never abort the run).
"""
from __future__ import annotations

import csv
import io
import time
from pathlib import Path

import requests
from .config import DATA_DIR

BASE = "https://raw.githubusercontent.com/karolpiczak/ESC-50/master"
META_URL = f"{BASE}/meta/esc50.csv"
AUDIO_URL = f"{BASE}/audio"

CATEGORY_MAP = {
    "door_wood_knock": "structural_tap",
    "clapping": "structural_tap",
    "footsteps": "structural_tap",
    "rain": "ambient_noise",
    "wind": "ambient_noise",
    "sea_waves": "ambient_noise",
    "engine": "ambient_noise",
    "keyboard_typing": "ambient_noise",
    "breathing": "ambient_noise",
    "crackling_fire": "ambient_noise",
    "washing_machine": "ambient_noise",
    "glass_breaking": "surface_clatter",
    "can_opening": "surface_clatter",
    "mouse_click": "surface_clatter",
}

PER_CATEGORY_CAP = 20          # 13 cats * 20 = up to 260 files (~55 MB)
RETRIES, RETRY_BACKOFF_S = 3, 1.5


def fetch_manifest() -> list[dict]:
    r = requests.get(META_URL, timeout=30)
    r.raise_for_status()
    return list(csv.DictReader(io.StringIO(r.text)))


def download_esc50(out_dir: Path | None = None, per_category_cap=PER_CATEGORY_CAP,
                   progress_every=40) -> Path:
    out_dir = out_dir or (DATA_DIR / "esc50")
    audio_dir = out_dir / "audio"
    audio_dir.mkdir(parents=True, exist_ok=True)
    manifest = fetch_manifest()
    wanted, per_cat = [], {}
    for row in manifest:
        cat = row["category"]
        if cat in CATEGORY_MAP and per_cat.get(cat, 0) < per_category_cap:
            per_cat[cat] = per_cat.get(cat, 0) + 1
            wanted.append(row)
    done = 0
    for k, row in enumerate(wanted):
        dest = audio_dir / row["filename"]
        if dest.exists() and dest.stat().st_size > 100_000:
            done += 1
            continue
        for attempt in range(RETRIES):
            try:
                rr = requests.get(f"{AUDIO_URL}/{row['filename']}", timeout=30)
                rr.raise_for_status()
                dest.write_bytes(rr.content)
                break
            except Exception:
                if attempt + 1 == RETRIES:
                    print(f"  [skip] {row['filename']} failed {RETRIES}x")
                else:
                    time.sleep(RETRY_BACKOFF_S * (attempt + 1))
        done += 1
        if progress_every and done % progress_every == 0:
            print(f"  {done}/{len(wanted)} files fetched")
    # manifest csv
    with open(out_dir / "manifest.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["filename", "esc50_category", "our_label"])
        for row in wanted:
            cat = row["category"]
            if (audio_dir / row["filename"]).exists():
                w.writerow([row["filename"], cat, CATEGORY_MAP[cat]])
    print(f"ESC-50 subset: {len(wanted)} files -> {audio_dir}")
    return out_dir


if __name__ == "__main__":
    download_esc50()
