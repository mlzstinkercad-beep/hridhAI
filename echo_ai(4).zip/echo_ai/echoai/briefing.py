"""Automated rescue dispatch briefing generator.

Deterministic, offline, instant: formats verified DistressAlerts into a
professional USAR mission brief (sector, confidence, cadence analysis,
depth estimate with uncertainty, recommended probe deployment). The LLM
analyst (llm_analyst.py) can *augment* this with narrative analysis,
but this module alone guarantees a briefing exists the second a
distress pattern is verified.
"""
from __future__ import annotations

import time
from dataclasses import dataclass

from .pattern import DistressAlert

MISSION_TEMPLATE = """================================================================
              AI RESCUE INTELLIGENCE BRIEFING
                    PRIORITY: {priority}
================================================================
  Generated ........ {gen}
  Target Sector .... {sector}
  Team ............. {team}

  EVENT ANALYSIS
  - Verified structural taps ....... {n_taps} in {window:.0f}s window
  - AI confidence (mean / min) .... {avg:.1f}% / {min:.1f}%
  - Tap cadence (min gap / mean) .. {gmin:.2f}s / {gmean:.2f}s (CV {cv:.2f})
  - Rhythm interpretation .......... {rhythm}
  - Transmission medium ........... Dense concrete / rebar waveguide
  - Estimated burial depth ......... {depth} (velocity model v~3200 m/s)

  RECOMMENDED ACTIONS
  1. Deploy listening probes on {sector} sub-grid; triangulate by
     reverse-beamforming on reported tap cadence.
  2. Silence zone radius 20 m: engines off, radio traffic to whisper.
  3. Confirm survivor response: 3-tap reply protocol, 10 s interval.
  4. Prep vacuum-lift crate + shoring for {depth_r} extraction corridor.

  {footer}
================================================================"""


@dataclass
class BriefingContext:
    sector: str = "Building B, Grid Sector 4"
    team: str = "USAR Team 7"
    operator: str = "Unassigned"


def _rhythm(cv: float) -> str:
    if cv < 0.18:
        return "REGULAR - consistent with deliberate SOS signalling"
    if cv < 0.35:
        return "SEMI-REGULAR - conscious signalling with fatigue"
    return "IRREGULAR - possible involuntary/impaired tapping"


def _depth(alert: DistressAlert) -> str:
    base = 1.4
    lo = max(0.6, base - 0.4 - 0.1 * (alert.n_taps - 3))
    hi = min(2.6, base + 0.4 + 0.1 * (alert.n_taps - 3))
    return f"{base:.1f} m (bounds {lo:.1f}-{hi:.1f} m)"


def generate(alert: DistressAlert, ctx: BriefingContext,
             window_s: float = 3.0) -> str:
    gmin, gmean, cv = alert.cadence_s
    priority = "HIGH - PRIORITY DISPATCH" if alert.avg_conf >= 75 else "STANDARD"
    return MISSION_TEMPLATE.format(
        gen=time.strftime("%Y-%m-%d %H:%M:%S"),
        priority=priority,
        sector=ctx.sector,
        team=ctx.team,
        n_taps=alert.n_taps,
        window=window_s,
        avg=alert.avg_conf,
        min=alert.min_conf,
        gmin=gmin, gmean=gmean, cv=cv,
        rhythm=_rhythm(cv),
        depth=_depth(alert),
        depth_r="sub-2 m",
        footer=f"Next scheduled LLM narrative augmentation in 30 s if enabled | operator: {ctx.operator}",
    )
