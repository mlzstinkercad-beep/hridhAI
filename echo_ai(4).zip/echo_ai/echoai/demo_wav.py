"""Demo rescue-scene WAV for file-replay mode (data/demo_rescue_scene.wav)."""
from __future__ import annotations

import numpy as np
import soundfile as sf

from .config import DATA_DIR, SAMPLE_RATE
from .synth_corpus import make_structural_tap_clip, make_negative_clip


def write_demo(path=None, seconds=24.0, seed=11):
    path = path or (DATA_DIR / "demo_rescue_scene.wav")
    path.parent.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(seed)
    out = []
    while sum(len(c) for c in out) / SAMPLE_RATE < seconds:
        r = rng.random()
        if r < 0.4:
            clip, _ = make_structural_tap_clip(rng, n_taps=int(rng.integers(3, 6)))
            out.append(clip)
        else:
            clip, _ = make_negative_clip(rng)
            out.append(clip)
    audio = np.concatenate(out)[: int(seconds * SAMPLE_RATE)]
    audio = audio / max(np.max(np.abs(audio)), 1e-9) * 0.9
    sf.write(path, audio.astype(np.float32), SAMPLE_RATE)
    print(f"demo scene -> {path} ({seconds}s)")
    return path


if __name__ == "__main__":
    write_demo()
