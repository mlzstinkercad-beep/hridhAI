"""Mission-control console widgets for ECHO-AI.

Custom-drawn (QPainter) dark-navy components matching the reference
design language: teal->cyan and purple gradient accents on glassy navy
panels, donut gauges, mini bar meters, vertical meters, stepper dots.
"""
from __future__ import annotations

import math

import numpy as np
from PyQt6.QtCore import (QPointF, QRectF, Qt, QTimer, pyqtProperty,
                          pyqtSignal)
from PyQt6.QtGui import (QBrush, QColor, QFont, QFontMetrics, QLinearGradient,
                         QPainter, QPen)
from PyQt6.QtWidgets import QFrame, QLabel, QVBoxLayout, QWidget

# ------------------------------------------------------------- palette ----
BG = "#171C2E"
PANEL = "#232A44"
PANEL_INSET = "#2A3150"
TEAL = "#22D3C5"
CYAN = "#2BB3F0"
PURPLE = "#8C6FF7"
VIOLET = "#A78BFA"
TXT = "#FFFFFF"
MUT = "#6B7597"
TRACK = "#2E3554"


def _grad_h(c1: str, c2: str) -> QLinearGradient:
    g = QLinearGradient(0, 0, 1, 0)
    g.setCoordinateMode(QLinearGradient.CoordinateMode.ObjectMode)
    g.setColorAt(0, QColor(c1)); g.setColorAt(1, QColor(c2))
    return g


def panel(w: QWidget, title: str = ""):
    w.setStyleSheet(f"""
        background-color: {PANEL}; border: 1px solid rgba(255,255,255,26);
        border-radius: 12px;
    """)


class GlassPanel(QFrame):
    """Base glassy navy card with optional title."""

    def __init__(self, title: str = "", parent=None):
        super().__init__(parent)
        self.title = title
        self.setStyleSheet(f"""
            GlassPanel {{
                background-color: {PANEL};
                border: 1px solid rgba(255,255,255,26);
                border-radius: 12px;
            }}
        """)


def make_title_label(text: str, color: str = TXT, size: int = 15,
                     bold: bool = True) -> QLabel:
    lab = QLabel(text)
    lab.setFont(QFont("Inter", size, QFont.Weight.Bold if bold else QFont.Weight.Normal))
    lab.setStyleSheet(f"color: {color}; background: transparent; border: none;")
    return lab


class GradientBar(QWidget):
    """Horizontal progress-style meter with gradient fill + knob."""

    def __init__(self, color1=TEAL, color2=CYAN, height=8, show_knob=True):
        super().__init__()
        self._v = 0.0
        self.c1, self.c2 = color1, color2
        self.bar_h = height
        self.knob = show_knob
        self.setMinimumHeight(height + 8)

    def set_value(self, v: float):
        self._v = max(0.0, min(1.0, v))
        self.update()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()
        y = (h - self.bar_h) / 2
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(TRACK))
        p.drawRoundedRect(QRectF(0, y, w, self.bar_h), self.bar_h / 2, self.bar_h / 2)
        if self._v > 0.01:
            g = QLinearGradient(0, y, w, y)
            g.setColorAt(0, QColor(self.c1)); g.setColorAt(1, QColor(self.c2))
            p.setBrush(QBrush(g))
            p.drawRoundedRect(QRectF(0, y, max(4.0, w * self._v), self.bar_h),
                              self.bar_h / 2, self.bar_h / 2)
        if self.knob and self._v > 0.005:
            kx = w * self._v
            p.setBrush(QColor("#FFFFFF"))
            p.drawEllipse(QPointF(kx, y + self.bar_h / 2), self.bar_h * 0.62,
                          self.bar_h * 0.62)
        p.end()


class DonutGauge(QWidget):
    """Arc donut gauge: teal arc + purple arc segments on dark track.

    value1 (0-1) drives the main teal arc; value2 (0-1) a secondary
    purple arc drawn from the same start. Center text lines customised
    via set_text().
    """

    def __init__(self, size=118, line1="AI", line2=""):
        super().__init__()
        self.setFixedSize(size, size)
        self._v1, self._v2 = 0.0, 0.0
        self._l1, self._l2 = line1, line2
        self._glow = 0.0

    def set_values(self, v1: float, v2: float = None):
        self._v1 = max(0.0, min(1.0, v1))
        if v2 is not None:
            self._v2 = max(0.0, min(1.0, v2))
        self.update()

    def set_text(self, l1: str, l2: str = ""):
        self._l1, self._l2 = l1, l2
        self.update()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        s = self.width()
        m = 11.0
        rect = QRectF(m, m, s - 2 * m, s - 2 * m)
        pen_w = 11
        start = 90 * 16
        span = 360 * 16

        p.setPen(QPen(QColor(TRACK), pen_w, Qt.PenStyle.SolidLine,
                      Qt.PenCapStyle.RoundCap))
        p.drawArc(rect, start, -span)

        def arc(v, c1, c2, width=pen_w):
            if v <= 0.003:
                return
            g = QConicGradientHelper(c1, c2, rect).gradient()
            p.setPen(QPen(QBrush(g), width, Qt.PenStyle.SolidLine,
                          Qt.PenCapStyle.RoundCap))
            p.drawArc(rect, start, -int(span * v))

        arc(self._v2, PURPLE, VIOLET, width=7)
        arc(self._v1, TEAL, CYAN)

        p.setPen(QColor(TXT))
        f = QFont("Inter", int(s * 0.16), QFont.Weight.Bold)
        p.setFont(f)
        p.drawText(rect, Qt.AlignmentFlag.AlignCenter, self._l1)
        if self._l2:
            p.setPen(QColor(MUT))
            f2 = QFont("Inter", int(s * 0.085))
            p.setFont(f2)
            p.drawText(QRectF(rect.left(), rect.center().y() + s * 0.13,
                              rect.width(), s * 0.15),
                       Qt.AlignmentFlag.AlignHCenter, self._l2)
        p.end()


class QConicGradientHelper:
    """Qt6 lacks a native conic gradient brush; emulate with a sweep of
    radial stops via a pre-rendered pixmap (cheap at gauge size)."""

    def __init__(self, c1: str, c2: str, rect: QRectF):
        from PyQt6.QtGui import QPixmap, QRadialGradient
        self.pm = QPixmap(int(rect.width()) + 2, int(rect.height()) + 2)
        self.pm.fill(Qt.GlobalColor.transparent)
        pp = QPainter(self.pm)
        pp.setRenderHint(QPainter.RenderHint.Antialiasing)
        g = QRadialGradient(rect.center(), rect.width() / 2)
        g.setColorAt(0, QColor(c1)); g.setColorAt(1, QColor(c2))
        pp.setPen(Qt.PenStyle.NoPen)
        pp.setBrush(QBrush(g))
        pp.drawEllipse(0, 0, self.pm.width(), self.pm.height())
        pp.end()

    def gradient(self):
        return QBrush(self.pm)


class MiniBars(QWidget):
    """Mini bar-chart meter (history of values). Alternating gradient bars."""

    def __init__(self, n=14, color1=TEAL, color2=CYAN, bar_w=6, gap=4):
        super().__init__()
        self.n = n
        self.hist: list[float] = [0.0] * n
        self.c1, self.c2 = color1, color2
        self.bar_w, self.gap = bar_w, gap
        self.setMinimumHeight(46)

    def push(self, v: float):
        self.hist.append(max(0.0, min(1.0, v)))
        self.hist = self.hist[-self.n:]
        self.update()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        h = self.height()
        for i, v in enumerate(self.hist):
            x = i * (self.bar_w + self.gap)
            bh = max(3.0, v * (h - 4))
            g = QLinearGradient(x, h - bh, x, h)
            a = (i % 2 == 0)
            g.setColorAt(0, QColor(self.c1 if a else PURPLE))
            g.setColorAt(1, QColor(self.c2 if a else VIOLET))
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QBrush(g))
            p.drawRoundedRect(QRectF(x, h - bh, self.bar_w, bh), 3, 3)
        p.end()


class StepperDots(QWidget):
    """Pattern-window stepper: filled dot per verified tap in window."""

    NEEDED = 3

    def __init__(self, labels=("ARM", "TAP 1", "TAP 2", "SOS")):
        super().__init__()
        self._step = 0
        self.labels = labels
        self.setMinimumHeight(44)

    def set_step(self, k: int):
        self._step = max(0, min(len(self.labels) - 1, k))
        self.update()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()
        n = len(self.labels)
        xs = [w * (i + 0.5) / n for i in range(n)]
        y = h * 0.38
        # track
        p.setPen(QPen(QColor(TRACK), 2, Qt.PenStyle.SolidLine))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawLine(QPointF(xs[0], y), QPointF(xs[-1], y))
        for i, x in enumerate(xs):
            active = i <= self._step
            if i == 0:
                col = PURPLE
            elif i == 1:
                col = VIOLET
            elif i == 2:
                col = TEAL
            else:
                col = "#FF5C7A"
            r = 7 if active else 5
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(col) if active else QColor(TRACK))
            p.drawEllipse(QPointF(x, y), r, r)
            p.setPen(QColor(TXT) if active else QColor(MUT))
            f = QFont("Inter", 8)
            p.setFont(f)
            p.drawText(QRectF(x - w / n / 2, y + 10, w / n, 14),
                       Qt.AlignmentFlag.AlignCenter, self.labels[i])
        p.end()


class PillButton(QWidget):
    clicked = pyqtSignal()

    def __init__(self, text: str, kind="primary", min_h=30):
        super().__init__()
        self.text = text
        self.kind = kind
        self.setFixedHeight(min_h)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def mousePressEvent(self, e):
        self.clicked.emit()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        r = self.height() / 2
        rect = QRectF(0, 0, self.width(), self.height())
        if self.kind == "primary":
            g = QLinearGradient(0, 0, self.width(), 0)
            g.setColorAt(0, QColor(TEAL)); g.setColorAt(1, QColor(CYAN))
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QBrush(g))
            p.drawRoundedRect(rect, r, r)
            tc = QColor("#FFFFFF")
        else:
            p.setPen(QPen(QColor("rgba(255,255,255,40)"), 1))
            p.setBrush(QColor(PANEL_INSET))
            p.drawRoundedRect(rect, r, r)
            tc = QColor(MUT)
        p.setPen(tc)
        p.setFont(QFont("Inter", 10, QFont.Weight.DemiBold))
        p.drawText(rect, Qt.AlignmentFlag.AlignCenter, self.text)
        p.end()


class VSliderBar(QWidget):
    """Vertical gradient meter (mic level), non-interactive + peak cap."""

    def __init__(self, color1=TEAL, color2=CYAN):
        super().__init__()
        self._v = 0.0
        self._peak = 0.0
        self.c1, self.c2 = color1, color2
        self.setFixedWidth(18)

    def set_value(self, v: float):
        self._v = max(0.0, min(1.0, v))
        self._peak = max(self._peak * 0.92, self._v)
        self.update()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(TRACK))
        p.drawRoundedRect(QRectF(0, 0, w, h), w / 2, w / 2)
        fh = max(4.0, self._v * h)
        g = QLinearGradient(0, h, 0, h - fh)
        g.setColorAt(0, QColor(self.c1)); g.setColorAt(1, QColor(self.c2))
        p.setBrush(QBrush(g))
        p.drawRoundedRect(QRectF(0, h - fh, w, fh), w / 2, w / 2)
        py = h - self._peak * h
        p.setBrush(QColor("#FFFFFF"))
        p.drawRect(QRectF(1, max(0.0, py - 2), w - 2, 2))
        p.end()
