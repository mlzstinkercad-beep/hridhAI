"""Audio input streams: live mic, file replay, and demo simulator.

All streams call callback(chunk: np.ndarray) roughly every CHUNK_SECONDS
with int16/float32 mono samples at SAMPLE_RATE. Audio capture runs in a
Python thread (sounddevice callback merely queues; we pull in a loop) so
a failing device can never crash the app.
"""
from __future__ import annotations

import queue
import threading
import time
from pathlib import Path

import numpy as np
import soundfile as sf

from .config import CHUNK_SAMPLES, SAMPLE_RATE
from .synth_corpus import make_structural_tap_clip, make_negative_clip


class LiveMicStream:
    """sounddevice mic capture with a safety thread wrapper."""

    def __init__(self, device=None):
        self.device = device
        self._sd = None
        self._q: queue.Queue = queue.Queue(maxsize=64)
        self._run = False

    def start(self, callback):
        import sounddevice as sd
        self._sd = sd

        def _cb(indata, frames, time_info, status):
            try:
                self._q.put_nowait(indata[:, 0].copy())
            except queue.Full:
                pass

        self._stream = sd.InputStream(samplerate=SAMPLE_RATE, channels=1,
                                      dtype="float32", blocksize=CHUNK_SAMPLES,
                                      device=self.device, callback=_cb)
        self._stream.start()
        self._run = True

        def _pull():
            while self._run:
                try:
                    chunk = self._q.get(timeout=0.25)
                    callback(chunk)
                except queue.Empty:
                    pass

        self._thread = threading.Thread(target=_pull, daemon=True)
        self._thread.start()
        return True

    def stop(self):
        self._run = False
        try:
            self._stream.stop(); self._stream.close()
        except Exception:
            pass


class FileStream:
    """Replay a WAV file through the pipeline in real time (demo mode)."""

    def __init__(self, path: Path, loop=True):
        self.path = Path(path)
        self.loop = loop
        self._run = False

    def start(self, callback):
        self._run = True

        def _play():
            while self._run:
                wav, sr = sf.read(self.path, dtype="float32")
                if wav.ndim > 1:
                    wav = wav.mean(axis=1)
                for i in range(0, len(wav) - CHUNK_SAMPLES, CHUNK_SAMPLES):
                    if not self._run:
                        return
                    callback(wav[i:i + CHUNK_SAMPLES])
                    time.sleep(CHUNK_SAMPLES / SAMPLE_RATE)
                if not self.loop:
                    break

        self._thread = threading.Thread(target=_play, daemon=True)
        self._thread.start()
        return True

    def stop(self):
        self._run = False


class SimulatorStream:
    """Synthesises the post-disaster soundscape live.

    Timeline: ambient bed with occasional clatter, then a structural-tap
    burst (3-5 taps, SOS cadence) every ~8 s. Perfect for demos without
    a microphone or a rescue site.
    """

    def __init__(self, seed=None):
        self.rng = np.random.default_rng(seed if seed is not None else int(time.time()))
        self._run = False
        self._buffer = np.zeros(0, dtype=np.float32)
        self._first = True                # guarantee an SOS burst up front

    def _next_clip(self):
        if self._first:
            self._first = False
            clip, label = make_structural_tap_clip(self.rng, n_taps=3)
            return clip.astype(np.float32), label
        r = self.rng.random()
        if r < 0.45:
            clip, label = make_structural_tap_clip(self.rng, n_taps=int(self.rng.integers(3, 6)))
        else:
            clip, label = make_negative_clip(self.rng)
        return clip.astype(np.float32), label

    def start(self, callback):
        self._run = True

        def _feed():
            while self._run:
                clip, _ = self._next_clip()
                clip = clip / max(np.max(np.abs(clip)), 1e-9)
                for i in range(0, len(clip) - CHUNK_SAMPLES, CHUNK_SAMPLES):
                    if not self._run:
                        return
                    callback(clip[i:i + CHUNK_SAMPLES].astype(np.float32))
                    time.sleep(CHUNK_SAMPLES / SAMPLE_RATE)

        self._thread = threading.Thread(target=_feed, daemon=True)
        self._thread.start()
        return True

    def stop(self):
        self._run = False
