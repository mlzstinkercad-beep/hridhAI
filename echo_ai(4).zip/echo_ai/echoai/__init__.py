"""ECHO-AI: acoustic survivor detection with a trained ML ensemble."""
__version__ = "2.0.0"

from .config import SAMPLE_RATE  # noqa: F401
