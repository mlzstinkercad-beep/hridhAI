#!/usr/bin/env bash
# ECHO-AI v3 one-shot pipeline: fetch real audio -> sanity tests -> dataset -> train -> demo wav.
# The model is NOT shipped: this script trains it (~20-40 min with the default profile).
# Safe to re-run; each stage is resumable (files already present are skipped).
set -e
cd "$(dirname "$0")"
PY=${PYTHON:-python3}
PROFILE=${PROFILE:-full}

echo "== [1/5] Fetching ESC-50 real-audio subset (online) =="
$PY -m echoai.cli fetch --esc-cap 20

echo "== [2/5] Running the offline test suite (pre-training, DSP fallback) =="
$PY -m echoai.cli test

echo "== [3/5] Building feature dataset (synthetic physics + voice + ESC-50 + augmentation) =="
$PY -m echoai.cli dataset --profile "$PROFILE"

echo "== [4/5] Training ensemble classifier (profile: $PROFILE) =="
$PY -m echoai.cli train

echo "== [5/5] Writing demo rescue scene WAV =="
$PY -m echoai.cli demo-wav

echo ""
echo "Done. Launch with:  $PY -m echoai.cli launch   (or: launch --mode file|live)"
