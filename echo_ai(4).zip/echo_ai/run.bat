@echo off
rem ECHO-AI v3 one-shot pipeline: fetch real audio -> sanity tests -> dataset -> train -> demo wav.
rem Windows twin of run.sh. The model is NOT shipped: this script trains it
rem (~20-40 min with the default profile). Safe to re-run; stages are resumable.
cd /d "%~dp0"
if not defined PYTHON set "PYTHON=python"
if not defined PROFILE set "PROFILE=full"

echo == [1/5] Fetching ESC-50 real-audio subset (online) ==
%PYTHON% -m echoai.cli fetch --esc-cap 20 || goto :fail

echo == [2/5] Running the offline test suite (pre-training, DSP fallback) ==
%PYTHON% -m echoai.cli test || goto :fail

echo == [3/5] Building feature dataset (synthetic physics + voice + ESC-50 + augmentation) ==
%PYTHON% -m echoai.cli dataset --profile %PROFILE% || goto :fail

echo == [4/5] Training ensemble classifier (profile: %PROFILE%) ==
%PYTHON% -m echoai.cli train || goto :fail

echo == [5/5] Writing demo rescue scene WAV ==
%PYTHON% -m echoai.cli demo-wav || goto :fail

echo.
echo Done. Launch with:  %PYTHON% -m echoai.cli launch   (mode: sim, file or live)
exit /b 0

:fail
echo.
echo FAILED - see the error above.
exit /b 1
