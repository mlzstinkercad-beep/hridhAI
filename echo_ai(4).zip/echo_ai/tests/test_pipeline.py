"""End-to-end offline test suite for ECHO-AI v3 (no mic, no network).

Runs: feature determinism/finiteness (18-D), corpus labels incl. voice,
BEC condensate physics (spike detection, veto, heavy-tail decoherence),
pattern state machine, briefing, persistence, processor gating, and two
full scenarios: 3-tap SOS -> alert, and 3-tap SOS BURIED IN SHOUTING
(the v3 headline: taps survive a loud human voice bed).
"""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from echoai.bec import CondensateTracker, _excess_kurtosis
from echoai.classifier import AcousticClassifier, ImpactEvent
from echoai.config import SAMPLE_RATE
from echoai.pattern import DistressAlert, PatternEngine
from echoai.processor import SignalProcessor
from echoai.synth_corpus import (_voice_segment, generate_corpus,
                                 make_negative_clip, make_structural_tap_clip)
from echoai.features import extract_features
from echoai.briefing import BriefingContext, generate as gen_briefing
from echoai.persistence import EventStore

PASS = 0


def ok(name, cond, detail=""):
    global PASS
    assert cond, f"FAIL {name} {detail}"
    PASS += 1
    print(f"  ok - {name}")


def test_features():
    print("[features]")
    rng = np.random.default_rng(3)
    tap, _ = make_structural_tap_clip(rng, n_taps=3)
    r = extract_features(tap, SAMPLE_RATE)
    ok("18-dim vector", r["vector"].shape == (18,))
    ok("finite", bool(np.all(np.isfinite(r["vector"]))))
    r2 = extract_features(tap, SAMPLE_RATE)
    ok("deterministic", np.allclose(r["vector"], r2["vector"]))
    noise, _ = make_negative_clip(np.random.default_rng(4))
    rn = extract_features(noise, SAMPLE_RATE)
    ok("tap vs noise separable (centroid)",
       r["telemetry"]["centroid_hz"] < rn["telemetry"]["centroid_hz"],
       f"{r['telemetry']['centroid_hz']:.0f} vs {rn['telemetry']['centroid_hz']:.0f}")
    ok("flatness within [0,1]", 0.0 <= r["telemetry"]["flatness"] <= 1.0)
    ok("harmonicity within [0,1]", 0.0 <= r["telemetry"]["harmonicity"] <= 1.0)
    ok("rolloff sane", 100.0 <= r["telemetry"]["rolloff_hz"] <= 15000.0)
    # voice must be MORE harmonic than a structural tap
    voice = _voice_segment(np.random.default_rng(6), 1.6, n_voices=1, shout=True)
    rv = extract_features(voice, SAMPLE_RATE)
    ok("voice more harmonic than tap",
       rv["telemetry"]["harmonicity"] > r["telemetry"]["harmonicity"],
       f"voice={rv['telemetry']['harmonicity']:.2f} tap={r['telemetry']['harmonicity']:.2f}")


def test_corpus():
    print("[corpus]")
    rng = np.random.default_rng(5)
    tap_c, noise_c, clat_c, voice_c = [], [], [], []
    gen = generate_corpus(n_per_class=30, seed=5)
    for clip, label, _extra in gen:
        f = extract_features(clip)["telemetry"]
        {"structural_tap": tap_c, "ambient_noise": noise_c,
         "surface_clatter": clat_c, "human_voice": voice_c}[label].append(f)
    ok("labels balanced", len(tap_c) == 30 and len(noise_c) + len(clat_c) + len(voice_c) == 30,
       f"tap={len(tap_c)} amb={len(noise_c)} clat={len(clat_c)} voice={len(voice_c)}")
    ok("voice class present", len(voice_c) > 0, f"voice={len(voice_c)}")
    tm = np.mean([f["centroid_hz"] for f in tap_c])
    cm = np.mean([f["centroid_hz"] for f in clat_c])
    ok("taps darker than clatter (centroid)", tm < cm, f"{tm:.0f} vs {cm:.0f}")
    om = np.mean([f["onset_density"] for f in tap_c])
    onm = np.mean([f["onset_density"] for f in noise_c])
    ok("taps more percussive than ambience", om > onm, f"{om:.2f} vs {onm:.2f}")
    hm_tap = np.mean([f["harmonicity"] for f in tap_c])
    hm_v = np.mean([f["harmonicity"] for f in voice_c])
    ok("voice negatives more harmonic than positives",
       hm_v > hm_tap, f"voice={hm_v:.2f} tap={hm_tap:.2f}")


def test_bec():
    print("[BEC condensate physics]")
    rng = np.random.default_rng(11)
    d = 18
    # 1) Gaussian cloud: no condensate
    trk = CondensateTracker()
    cloud = rng.standard_normal((400, d))
    for v in cloud:
        trk.observe_ambient(v)
    ok("thermal cloud: no condensate", not trk.condensate,
       f"ratio={trk.snapshot().get('ratio', 0):.2f} occ={trk.snapshot().get('occupation', 0):.2f}")
    # 2) machine population: condensate appears (a real periodic machine
    #    produces near-identical frames: strong, consistent directional shift)
    trk2 = CondensateTracker()
    machine_dir = rng.standard_normal(d)
    machine_dir /= np.linalg.norm(machine_dir)
    for i in range(400):
        v = rng.standard_normal(d) * 0.9
        if rng.random() < 0.7:
            v = v + machine_dir * rng.uniform(3.0, 4.5)
        trk2.observe_ambient(v)
    ok("machine population: condensate detected", trk2.condensate,
       f"ratio={trk2.snapshot().get('ratio', 0):.2f} occ={trk2.snapshot().get('occupation', 0):.2f}")
    # 3) veto fires on a transient aligned with the ground state
    verdict = trk2.evaluate_transient(machine_dir * 3.5 + trk2._fit["mu"])
    ok("ground-state transient vetoed", verdict["veto"],
       f"proj={verdict['projection']:.2f} reason={verdict['reason']}")
    # 4) off-axis transient passes
    off = rng.standard_normal(d) * 3.0
    verdict2 = trk2.evaluate_transient(off)
    ok("off-ground-state transient passes", not verdict2["veto"],
       f"proj={verdict2['projection']:.2f}")
    # 5) heavy tails (humans shouting) disable the veto
    trk3 = CondensateTracker()
    for i in range(400):
        v = rng.standard_normal(d) * 0.9
        if rng.random() < 0.7:
            v = v + machine_dir * rng.uniform(3.0, 4.5)
        if rng.random() < 0.25:            # impulsive human activity
            v = v + rng.standard_normal(d) * rng.uniform(4.0, 9.0)
        trk3.observe_ambient(v)
    snap = trk3.snapshot()
    verdict3 = trk3.evaluate_transient(machine_dir * 3.5 + trk3._fit["mu"])
    ok("heavy tails (humans) decohere the veto",
       trk3.humans_present and not verdict3["veto"],
       f"kurt={snap.get('kurtosis', 0):.1f} veto={verdict3['veto']}")
    # 6) rank-1 projector removes the machine direction
    v = machine_dir * 2.0
    exc = trk2.excise(v)
    ok("rank-1 projector kills ground-state component",
       float(np.linalg.norm(exc)) < 0.35 * float(np.linalg.norm(v)),
       f"|exc|/|v|={np.linalg.norm(exc) / np.linalg.norm(v):.2f}")
    # 7) kurtosis helper sanity
    ok("gaussian kurtosis ~ 0", abs(_excess_kurtosis(rng.standard_normal(4000))) < 0.3)
    lap = rng.laplace(0, 1, 4000)
    ok("laplace kurtosis ~ 3", abs(_excess_kurtosis(lap) - 3.0) < 0.5,
       f"{_excess_kurtosis(lap):.2f}")


def test_pattern():
    print("[pattern]")
    pe = PatternEngine()
    t0 = 100.0
    evs = [ImpactEvent(t_mono=t0 + i * 0.6, confidence=80.0,
                       label="structural_tap", telemetry={}) for i in range(3)]
    alerts = [pe.register_tap(e) for e in evs]
    ok("fires exactly on 3rd", sum(a is not None for a in alerts) == 1)
    a = alerts[-1]
    ok("avg conf", abs(a.avg_conf - 80.0) < 1e-6)
    ok("cadence mean ~0.6", abs(a.cadence_s[1] - 0.6) < 0.05)
    # cooldown: immediate 4th burst should NOT alert
    pe2 = PatternEngine()
    for e in evs[:3]:
        pe2.register_tap(e)
    a2 = pe2.register_tap(ImpactEvent(t_mono=t0 + 2.6, confidence=90,
                                      label="structural_tap", telemetry={}))
    ok("cooldown suppresses immediate re-alert", a2 is None)


def test_briefing():
    print("[briefing]")
    alert = DistressAlert(t_trigger=1.0, n_taps=3, avg_conf=82.4, min_conf=76.1,
                           cadence_s=(0.55, 0.62, 0.11), tap_times=[1, 2, 3])
    text = gen_briefing(alert, BriefingContext())
    for needle in ("AI RESCUE INTELLIGENCE BRIEFING", "Building B, Grid Sector 4",
                   "82.4%", "USAR Team 7", "RECOMMENDED ACTIONS", "burial depth"):
        ok("contains: " + needle[:30], needle in text)


def test_persistence():
    print("[persistence]")
    with tempfile.TemporaryDirectory() as d:
        store = EventStore(Path(d) / "t.db")
        ev = ImpactEvent(t_mono=1.0, confidence=77.5, label="structural_tap",
                         telemetry={"centroid_hz": 600, "flatness": 0.2, "zcr": 0.05,
                                    "band_ratio": 0.4, "onset_density": 0.1,
                                    "peak": 0.4},
                         feature_vector=np.zeros(18, dtype=np.float32))
        store.log_tap(ev)
        store.log_alert(DistressAlert(1.0, 3, 80, 70, (0.5, 0.6, 0.1), [1, 2, 3]),
                        "briefing text")
        c = store.counts()
        ok("roundtrip", c["taps"] == 1 and c["alerts"] == 1)
        store.close()


def test_processor_and_classifier():
    print("[processor+classifier]")
    clf = AcousticClassifier()
    ok("classifier loads (or documented fallback)", clf.available or clf.last_error)
    sp = SignalProcessor(classifier=clf, pattern=PatternEngine())
    rng = np.random.default_rng(9)
    quiet = 0.001 * rng.standard_normal(int(0.15 * SAMPLE_RATE))
    f = sp.process_chunk(quiet)
    ok("quiet chunk ignored", f["event"] is None and not f["tap_verified"])
    ok("BEC present in frame", "bec" in f and f["bec"] is not None)
    tap_clip, _ = make_structural_tap_clip(np.random.default_rng(10), n_taps=3)
    # feed a loud tap segment
    seg = tap_clip[: int(0.15 * SAMPLE_RATE)]
    seg = (seg / max(np.max(np.abs(seg)), 1e-9) * 0.6).astype(np.float32)
    f = sp.process_chunk(seg)
    ok("loud transient gated in", f["event"] is not None)
    ok("confidence in range", 0 <= f["confidence"] <= 100)


def _run_sos(proc, clip, gain=0.7):
    """Feed a clip through the processor chunk by chunk; return the alert."""
    win = int(0.15 * SAMPLE_RATE)
    fired = None
    for i in range(0, len(clip) - win, win):
        chunk = (clip[i:i + win] / max(1e-9, np.max(np.abs(clip))) * gain).astype(np.float32)
        f = proc.process_chunk(chunk)
        if f["alert"] is not None:
            fired = f["alert"]
            break
    return fired


def test_end_to_end_scenario():
    print("[scenario: 3-tap SOS -> alert -> briefing]")
    rng = np.random.default_rng(42)
    clf = AcousticClassifier()
    proc = SignalProcessor(classifier=clf, pattern=PatternEngine())
    tap_clip, positions = make_structural_tap_clip(rng, n_taps=3)
    fired = _run_sos(proc, tap_clip)
    ok("distress alert fired", fired is not None)
    if fired:
        ok(">=3 taps", fired.n_taps >= 3)
        text = gen_briefing(fired, BriefingContext())
        ok("briefing generated", "AI RESCUE INTELLIGENCE BRIEFING" in text)


def test_shouting_robustness():
    print("[scenario: 3-tap SOS buried in SHOUTING -> alert (v3 headline)]")
    rng = np.random.default_rng(77)
    clf = AcousticClassifier()
    proc = SignalProcessor(classifier=clf, pattern=PatternEngine())
    # tap clip that also carries a loud shouting bed (35% of positives do)
    tap_clip, positions = make_structural_tap_clip(rng, n_taps=3, with_voice=True)
    # extra shouting mixed ON TOP at 0 dB SNR-equivalent gain
    shout = _voice_segment(rng, len(tap_clip) / SAMPLE_RATE, n_voices=2, shout=True)
    tap_rms = float(np.sqrt(np.mean(tap_clip ** 2)))
    noisy = tap_clip + shout * (tap_rms * 0.9)
    fired = _run_sos(proc, noisy)
    ok("alert fires despite shouting bed", fired is not None)
    if fired:
        text = gen_briefing(fired, BriefingContext())
        ok("briefing generated under shouting", "AI RESCUE INTELLIGENCE BRIEFING" in text)
    # and shouting alone must NOT fire the pattern engine
    proc2 = SignalProcessor(classifier=AcousticClassifier(), pattern=PatternEngine())
    shout_only = _voice_segment(np.random.default_rng(78), 6.0, n_voices=2, shout=True)
    fired2 = _run_sos(proc2, shout_only, gain=0.9)
    ok("shouting alone does not fire distress alert", fired2 is None)


if __name__ == "__main__":
    test_features()
    test_corpus()
    test_bec()
    test_pattern()
    test_briefing()
    test_persistence()
    test_processor_and_classifier()
    test_end_to_end_scenario()
    test_shouting_robustness()
    print(f"\nALL {PASS} CHECKS PASSED")
