# GhostTrace Generalization Ledger

| dataset | detected | true | match | thr | infected MAD | margin | clean MAD | clean margin | IoU | GT ASR pre | GT ASR post | CA delta | cure method | runtime | verdict |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| FashionMNIST | - | - | - | - | - | - | - | - | - | - | - | - | - | 609s/900s | FAIL(clean_control_flagged;post_cure_gt_asr>=0.15) |

_Verdict gates: infected flagged, class match, clean control unflagged, post-cure GT ASR < 15%. Per-dataset acceptance floors (CA, runtime) live in each config and are enforced by run_smoke_test.py._