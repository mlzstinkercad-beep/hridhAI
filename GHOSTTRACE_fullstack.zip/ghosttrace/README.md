# GHOSTTRACE
Neural Network Forensics & Backdoor Detection System — hackathon MVP.

## What is included
- Gradio command-centre UI.
- Modular PyTorch backend for CIFAR-10 experiments.
- Controlled fixed-patch poisoning laboratory.
- Clean-model baseline evaluation.
- Candidate-target ranking using trigger optimisation and triggered validation.
- Trigger reconstruction, mitigation experiments, SQLite experiment history and JSON/HTML reports.
- Safe checkpoint loading (`weights_only=True`) and trusted architecture construction. Uploaded Python/model code is never executed.

> Research prototype only. A low anomaly score is not proof that a model is safe. Detection is limited to the tested threat model.

## Quick start (Python 3.10–3.12 recommended)
```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
Open the local Gradio URL printed in the terminal.

## First run
1. Open **Attack Laboratory** and train a clean and poisoned CIFAR-10 CNN.
2. Open **Model Scanner** and select the generated backdoored checkpoint.
3. Run detection/reconstruction. The scanner is not given trigger location or target class.
4. Validate candidates, optionally run mitigation, and export the report.

CIFAR-10 is downloaded by torchvision on first use. A GPU is recommended; CPU mode is supported but slower.

## Project structure
```text
ghosttrace/
├── app.py
├── requirements.txt
├── configs/default.json
├── src/ghosttrace/
│   ├── config.py
│   ├── db.py
│   ├── orchestrator.py
│   ├── data/datasets.py
│   ├── models/cnn.py
│   ├── models/loader.py
│   ├── attacks/poison.py
│   ├── analysis/behaviour.py
│   ├── detection/engine.py
│   ├── reconstruction/trigger.py
│   ├── validation/validate.py
│   ├── mitigation/repair.py
│   ├── reporting/report.py
│   └── app/ui.py
└── tests/
```

## Security notes
- Only state-dict checkpoints for the built-in `small_cnn` architecture are accepted.
- Never load untrusted `.pt` files with unrestricted pickle deserialization.
- For a real deployment, run training/scanning jobs in isolated workers with CPU, memory, time and filesystem limits; add authentication and upload-size limits.
