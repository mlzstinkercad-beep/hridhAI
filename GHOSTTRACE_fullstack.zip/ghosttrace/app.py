from src.ghosttrace.app.ui import build_app

if __name__ == "__main__":
    demo = build_app()
    demo.queue(default_concurrency_limit=1).launch(show_error=True)
