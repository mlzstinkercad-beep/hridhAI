import torch
from torch.utils.data import Dataset

class PoisonedDataset(Dataset):
    def __init__(self, base, rate=0.05, target=0, size=3, value=1.0, seed=42):
        self.base=base; self.target=target; self.size=size; self.value=value
        g=torch.Generator().manual_seed(seed)
        n=int(len(base)*rate)
        self.poisoned=set(torch.randperm(len(base),generator=g)[:n].tolist())
    def __len__(self): return len(self.base)
    def __getitem__(self,idx):
        x,y=self.base[idx]
        if idx in self.poisoned:
            x=x.clone(); x[:,-self.size:,-self.size:]=self.value
            y=self.target
        return x,y

def add_trigger(x, mask, pattern):
    return x*(1-mask)+pattern*mask
