import sqlite3, json
from pathlib import Path
from datetime import datetime, timezone

DB_PATH = Path("artifacts/ghosttrace.sqlite3")
def connect():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB_PATH)
    con.execute('''CREATE TABLE IF NOT EXISTS experiments (
        id TEXT PRIMARY KEY, created_at TEXT, status TEXT, model_name TEXT,
        metrics_json TEXT, config_json TEXT, report_path TEXT)''')
    con.commit()
    return con

def save_experiment(record):
    con=connect()
    con.execute("INSERT OR REPLACE INTO experiments VALUES (?,?,?,?,?,?,?)", (
        record["experiment_id"], datetime.now(timezone.utc).isoformat(),
        record.get("status","completed"), record.get("model_name",""),
        json.dumps(record.get("metrics",{})), json.dumps(record.get("config",{})),
        record.get("report_path","")))
    con.commit(); con.close()

def history(limit=50):
    con=connect()
    rows=con.execute("SELECT id,created_at,status,model_name,metrics_json FROM experiments ORDER BY created_at DESC LIMIT ?",(limit,)).fetchall()
    con.close()
    return [{"experiment_id":r[0],"created_at":r[1],"status":r[2],"model_name":r[3],"metrics":json.loads(r[4])} for r in rows]
