import torch
@torch.no_grad()
def evaluate(model, loader, device):
    model.eval(); correct=total=0; class_counts={}
    for x,y in loader:
        x,y=x.to(device),y.to(device); pred=model(x).argmax(1)
        correct+=(pred==y).sum().item(); total+=y.numel()
        for c in pred.cpu().tolist(): class_counts[c]=class_counts.get(c,0)+1
    return {"clean_accuracy":correct/max(total,1),"samples":total,
            "prediction_distribution":class_counts}
