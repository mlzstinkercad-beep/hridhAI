import torch
from .cnn import SmallCNN

SUPPORTED={"small_cnn":SmallCNN}
def build_model(architecture="small_cnn", device=None):
    if architecture not in SUPPORTED: raise ValueError("Unsupported architecture")
    return SUPPORTED[architecture]().to(device or ("cuda" if torch.cuda.is_available() else "cpu"))

def safe_load_state_dict(path, model, device="cpu"):
    # Checkpoint must be a tensor-only state_dict. Never execute uploaded model code.
    try: state=torch.load(path,map_location=device,weights_only=True)
    except TypeError: raise RuntimeError("This PyTorch version lacks safe weights_only loading; upgrade PyTorch.")
    if isinstance(state,dict) and "state_dict" in state: state=state["state_dict"]
    if not isinstance(state,dict) or not all(torch.is_tensor(v) for v in state.values()):
        raise ValueError("Expected a tensor-only state_dict checkpoint.")
    model.load_state_dict(state,strict=True)
    return model
