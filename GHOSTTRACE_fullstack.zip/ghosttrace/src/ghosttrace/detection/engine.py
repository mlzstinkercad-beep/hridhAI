import torch
from ..reconstruction.trigger import reconstruct_trigger

def rank_targets(model, clean_batch, device, steps=60, lr=0.1, size=3):
    results=[]
    for target in range(10):
        candidate=reconstruct_trigger(model,target,clean_batch,device,steps,lr,size)
        with torch.no_grad():
            x=clean_batch[:min(64,len(clean_batch))].to(device)
            patched=x*(1-candidate["mask"])+candidate["pattern"]*candidate["mask"]
            asr=(model(patched).argmax(1)==target).float().mean().item()
        results.append({"target_class":target,"score":asr,
                        "optimisation_loss":candidate["final_loss"]})
    return sorted(results,key=lambda r:r["score"],reverse=True)
