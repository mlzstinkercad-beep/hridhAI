import torch
from torch.utils.data import DataLoader, Subset
from torchvision import datasets, transforms

MEAN=(0.4914,0.4822,0.4465); STD=(0.2470,0.2435,0.2616)
CLASS_NAMES=("airplane","automobile","bird","cat","deer","dog","frog","horse","ship","truck")

def get_cifar10(batch_size=128, root="data", workers=2):
    tf=transforms.Compose([transforms.ToTensor(),transforms.Normalize(MEAN,STD)])
    train=datasets.CIFAR10(root=root,train=True,download=True,transform=tf)
    test=datasets.CIFAR10(root=root,train=False,download=True,transform=tf)
    return (DataLoader(train,batch_size=batch_size,shuffle=True,num_workers=workers),
            DataLoader(test,batch_size=batch_size,shuffle=False,num_workers=workers), train, test)

def denormalize(x):
    mean=torch.tensor(MEAN,device=x.device).view(1,3,1,1)
    std=torch.tensor(STD,device=x.device).view(1,3,1,1)
    return (x*std+mean).clamp(0,1)
