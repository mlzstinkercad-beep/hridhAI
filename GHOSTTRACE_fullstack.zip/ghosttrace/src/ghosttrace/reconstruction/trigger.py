import torch
import torch.nn.functional as F

def reconstruct_trigger(model, target, clean_batch, device, steps=120, lr=0.1, size=3):
    # Optimises a bounded universal patch at a fixed corner; scanner receives no trigger metadata.
    # This MVP tests a documented fixed-patch threat model, not arbitrary trigger families.
    model.eval()
    x=clean_batch[:min(64,len(clean_batch))].to(device)
    mask=torch.zeros((1,1,32,32),device=device); mask[:,:,-size:,-size:]=1
    pattern=torch.nn.Parameter(torch.full((1,3,32,32),0.5,device=device))
    opt=torch.optim.Adam([pattern],lr=lr)
    history=[]
    for step in range(steps):
        opt.zero_grad()
        patched=x*(1-mask)+pattern.clamp(0,1)*mask
        logits=model(patched)
        loss=F.cross_entropy(logits,torch.full((len(x),),target,device=device,dtype=torch.long))
        loss.backward(); opt.step()
        history.append(float(loss.detach().cpu()))
    return {"mask":mask.detach(),"pattern":pattern.detach().clamp(0,1),
            "loss_history":history,"final_loss":history[-1]}
