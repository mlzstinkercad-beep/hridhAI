from dataclasses import dataclass, asdict
import random, numpy as np, torch

@dataclass
class ExperimentConfig:
    seed: int = 42
    batch_size: int = 128
    epochs: int = 3
    learning_rate: float = 1e-3
    poison_rate: float = 0.05
    target_class: int = 0
    trigger_size: int = 3
    trigger_value: float = 1.0
    scan_steps: int = 120
    scan_lr: float = 0.1
    validation_samples: int = 500

    def seed_all(self):
        random.seed(self.seed); np.random.seed(self.seed); torch.manual_seed(self.seed)
        if torch.cuda.is_available(): torch.cuda.manual_seed_all(self.seed)

    def to_dict(self): return asdict(self)
