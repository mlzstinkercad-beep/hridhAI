import torch
@torch.no_grad()
def validate_trigger(model, loader, candidate, device, limit=500):
    model.eval(); success=seen=0
    mask,pattern=candidate["mask"],candidate["pattern"]
    for x,y in loader:
        x=x.to(device); patched=x*(1-mask)+pattern*mask
        success+=(model(patched).argmax(1)==candidate["target_class"]).sum().item()
        seen+=len(x)
        if seen>=limit: break
    return {"attack_success_rate":success/max(seen,1),"samples":seen}
