import uuid, time, platform
from pathlib import Path
import torch
from torch.utils.data import DataLoader
from .config import ExperimentConfig
from .data.datasets import get_cifar10
from .models.loader import build_model, safe_load_state_dict
from .attacks.poison import PoisonedDataset
from .analysis.behaviour import evaluate
from .detection.engine import rank_targets
from .reconstruction.trigger import reconstruct_trigger
from .validation.validate import validate_trigger
from .mitigation.repair import clean_finetune
from .reporting.report import write_report
from .db import save_experiment

DEVICE="cuda" if torch.cuda.is_available() else "cpu"
ART=Path("artifacts"); ART.mkdir(exist_ok=True)

def train_lab(cfg: ExperimentConfig, progress=lambda x:None):
    cfg.seed_all()
    train_loader,test_loader,train_ds,test_ds=get_cifar10(cfg.batch_size)
    clean=build_model(device=DEVICE)
    opt=torch.optim.Adam(clean.parameters(),lr=cfg.learning_rate)
    loss_fn=torch.nn.CrossEntropyLoss()
    clean.train()
    for ep in range(cfg.epochs):
        total=0
        for x,y in train_loader:
            x,y=x.to(DEVICE),y.to(DEVICE); opt.zero_grad()
            loss=loss_fn(clean(x),y); loss.backward(); opt.step(); total+=loss.item()
        progress(f"Clean model epoch {ep+1}/{cfg.epochs} | loss {total/max(len(train_loader),1):.4f}")
    torch.save(clean.state_dict(),ART/"clean_small_cnn.pt")
    poisoned=PoisonedDataset(train_ds,cfg.poison_rate,cfg.target_class,cfg.trigger_size,cfg.trigger_value,cfg.seed)
    poison_loader=DataLoader(poisoned,batch_size=cfg.batch_size,shuffle=True,num_workers=2)
    backdoor=build_model(device=DEVICE); opt=torch.optim.Adam(backdoor.parameters(),lr=cfg.learning_rate)
    backdoor.train()
    for ep in range(cfg.epochs):
        for x,y in poison_loader:
            x,y=x.to(DEVICE),y.to(DEVICE); opt.zero_grad()
            loss=loss_fn(backdoor(x),y); loss.backward(); opt.step()
        progress(f"Backdoored model epoch {ep+1}/{cfg.epochs}")
    torch.save(backdoor.state_dict(),ART/"backdoored_small_cnn.pt")
    clean_metrics=evaluate(clean,test_loader,DEVICE)
    backdoor_metrics=evaluate(backdoor,test_loader,DEVICE)
    return {"clean_path":str(ART/"clean_small_cnn.pt"),"backdoor_path":str(ART/"backdoored_small_cnn.pt"),
            "clean_metrics":clean_metrics,"backdoor_metrics":backdoor_metrics,
            "message":"Training completed. Metrics are measured on the CIFAR-10 test split."}

def scan_model(checkpoint, cfg: ExperimentConfig, progress=lambda x:None):
    cfg.seed_all()
    _,test_loader,_,_=get_cifar10(cfg.batch_size)
    model=build_model(device=DEVICE); safe_load_state_dict(checkpoint,model,DEVICE)
    clean_metrics=evaluate(model,test_loader,DEVICE)
    batch=next(iter(test_loader))[0][:64]
    progress("Ranking all 10 candidate target classes...")
    ranked=rank_targets(model,batch,DEVICE,cfg.scan_steps,cfg.scan_lr,cfg.trigger_size)
    best=ranked[0]
    progress(f"Reconstructing candidate for target class {best['target_class']}...")
    candidate=reconstruct_trigger(model,best["target_class"],batch,DEVICE,cfg.scan_steps,cfg.scan_lr,cfg.trigger_size)
    candidate["target_class"]=best["target_class"]
    validation=validate_trigger(model,test_loader,candidate,DEVICE,cfg.validation_samples)
    exp_id=str(uuid.uuid4())[:8]
    record={"experiment_id":exp_id,"status":"completed","model_name":Path(checkpoint).name,
        "seed":cfg.seed,"dataset":"CIFAR-10","architecture":"small_cnn",
        "config":cfg.to_dict(),"metrics":{"clean_accuracy":clean_metrics["clean_accuracy"],
        "candidate_target":best["target_class"],"candidate_score":best["score"],
        "attack_success_rate":validation["attack_success_rate"],"validation_samples":validation["samples"]},
        "ranked_targets":ranked,"loss_history":candidate["loss_history"],
        "limitations":"Fixed-patch, fixed-corner reconstruction prototype. Candidate score is not proof of a backdoor. Results apply only to this model, dataset and configuration.",
        "software":{"python":platform.python_version(),"torch":torch.__version__}}
    jp,hp=write_report(record); record["report_path"]=jp; save_experiment(record)
    return record,candidate,clean_metrics
