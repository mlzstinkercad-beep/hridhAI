import gradio as gr
import pandas as pd
import plotly.express as px
from pathlib import Path
from ..config import ExperimentConfig
from ..orchestrator import train_lab, scan_model
from ..db import history

CSS = """
.gradio-container {background:#080d18 !important;color:#e8edf7 !important}
#hero {background:linear-gradient(120deg,#111d32,#102b32);border:1px solid #263a50;border-radius:18px;padding:22px}
.panel {border:1px solid #26364b;border-radius:14px}
"""

def cfg_from(seed,epochs,poison,target,size,steps,lr):
    return ExperimentConfig(seed=int(seed),epochs=int(epochs),poison_rate=float(poison),
        target_class=int(target),trigger_size=int(size),scan_steps=int(steps),scan_lr=float(lr))

def run_lab(seed,epochs,poison,target,size,progress=gr.Progress()):
    cfg=cfg_from(seed,epochs,poison,target,size,100,.1)
    try:
        result=train_lab(cfg,lambda msg: progress(0.5,desc=msg))
        return result["message"],result["clean_path"],result["backdoor_path"],pd.DataFrame([
            {"Model":"Clean","Clean accuracy":result["clean_metrics"]["clean_accuracy"]},
            {"Model":"Backdoored","Clean accuracy":result["backdoor_metrics"]["clean_accuracy"]}])
    except Exception as e: return f"ERROR: {e}",None,None,pd.DataFrame()

def run_scan(model_file,seed,steps,size,progress=gr.Progress()):
    if not model_file: return "Upload or select a checkpoint first.",{},pd.DataFrame(),None
    cfg=ExperimentConfig(seed=int(seed),scan_steps=int(steps),trigger_size=int(size))
    try:
        record,candidate,base=scan_model(model_file,cfg,lambda msg:progress(0.5,desc=msg))
        table=pd.DataFrame(record["ranked_targets"])
        return ((f"Investigation {record['experiment_id']} completed. Candidate class: {record['metrics']['candidate_target']}. "
                 f"Candidate score: {record['metrics']['candidate_score']:.3f}. "
                 f"Validation ASR: {record['metrics']['attack_success_rate']:.3f}. "
                 f"Clean accuracy: {record['metrics']['clean_accuracy']:.3f}. "
                 "Interpretation: candidate evidence requires human review; it is not proof."),
                record, table, record["report_path"])
    except Exception as e: return f"ERROR: {e}",{},pd.DataFrame(),None

def history_df():
    rows=history()
    return pd.DataFrame([{"ID":r["experiment_id"],"Created":r["created_at"],"Status":r["status"],
        "Model":r["model_name"],"Metrics":str(r["metrics"])} for r in rows])

def build_app():
    with gr.Blocks(title="GHOSTTRACE | Neural Network Forensics",css=CSS,theme=gr.themes.Base(
        primary_hue="teal",secondary_hue="slate",neutral_hue="slate")) as demo:
        gr.HTML("""<div id="hero"><div style="letter-spacing:4px;color:#6ce0d0;font-size:12px">AI SECURITY / MODEL FORENSICS</div>
        <h1 style="font-size:36px;margin:8px 0">GHOSTTRACE</h1>
        <div style="color:#a8b8cc">INVESTIGATE · RECONSTRUCT · VALIDATE · MITIGATE</div>
        <p style="color:#8da2b9">A controlled research workstation for investigating image-classification backdoors.</p></div>""")
        with gr.Tabs():
            with gr.Tab("Command Centre"):
                gr.Markdown("### Investigation overview")
                hist=gr.Dataframe(value=history_df(),label="Recent investigations",interactive=False)
                refresh=gr.Button("Refresh history")
                refresh.click(history_df,outputs=hist)
                gr.Markdown("**Scope:** CIFAR-10 / built-in SmallCNN / fixed-patch research threat model.")
            with gr.Tab("Attack Laboratory"):
                gr.Markdown("### Train controlled reference models\nCreates clean and deliberately poisoned models for ground-truth evaluation.")
                with gr.Row():
                    seed=gr.Number(value=42,label="Random seed",precision=0)
                    epochs=gr.Slider(1,20,value=3,step=1,label="Training epochs")
                    poison=gr.Slider(.01,.2,value=.05,step=.01,label="Poison rate")
                with gr.Row():
                    target=gr.Dropdown(choices=list(range(10)),value=0,label="Poison target class")
                    size=gr.Slider(2,6,value=3,step=1,label="Trigger size (pixels)")
                train_btn=gr.Button("TRAIN CLEAN + BACKDOORED MODELS",variant="primary")
                train_status=gr.Textbox(label="Training log",lines=3)
                with gr.Row():
                    clean_file=gr.File(label="Clean checkpoint")
                    backdoor_file=gr.File(label="Backdoored checkpoint")
                lab_metrics=gr.Dataframe(label="Measured clean accuracy")
                train_btn.click(run_lab,[seed,epochs,poison,target,size],
                    [train_status,clean_file,backdoor_file,lab_metrics])
            with gr.Tab("Model Scanner"):
                gr.Markdown("### Neural autopsy / ghost hunter\nThe scanner receives model weights and clean reference data. Trigger metadata is not passed to the scanner.")
                model=gr.File(label="PyTorch state-dict checkpoint (.pt)",file_types=[".pt"])
                with gr.Row():
                    scan_seed=gr.Number(value=42,label="Seed",precision=0)
                    scan_steps=gr.Slider(20,300,value=120,step=10,label="Optimisation steps")
                    scan_size=gr.Slider(2,6,value=3,step=1,label="Candidate patch size")
                scan_btn=gr.Button("START FORENSIC INVESTIGATION",variant="primary")
                scan_status=gr.Textbox(label="Investigation status",lines=4)
                record=gr.JSON(label="Forensic evidence")
                ranking=gr.Dataframe(label="Suspicious target-class ranking")
                report=gr.File(label="JSON forensic report")
                scan_btn.click(run_scan,[model,scan_seed,scan_steps,scan_size],
                    [scan_status,record,ranking,report])
            with gr.Tab("Neural Repair"):
                gr.Markdown("""### Mitigation status
The backend includes clean fine-tuning on a copy of the model. The current UI milestone exposes the repair engine as a module; connect it to a selected investigation after validating the detection pipeline. Always compare post-repair clean accuracy and ASR before claiming remediation.""")
                gr.Code(value="from src.ghosttrace.mitigation.repair import clean_finetune",language="python")
            with gr.Tab("Forensic Report"):
                gr.Markdown("""### Evidence and reproducibility
Reports are saved under `artifacts/reports/` as JSON and HTML. Each record includes model identity, configuration, ranked targets, measured clean accuracy, candidate validation ASR, software version and explicit limitations.""")
                gr.Markdown("Never interpret an anomaly score as proof of compromise or a clean scan as certification of safety.")
        gr.Markdown("<div style='color:#6f829b;text-align:center;padding:18px'>GHOSTTRACE v1.0 · RESEARCH PROTOTYPE · NOT A MODEL-SAFETY CERTIFICATION</div>")
    return demo
