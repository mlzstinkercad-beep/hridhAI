import copy, torch
from torch import nn

def clean_finetune(model, train_loader, device, epochs=1, lr=1e-4):
    repaired=copy.deepcopy(model).to(device)
    opt=torch.optim.Adam(repaired.parameters(),lr=lr)
    loss_fn=nn.CrossEntropyLoss()
    repaired.train()
    for _ in range(epochs):
        for x,y in train_loader:
            x,y=x.to(device),y.to(device); opt.zero_grad()
            loss=loss_fn(repaired(x),y); loss.backward(); opt.step()
    return repaired
