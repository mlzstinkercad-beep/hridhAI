import json
from pathlib import Path
from html import escape

def write_report(record):
    out=Path("artifacts/reports"); out.mkdir(parents=True,exist_ok=True)
    stem=record["experiment_id"]
    jp=out/f"{stem}.json"; hp=out/f"{stem}.html"
    jp.write_text(json.dumps(record,indent=2,default=str))
    rows="".join(f"<tr><th>{escape(str(k))}</th><td>{escape(str(v))}</td></tr>" for k,v in record.get("metrics",{}).items())
    hp.write_text(f'''<!doctype html><html><head><meta charset="utf-8"><title>GHOSTTRACE report</title>
    <style>body{{font:15px system-ui;background:#0b1020;color:#e8edf7;padding:32px}}table{{border-collapse:collapse}}td,th{{padding:10px;border:1px solid #34405a;text-align:left}}h1{{color:#70e1d1}}</style></head>
    <body><h1>GHOSTTRACE / FORENSIC REPORT</h1><p>Experiment: {escape(stem)}</p><p>Model: {escape(record.get("model_name",""))}</p>
    <h2>Measured metrics</h2><table>{rows}</table><h2>Limitations</h2><p>{escape(record.get("limitations",""))}</p></body></html>''')
    return str(jp),str(hp)
