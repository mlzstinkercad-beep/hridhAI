import torch
from src.ghosttrace.models.loader import build_model
def test_forward_shape():
    model=build_model("small_cnn","cpu")
    assert model(torch.randn(2,3,32,32)).shape==(2,10)
