import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "SURAKSHA-AI · Multi-Hazard Guardian for India",
  description:
    "HridhAI 2026 · Track 2 (AI That Protects). Multi-hazard early warning and response: phone-seismometer quake detection, satellite fire hotspots, cyclone and flood warnings — with signed official alerts, AI triage dispatch and mesh relay when towers go down.",
  keywords: [
    "SURAKSHA-AI",
    "disaster management India",
    "early warning system",
    "phone seismometer",
    "AI triage",
    "HridhAI 2026",
  ],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
