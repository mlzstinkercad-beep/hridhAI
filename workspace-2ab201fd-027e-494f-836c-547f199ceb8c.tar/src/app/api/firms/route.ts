import { NextResponse } from "next/server";
import type { FireHotspot } from "@/lib/types";

export const revalidate = 600;

/**
 * NASA FIRMS VIIRS active-fire layer.
 * If FIRMS_MAP_KEY env is set we proxy the real near-real-time feed;
 * otherwise we return clearly-labelled simulated hotspots so the demo
 * never breaks on stage. Honest data-labelling is part of the design.
 */
export async function GET() {
  const key = process.env.FIRMS_MAP_KEY;
  if (key) {
    try {
      // Telangana + AP bbox: 77.0,15.0,82.0,19.5
      const res = await fetch(
        `https://firms.modaps.eosdis.nasa.gov/api/area/csv/${key}/VIIRS_SNPP_NRT/77.0,15.0,82.0,19.5/1`,
        { next: { revalidate: 600 }, signal: AbortSignal.timeout(8000) }
      );
      const csv = await res.text();
      const lines = csv.trim().split("\n");
      if (lines.length > 1 && !lines[0].startsWith("invalid")) {
        const hotspots: FireHotspot[] = lines.slice(1, 200).map((line, i) => {
          const c = line.split(",");
          return {
            id: `firms-${i}`,
            lat: parseFloat(c[0]),
            lng: parseFloat(c[1]),
            confidence: (c[8] ?? "l").trim(),
            frp: parseFloat(c[11] ?? "0") || 0,
            acquired: `${c[5] ?? ""} ${c[6] ?? ""} IST`,
            simulated: false,
          };
        });
        return NextResponse.json({ ok: true, source: "NASA FIRMS (live)", hotspots });
      }
    } catch {
      /* fall through to simulated */
    }
  }

  // Simulated hotspot cluster — Ananthagiri Hills, Vikarabad forest
  const origin = { lat: 17.332, lng: 78.098 };
  const hotspots: FireHotspot[] = Array.from({ length: 14 }, (_, i) => ({
    id: `sim-fh-${i}`,
    lat: origin.lat + (Math.random() - 0.5) * 0.06,
    lng: origin.lng + (Math.random() - 0.5) * 0.07,
    confidence: Math.random() > 0.3 ? "h" : "n",
    frp: 30 + Math.round(Math.random() * 170),
    acquired: "VIIRS 375m · recent pass",
    simulated: true,
  }));
  return NextResponse.json({ ok: true, source: "simulated (set FIRMS_MAP_KEY for live NASA data)", hotspots });
}
