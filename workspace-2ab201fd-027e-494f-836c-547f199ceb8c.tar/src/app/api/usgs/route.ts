import { NextResponse } from "next/server";
import type { UsgsQuake } from "@/lib/types";

export const revalidate = 300;

/**
 * Live USGS earthquake feed (M2.5+ past 24h), proxied server-side.
 * Proves the platform ingests REAL seismic data alongside phone sensors.
 */
export async function GET() {
  try {
    const res = await fetch(
      "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/2.5_day.geojson",
      { next: { revalidate: 300 }, signal: AbortSignal.timeout(8000) }
    );
    const j = (await res.json()) as {
      features: {
        id: string;
        properties: { mag: number | null; place: string | null; time: number };
        geometry: { coordinates: [number, number, number] };
      }[];
    };
    const quakes: UsgsQuake[] = j.features
      .filter((f) => typeof f.properties.mag === "number")
      .map((f) => ({
        id: f.id,
        mag: f.properties.mag ?? 0,
        place: f.properties.place ?? "—",
        time: f.properties.time,
        lat: f.geometry.coordinates[1],
        lng: f.geometry.coordinates[0],
        depth: f.geometry.coordinates[2],
      }))
      .sort((a, b) => b.mag - a.mag)
      .slice(0, 120);
    return NextResponse.json({ ok: true, count: quakes.length, quakes, fetchedAt: Date.now() });
  } catch {
    return NextResponse.json(
      { ok: false, count: 0, quakes: [], error: "USGS feed unreachable (sandbox network)" },
      { status: 200 }
    );
  }
}
