"use client";

import { useEffect } from "react";
import dynamic from "next/dynamic";
import TopBar from "@/components/TopBar";
import LoopRail from "@/components/LoopRail";
import StatsBar from "@/components/StatsBar";
import SeismoPanel from "@/components/SeismoPanel";
import AlertsFeed from "@/components/AlertsFeed";
import TriagePanel from "@/components/TriagePanel";
import { useSuraksha } from "@/lib/store";
import type { FireHotspot, UsgsQuake } from "@/lib/types";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const MapCanvas = dynamic(() => import("@/components/MapCanvas"), {
  ssr: false,
  loading: () => (
    <div className="flex h-full w-full items-center justify-center bg-zinc-950">
      <div className="flex flex-col items-center gap-2 text-zinc-500">
        <div className="h-6 w-6 animate-spin rounded-full border-2 border-amber-500 border-t-transparent" />
        <span className="text-xs">initialising command map…</span>
      </div>
    </div>
  ),
});

export default function Home() {
  // engine heartbeat — 1 tick per second
  useEffect(() => {
    const iv = setInterval(() => useSuraksha.getState().tick(), 1000);
    return () => clearInterval(iv);
  }, []);

  // pull real-world feeds once on load
  useEffect(() => {
    fetch("/api/usgs")
      .then((r) => r.json())
      .then((j: { ok: boolean; quakes: UsgsQuake[] }) => {
        if (j.ok && j.quakes.length) useSuraksha.getState().setUsgs(j.quakes);
      })
      .catch(() => {});
    fetch("/api/firms")
      .then((r) => r.json())
      .then((j: { ok: boolean; hotspots: FireHotspot[] }) => {
        if (j.ok && j.hotspots.length) useSuraksha.getState().setFirms(j.hotspots);
      })
      .catch(() => {});
  }, []);

  return (
    <div className="dark flex h-screen flex-col overflow-hidden bg-zinc-950 text-zinc-100">
      <TopBar />
      <LoopRail />

      {/* mobile: simple stacking; desktop: 3-column command center grid */}
      <main className="flex min-h-0 flex-1 flex-col gap-2 overflow-y-auto p-2 lg:grid lg:grid-cols-[320px_minmax(0,1fr)_380px] lg:overflow-hidden">
        <section
          aria-label="Sensor rail"
          className="order-2 flex shrink-0 flex-col overflow-hidden rounded-xl border border-white/10 bg-zinc-900/60 lg:order-1 lg:min-h-0"
        >
          <SeismoPanel />
        </section>

        <section
          aria-label="Live operations map"
          className="relative order-1 z-0 min-h-[46vh] shrink-0 overflow-hidden rounded-xl border border-white/10 lg:order-2 lg:min-h-0"
        >
          <MapCanvas />
        </section>

        <section
          aria-label="Alerts and dispatch"
          className="order-3 flex h-[75vh] shrink-0 flex-col overflow-hidden rounded-xl border border-white/10 bg-zinc-900/60 lg:h-auto lg:min-h-0"
        >
          <Tabs defaultValue="alerts" className="flex min-h-0 flex-1 flex-col">
            <TabsList className="mx-3 mt-3 grid grid-cols-2 bg-black/40">
              <TabsTrigger value="alerts" className="text-xs">
                Alerts &amp; authenticity
              </TabsTrigger>
              <TabsTrigger value="dispatch" className="text-xs">
                SOS &amp; dispatch
              </TabsTrigger>
            </TabsList>
            <TabsContent value="alerts" className="mt-0 min-h-0 flex-1 lg:overflow-hidden">
              <AlertsFeed />
            </TabsContent>
            <TabsContent value="dispatch" className="mt-0 min-h-0 flex-1 lg:overflow-hidden">
              <TriagePanel />
            </TabsContent>
          </Tabs>
        </section>
      </main>

      <StatsBar />

      <footer className="flex flex-wrap items-center justify-center gap-x-3 gap-y-0.5 border-t border-white/10 bg-black/50 px-3 py-1.5 text-center text-[10px] text-zinc-500">
        <span>
          <span className="font-semibold text-zinc-400">SURAKSHA-AI</span> ·
          HridhAI 2026 · Track 2: AI That Protects
        </span>
        <span className="hidden sm:inline">
          Observe → Analyse → Assess risk → Protect
        </span>
        <span>
          live feeds: USGS seismic · NASA FIRMS · IMD/INCOIS simulated alerts
        </span>
      </footer>
    </div>
  );
}
