"use client";

import "leaflet/dist/leaflet.css";
import { useEffect, useRef, useState } from "react";
import type * as LeafletNS from "leaflet";
import { useSuraksha } from "@/lib/store";
import { FLOOD_ZONES, CYCLONE_TRACK } from "@/lib/data";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import type { SosType } from "@/lib/types";

const SEV_COLOR: Record<string, string> = {
  P1: "#ef4444",
  P2: "#f97316",
  P3: "#eab308",
};

const ICONS: Record<string, string> = {
  ambulance: `<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 8h11v9H3z"/><path d="M14 10h3.5L20 13v4h-6"/><circle cx="7" cy="18.5" r="1.6"/><circle cx="16.5" cy="18.5" r="1.6"/><path d="M7.5 11v3M6 12.5h3"/></svg>`,
  rescue: `<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l8 3v5c0 5-3.4 8.6-8 10-4.6-1.4-8-5-8-10V6z"/><path d="M8.5 12l2.5 2.5 4.5-4.5"/></svg>`,
  fire: `<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3c1 3-3 4.5-3 8a3 3 0 0 0 6 0c0-1-.5-2-1-2.5C15.5 10 17 12 17 14a5 5 0 0 1-10 0c0-4.5 4-7.5 5-11z"/></svg>`,
  hospital: `<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>`,
  quake: `<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12h4l2-7 4 14 2-7h8"/></svg>`,
};

function sosIcon(sev: string, hops: number): LeafletNS.DivIconOptions["html"] {
  const c = SEV_COLOR[sev] ?? "#eab308";
  return `<div class="mk-sos" style="--mk:${c}"><span>${sev}</span>${
    hops > 0 ? '<i class="mk-hops">mesh</i>' : ""
  }</div>`;
}

function unitIcon(kind: string, status: string): string {
  const color =
    kind === "ambulance" ? "#f59e0b" : kind === "rescue" ? "#22d3ee" : "#fb923c";
  const active = status === "enroute" || status === "onsite";
  return `<div class="mk-unit" style="--mk:${color};${active ? "box-shadow:0 0 0 3px rgba(255,255,255,.18)" : ""}">${ICONS[kind]}</div>`;
}

export default function MapCanvas() {
  const rootRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<LeafletNS.Map | null>(null);
  const LRef = useRef<typeof LeafletNS | null>(null);
  const groups = useRef<Record<string, LeafletNS.LayerGroup>>({});
  const [ready, setReady] = useState(false);
  const [sosDraft, setSosDraft] = useState<{ lat: number; lng: number } | null>(null);
  const [sosType, setSosType] = useState<SosType>("medical");
  const [sosNote, setSosNote] = useState("");

  const hazards = useSuraksha((s) => s.hazards);
  const soss = useSuraksha((s) => s.soss);
  const responders = useSuraksha((s) => s.responders);
  const hospitals = useSuraksha((s) => s.hospitals);
  const safeZones = useSuraksha((s) => s.safeZones);
  const fireHotspots = useSuraksha((s) => s.fireHotspots);
  const usgsQuakes = useSuraksha((s) => s.usgsQuakes);
  const showUsgs = useSuraksha((s) => s.showUsgs);
  const scenario = useSuraksha((s) => s.scenario);
  const viewCommand = useSuraksha((s) => s.viewCommand);
  const sosArmed = useSuraksha((s) => s.sosArmed);
  const addCitizenSos = useSuraksha((s) => s.addCitizenSos);

  // ---- init map ----
  useEffect(() => {
    let cancelled = false;
    (async () => {
      const L = (await import("leaflet")) as typeof LeafletNS;
      if (cancelled || !rootRef.current || mapRef.current) return;
      LRef.current = L;
      const map = L.map(rootRef.current, {
        center: [17.4126, 78.4392],
        zoom: 11,
        zoomControl: false,
        attributionControl: true,
      });
      // Primary basemap: Esri World Dark Gray (free, no key). Sustained
      // failure (rate-limit / network hiccup) cycles sources:
      // Esri → OSM → Esri, at most one switch per 20 s, only when the
      // failing window has zero successful tile loads. Stage-proof.
      const TILE_SOURCES = [
        "https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Base/MapServer/tile/{z}/{y}/{x}",
        "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
        "https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Base/MapServer/tile/{z}/{y}/{x}",
      ];
      let tileStage = 0;
      let errCount = 0;
      let okCount = 0;
      let windowStart = Date.now();
      let lastFailover = 0;
      const base = L.tileLayer(TILE_SOURCES[0], {
        attribution: "© Esri · © OpenStreetMap contributors",
        maxZoom: 19,
      });
      const maybeFailover = () => {
        const now = Date.now();
        if (now - windowStart > 15_000) {
          windowStart = now;
          errCount = 0;
          okCount = 0;
          return;
        }
        if (
          errCount >= 10 &&
          okCount === 0 &&
          now - lastFailover > 20_000
        ) {
          tileStage = (tileStage + 1) % TILE_SOURCES.length;
          lastFailover = now;
          windowStart = now;
          errCount = 0;
          okCount = 0;
          base.setUrl(TILE_SOURCES[tileStage], false);
        }
      };
      base.on("tileerror", () => {
        errCount++;
        maybeFailover();
      });
      base.on("tileload", () => {
        okCount++;
      });
      base.addTo(map);
      L.control.zoom({ position: "bottomleft" }).addTo(map);
      for (const g of [
        "risk",
        "flood",
        "fire",
        "cyclone",
        "usgs",
        "zones",
        "hospitals",
        "units",
        "soss",
      ]) {
        groups.current[g] = L.layerGroup().addTo(map);
      }
      mapRef.current = map;
      setReady(true);
    })();
    return () => {
      cancelled = true;
      mapRef.current?.remove();
      mapRef.current = null;
    };
  }, []);

  // ---- view commands ----
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !viewCommand) return;
    if (viewCommand.target === "hyderabad")
      map.setView([17.4126, 78.4392], 11);
    if (viewCommand.target === "coast")
      map.fitBounds([
        [14.6, 79.0],
        [17.6, 85.2],
      ]);
    if (viewCommand.target === "fire") map.setView([17.332, 78.098], 11);
  }, [viewCommand]);

  // ---- hazard / risk / cyclone / flood / fire ----
  useEffect(() => {
    const L = LRef.current;
    const map = mapRef.current;
    if (!ready || !L || !map) return;
    const g = groups.current;
    g.risk.clearLayers();
    g.flood.clearLayers();
    g.fire.clearLayers();
    g.cyclone.clearLayers();

    for (const h of hazards) {
      if (h.kind === "quake") {
        L.circle([h.epicenter.lat, h.epicenter.lng], {
          radius: h.radiusKm * 1000,
          color: "#ef4444",
          weight: 1.5,
          fillColor: "#ef4444",
          fillOpacity: 0.08,
          dashArray: "6 6",
        })
          .bindPopup(
            `<b>${h.title}</b><br/>Strong-shaking radius ≈ ${Math.round(h.radiusKm)} km<br/><span style="color:#94a3b8">modeled from ${h.magnitude?.toFixed(1) ?? "—"} M · depth 12 km</span>`
          )
          .addTo(g.risk);
        L.marker([h.epicenter.lat, h.epicenter.lng], {
          icon: L.divIcon({
            className: "",
            html: `<div class="mk-epi">${ICONS.quake}</div>`,
            iconSize: [28, 28],
            iconAnchor: [14, 14],
          }),
        }).addTo(g.risk);
      }
      if (h.kind === "cyclone") {
        L.circle([h.epicenter.lat, h.epicenter.lng], {
          radius: h.radiusKm * 1000,
          color: "#f97316",
          weight: 1.2,
          fillColor: "#f97316",
          fillOpacity: 0.05,
        }).addTo(g.cyclone);
        // track + uncertainty cones
        L.polyline(
          CYCLONE_TRACK.map((p) => [p.lat, p.lng] as [number, number]),
          { color: "#f97316", weight: 2, dashArray: "4 6" }
        ).addTo(g.cyclone);
        const idx = h.trackIndex ?? 0;
        CYCLONE_TRACK.forEach((p, i) => {
          if (i < idx) return;
          L.circle([p.lat, p.lng], {
            radius: (50 + i * 45) * 1000,
            color: "#f97316",
            weight: 0.5,
            fillColor: "#f97316",
            fillOpacity: 0.05,
          }).addTo(g.cyclone);
        });
        L.marker([h.epicenter.lat, h.epicenter.lng], {
          icon: L.divIcon({
            className: "",
            html: `<div class="mk-cyclone"><div class="mk-cyclone-spin"></div><span>${Math.round(h.windKmph ?? 0)}</span></div>`,
            iconSize: [44, 44],
            iconAnchor: [22, 22],
          }),
        })
          .bindPopup(
            `<b>${h.title}</b><br/>Winds ${Math.round(h.windKmph ?? 0)} km/h · ${h.category}<br/><span style="color:#94a3b8">IMD track + uncertainty cone</span>`
          )
          .addTo(g.cyclone);
      }
      if (h.kind === "flood") {
        for (const z of FLOOD_ZONES) {
          const op = Math.min(0.34, 0.08 + ((h.waterLevelM ?? 0) / 2.4) * 0.3);
          L.circle([z.pos.lat, z.pos.lng], {
            radius: z.radiusKm * 1000,
            color: "#14b8a6",
            weight: 1,
            fillColor: "#14b8a6",
            fillOpacity: op,
          })
            .bindPopup(
              `<b>${z.name}</b><br/>Water level ≈ ${(h.waterLevelM ?? 0).toFixed(1)} m<br/><span style="color:#94a3b8">GHMC flood-prone zone</span>`
            )
            .addTo(g.flood);
        }
      }
      if (h.kind === "fire") {
        L.circle([h.epicenter.lat, h.epicenter.lng], {
          radius: (h.spreadKm ?? 0.5) * 1000,
          color: "#f97316",
          weight: 2,
          fillColor: "#f97316",
          fillOpacity: 0.16,
          dashArray: "2 6",
        })
          .bindPopup(
            `<b>${h.title}</b><br/>Spread ≈ ${(h.spreadKm ?? 0).toFixed(1)} km radius<br/><span style="color:#94a3b8">wind 18 km/h from SW → spreading NE</span>`
          )
          .addTo(g.fire);
        L.marker([h.epicenter.lat + 0.028, h.epicenter.lng], {
          icon: L.divIcon({
            className: "",
            html: `<div class="mk-wind">wind 18 km/h ↗</div>`,
            iconSize: [130, 20],
            iconAnchor: [65, 10],
          }),
        }).addTo(g.fire);
      }
    }

    for (const f of fireHotspots) {
      L.circleMarker([f.lat, f.lng], {
        radius: 4,
        color: "#fbbf24",
        weight: 1,
        fillColor: "#f97316",
        fillOpacity: 0.95,
      })
        .bindPopup(
          `<b>VIIRS hotspot</b><br/>FRP ${f.frp} MW · confidence ${f.confidence}<br/>${f.acquired}${f.simulated ? '<br/><span style="color:#94a3b8">SIMULATED — set FIRMS_MAP_KEY for live</span>' : '<br/><span style="color:#34d399">LIVE NASA FIRMS</span>'}`
        )
        .addTo(g.fire);
    }
  }, [ready, hazards, fireHotspots]);

  // ---- USGS layer ----
  useEffect(() => {
    const L = LRef.current;
    const map = mapRef.current;
    if (!ready || !L || !map) return;
    const g = groups.current.usgs;
    g.clearLayers();
    if (!showUsgs) return;
    // global feed — pull the view back so the quakes are actually visible
    if (!useSuraksha.getState().scenario) map.setView([21.5, 80], 4);
    for (const q of usgsQuakes) {
      const c = q.mag >= 4.5 ? "#ef4444" : q.mag >= 3.5 ? "#f59e0b" : "#facc15";
      L.circleMarker([q.lat, q.lng], {
        radius: 3 + q.mag * 0.7,
        color: c,
        weight: 1,
        fillOpacity: 0.55,
      })
        .bindPopup(
          `<b>M${q.mag.toFixed(1)} — LIVE USGS</b><br/>${q.place}<br/>depth ${q.depth} km`
        )
        .addTo(g);
    }
  }, [ready, usgsQuakes, showUsgs]);

  // ---- safe zones ----
  useEffect(() => {
    const L = LRef.current;
    if (!ready || !L) return;
    const g = groups.current.zones;
    g.clearLayers();
    for (const z of safeZones) {
      L.circle([z.pos.lat, z.pos.lng], {
        radius: z.radiusKm * 1000,
        color: "#10b981",
        weight: 1.2,
        fillColor: "#10b981",
        fillOpacity: 0.1,
      })
        .bindPopup(
          `<b>${z.name}</b><br/>Capacity ${z.capacity} · occupancy ${z.occupancy}<br/><span style="color:#34d399">crowd-marked safe zone</span>`
        )
        .addTo(g);
      L.marker([z.pos.lat, z.pos.lng], {
        icon: L.divIcon({
          className: "",
          html: `<div class="mk-safe">${ICONS.rescue}</div>`,
          iconSize: [22, 22],
          iconAnchor: [11, 11],
        }),
      }).addTo(g);
    }
  }, [ready, safeZones]);

  // ---- hospitals ----
  useEffect(() => {
    const L = LRef.current;
    if (!ready || !L) return;
    const g = groups.current.hospitals;
    g.clearLayers();
    for (const h of hospitals) {
      L.marker([h.pos.lat, h.pos.lng], {
        icon: L.divIcon({
          className: "",
          html: `<div class="mk-hospital ${h.notified ? "notified" : ""}" style="--mk:${h.kind === "govt" ? "#e5e7eb" : "#cbd5e1"}">${ICONS.hospital}</div>`,
          iconSize: [22, 22],
          iconAnchor: [11, 11],
        }),
      })
        .bindPopup(
          `<b>${h.name}</b><br/>${h.kind.toUpperCase()} · trauma ${h.trauma ? "yes" : "no"}<br/>Beds free: ${h.bedsFree}${h.notified ? '<br/><span style="color:#34d399">✓ NOTIFIED by dispatch AI</span>' : ""}`
        )
        .addTo(g);
    }
  }, [ready, hospitals]);

  // ---- responders ----
  useEffect(() => {
    const L = LRef.current;
    if (!ready || !L) return;
    const g = groups.current.units;
    g.clearLayers();
    for (const r of responders) {
      L.marker([r.pos.lat, r.pos.lng], {
        icon: L.divIcon({
          className: "",
          html: unitIcon(r.kind, r.status),
          iconSize: [24, 24],
          iconAnchor: [12, 12],
        }),
      })
        .bindPopup(
          `<b>${r.callsign}</b><br/>${r.agency}<br/>status: ${r.status}${r.targetSosId ? " · on task" : ""}`
        )
        .addTo(g);
    }
  }, [ready, responders]);

  // ---- SOS ----
  useEffect(() => {
    const L = LRef.current;
    if (!ready || !L) return;
    const g = groups.current.soss;
    g.clearLayers();
    for (const s of soss) {
      if (s.status === "resolved") continue;
      const unit = responders.find((r) => r.id === s.assignedResponderId);
      L.marker([s.pos.lat, s.pos.lng], {
        icon: L.divIcon({
          className: "",
          html: sosIcon(s.severity, s.hops),
          iconSize: [38, 34],
          iconAnchor: [19, 17],
        }),
      })
        .bindPopup(
          `<b>${s.severity} · ${s.type.toUpperCase()}</b> <span style="color:#94a3b8">(score ${s.score}, ${(s.confidence * 100).toFixed(0)}% conf)</span><br/>${s.note}<br/>people: ${s.peopleCount} · ${s.source}${s.hops > 0 ? ` · <span style="color:#22d3ee">mesh relay ×${s.hops}</span>` : ""}${unit ? `<br/><span style="color:#f59e0b">→ ${unit.callsign} (${unit.agency}) ${unit.status}</span>` : '<br/><span style="color:#94a3b8">awaiting dispatch…</span>'}`
        )
        .addTo(g);
    }
  }, [ready, soss, responders]);

  // ---- map click → SOS mode ----
  useEffect(() => {
    const map = mapRef.current;
    if (!ready || !map) return;
    const handler = (e: LeafletNS.LeafletMouseEvent) => {
      if (sosArmed) {
        setSosDraft({ lat: e.latlng.lat, lng: e.latlng.lng });
        useSuraksha.getState().toggleSosArmed();
      }
    };
    map.on("click", handler);
    return () => {
      map.off("click", handler);
    };
  }, [ready, sosArmed]);

  const submitSos = () => {
    if (!sosDraft) return;
    addCitizenSos(
      sosType,
      sosNote || "Citizen SOS raised from map",
      { lat: sosDraft.lat, lng: sosDraft.lng }
    );
    setSosDraft(null);
    setSosNote("");
  };

  return (
    <div className={`relative h-full w-full ${sosArmed ? "cursor-crosshair" : ""}`}>
      {/* NOTE: this div's className must stay static — React would strip
          Leaflet's injected `leaflet-container` class on re-render. */}
      <div ref={rootRef} className="h-full w-full" />
      {/* legend */}
      <div className="pointer-events-none absolute bottom-3 right-3 z-[500] rounded-md border border-white/10 bg-black/70 px-2.5 py-2 text-[10px] leading-4 text-zinc-300 backdrop-blur">
        <div><span className="legend-dot" style={{ background: "#ef4444" }} /> P1 critical · <span className="legend-dot" style={{ background: "#f97316" }} /> P2 · <span className="legend-dot" style={{ background: "#eab308" }} /> P3</div>
        <div><span className="legend-dot" style={{ background: "#f59e0b" }} /> 108 ambulance · <span className="legend-dot" style={{ background: "#22d3ee" }} /> NDRF/SDRF · <span className="legend-dot" style={{ background: "#fb923c" }} /> Fire</div>
        <div><span className="legend-dot" style={{ background: "#10b981" }} /> safe zone · <span className="legend-dot" style={{ background: "#14b8a6" }} /> flood · <span className="legend-dot" style={{ background: "#facc15" }} /> USGS live</div>
      </div>
      {scenario && (
        <div className="pointer-events-none absolute left-1/2 top-3 z-[500] -translate-x-1/2 rounded border border-amber-500/40 bg-black/70 px-3 py-1 text-[11px] font-semibold tracking-widest text-amber-400 backdrop-blur">
          SIMULATED SCENARIO · T+{Math.floor(useSuraksha.getState().t)}s
        </div>
      )}
      <Dialog open={!!sosDraft} onOpenChange={(o) => !o && setSosDraft(null)}>
        <DialogContent className="dark border border-white/10 bg-zinc-950 sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-zinc-100">Raise citizen SOS</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <Select value={sosType} onValueChange={(v) => setSosType(v as SosType)}>
              <SelectTrigger className="dark bg-zinc-900 text-zinc-100">
                <SelectValue placeholder="Emergency type" />
              </SelectTrigger>
              <SelectContent className="dark border-white/10 bg-zinc-950 text-zinc-100">
                <SelectItem value="medical">Medical</SelectItem>
                <SelectItem value="trapped">Trapped</SelectItem>
                <SelectItem value="fire">Fire</SelectItem>
                <SelectItem value="structural">Structural</SelectItem>
                <SelectItem value="flood">Flood</SelectItem>
                <SelectItem value="general">General</SelectItem>
              </SelectContent>
            </Select>
            <Textarea
              placeholder="What is happening? (words like 'unconscious', 'child', 'trapped' raise triage priority)"
              value={sosNote}
              onChange={(e) => setSosNote(e.target.value)}
              className="dark min-h-20 border-white/10 bg-zinc-900 text-zinc-100"
            />
            <Button onClick={submitSos} className="w-full bg-red-600 text-white hover:bg-red-500">
              Transmit SOS (goes through mesh if towers are down)
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
