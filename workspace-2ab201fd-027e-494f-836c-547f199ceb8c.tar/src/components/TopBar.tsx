"use client";

import { useSuraksha } from "@/lib/store";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import type { ScenarioKind } from "@/lib/types";

const SCENARIOS: { v: ScenarioKind; label: string }[] = [
  { v: "quake", label: "Earthquake · M5.7 Telangana" },
  { v: "cyclone", label: "Cyclone · Bay of Bengal landfall" },
  { v: "flood", label: "Flash flood · GHMC low-lying zones" },
  { v: "fire", label: "Wildfire · Ananthagiri Hills" },
];

export default function TopBar() {
  const scenario = useSuraksha((s) => s.scenario);
  const startScenario = useSuraksha((s) => s.startScenario);
  const resetSim = useSuraksha((s) => s.resetSim);
  const towersDown = useSuraksha((s) => s.towersDown);
  const setTowersDown = useSuraksha((s) => s.setTowersDown);
  const showUsgs = useSuraksha((s) => s.showUsgs);
  const toggleUsgs = useSuraksha((s) => s.toggleUsgs);
  const sosArmed = useSuraksha((s) => s.sosArmed);
  const toggleSosArmed = useSuraksha((s) => s.toggleSosArmed);
  const usgsFetchedAt = useSuraksha((s) => s.usgsFetchedAt);

  return (
    <header className="flex flex-wrap items-center gap-x-4 gap-y-2 border-b border-white/10 bg-black/40 px-3 py-2 backdrop-blur">
      <div className="flex items-center gap-2.5">
        <svg viewBox="0 0 24 24" className="h-7 w-7 text-amber-400" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M12 3l8 3v5c0 5-3.4 8.6-8 10-4.6-1.4-8-5-8-10V6z" />
          <path d="M12 8v4M12 15h.01" />
        </svg>
        <div className="leading-tight">
          <div className="text-sm font-bold tracking-wide text-zinc-100">
            SURAKSHA-AI
          </div>
          <div className="text-[10px] text-zinc-500">
            multi-hazard guardian · India command
          </div>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-2 md:ml-auto">
        <Select
          value={scenario ?? ""}
          onValueChange={(v) => v && startScenario(v as ScenarioKind)}
        >
          <SelectTrigger className="h-8 w-[240px] border-white/10 bg-zinc-900 text-xs text-zinc-100">
            <SelectValue placeholder="Launch disaster scenario…" />
          </SelectTrigger>
          <SelectContent className="border-white/10 bg-zinc-950 text-zinc-100">
            {SCENARIOS.map((s) => (
              <SelectItem key={s.v} value={s.v} className="text-xs">
                {s.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Button
          size="sm"
          variant="outline"
          className={`h-8 border-white/10 text-[11px] ${sosArmed ? "border-red-500/50 bg-red-500/15 text-red-300" : "text-zinc-300"}`}
          onClick={toggleSosArmed}
        >
          {sosArmed ? "click map to place SOS…" : "Raise SOS on map"}
        </Button>

        <Button
          size="sm"
          variant="outline"
          className="h-8 border-white/10 text-[11px] text-zinc-300"
          onClick={resetSim}
        >
          Reset
        </Button>

        <label className="flex items-center gap-1.5 text-[11px] text-zinc-400">
          <Switch checked={towersDown} onCheckedChange={setTowersDown} />
          tower outage
        </label>

        <label className="flex items-center gap-1.5 text-[11px] text-zinc-400">
          <Switch checked={showUsgs} onCheckedChange={toggleUsgs} />
          USGS live
          {usgsFetchedAt && (
            <span className="hidden font-mono text-[9px] text-emerald-500 sm:inline">
              ●
            </span>
          )}
        </label>
      </div>
    </header>
  );
}
