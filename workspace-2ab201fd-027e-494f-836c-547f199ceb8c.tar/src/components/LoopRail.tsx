"use client";

import { useSuraksha } from "@/lib/store";
import { Eye, Radar, Gauge, ShieldCheck } from "lucide-react";

const STAGES = [
  { key: "observe", label: "Observe", Icon: Eye, hint: "sensors & feeds" },
  { key: "analyse", label: "Analyse", Icon: Radar, hint: "detection models" },
  { key: "assess", label: "Assess risk", Icon: Gauge, hint: "triage & zones" },
  { key: "protect", label: "Protect", Icon: ShieldCheck, hint: "alerts & dispatch" },
] as const;

export default function LoopRail() {
  const loopStage = useSuraksha((s) => s.loopStage);
  const scenario = useSuraksha((s) => s.scenario);
  const activeIdx = STAGES.findIndex((s) => s.key === loopStage);

  return (
    <div className="flex items-center justify-center gap-1 border-b border-white/10 bg-black/20 px-3 py-1.5">
      {STAGES.map((s, i) => {
        const done = scenario !== null && i < activeIdx;
        const active = scenario !== null && i === activeIdx;
        return (
          <div key={s.key} className="flex items-center gap-1">
            <div
              className={`flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 transition-colors ${
                active
                  ? "border-amber-400/60 bg-amber-500/15 text-amber-300 shadow-[0_0_12px_rgba(245,158,11,0.25)]"
                  : done
                    ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-400"
                    : "border-white/10 text-zinc-600"
              }`}
            >
              <s.Icon className="h-3 w-3" />
              <span className="text-[11px] font-semibold">{s.label}</span>
              <span className="hidden text-[9px] opacity-70 lg:inline">
                {s.hint}
              </span>
            </div>
            {i < STAGES.length - 1 && (
              <span className={`text-[10px] ${done ? "text-emerald-500" : "text-zinc-700"}`}>
                →
              </span>
            )}
          </div>
        );
      })}
    </div>
  );
}
