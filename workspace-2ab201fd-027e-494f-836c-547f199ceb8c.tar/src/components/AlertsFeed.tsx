"use client";

import { useState } from "react";
import { useSuraksha } from "@/lib/store";
import { verifyAlert, shortSig } from "@/lib/crypto";
import { analyzeForward } from "@/lib/misinfo";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

const AGENCY_COLOR: Record<string, string> = {
  IMD: "#f59e0b",
  NDMA: "#ef4444",
  INCOIS: "#22d3ee",
  SDRF: "#a3e635",
  FSI: "#fb923c",
  "SURAKSHA-AI": "#e5e7eb",
};

const SEV_STYLE: Record<string, string> = {
  CRITICAL: "bg-red-500/15 text-red-400 border-red-500/40",
  WARNING: "bg-amber-500/15 text-amber-400 border-amber-500/40",
  ADVISORY: "bg-zinc-500/10 text-zinc-300 border-zinc-500/30",
};

const FAKE_FORWARD = `DAM HAS BROKEN NEAR NAGARJUNA SAGAR!!! WATER WILL REACH HYDERABAD IN 2 HOURS!!! FORWARD TO ALL FAMILY & FRIENDS SHARE MAX AS MEDIA WON'T SHOW THIS !!!!!!`;

const GENUINE_BULLETIN = `IMD Bulletin: Cyclone 'Bhairavi' (SIM) — severe cyclonic storm, landfall near Bapatla coast. Helpline 112. Evacuation advisories issued for low-lying mandals.`;

export default function AlertsFeed() {
  const alerts = useSuraksha((s) => s.alerts);
  const towersDown = useSuraksha((s) => s.towersDown);
  const [txt, setTxt] = useState("");
  const [verdict, setVerdict] = useState<ReturnType<typeof analyzeForward> | null>(null);
  const [checking, setChecking] = useState<Record<string, "pending" | boolean>>({});

  const check = async (id: string, agency: string, headline: string, at: number, sig: string) => {
    setChecking((c) => ({ ...c, [id]: "pending" }));
    const ok = await verifyAlert(agency, headline, at, sig);
    setChecking((c) => ({ ...c, [id]: ok }));
  };

  return (
    <div className="flex h-full flex-col gap-3 p-3">
      {/* ---- misinformation shield ---- */}
      <div className="rounded-lg border border-white/10 bg-black/30 p-3">
        <div className="mb-2 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-zinc-100">
            Misinformation Shield
          </h3>
          <span className="text-[10px] text-zinc-500">
            disasters kill twice — panic kills too
          </span>
        </div>
        <Textarea
          value={txt}
          onChange={(e) => setTxt(e.target.value)}
          placeholder="Paste a forwarded emergency message to check…"
          className="min-h-16 border-white/10 bg-zinc-900 text-xs text-zinc-100"
        />
        <div className="mt-2 flex flex-wrap gap-1.5">
          <Button
            size="sm"
            variant="outline"
            className="h-7 border-white/10 text-[11px] text-zinc-300"
            onClick={() => {
              setTxt(FAKE_FORWARD);
              setVerdict(null);
            }}
          >
            Load viral forward
          </Button>
          <Button
            size="sm"
            variant="outline"
            className="h-7 border-white/10 text-[11px] text-zinc-300"
            onClick={() => {
              setTxt(GENUINE_BULLETIN);
              setVerdict(null);
            }}
          >
            Load IMD bulletin
          </Button>
          <Button
            size="sm"
            className="h-7 bg-amber-500 text-[11px] font-semibold text-black hover:bg-amber-400"
            onClick={() => setVerdict(analyzeForward(txt))}
            disabled={!txt.trim()}
          >
            Analyze
          </Button>
        </div>
        {verdict && (
          <div
            className={`mt-2 rounded-md border p-2 text-xs ${
              verdict.risk === "LIKELY_FALSE"
                ? "border-red-500/40 bg-red-500/10 text-red-300"
                : verdict.risk === "UNVERIFIED"
                  ? "border-amber-500/40 bg-amber-500/10 text-amber-300"
                  : "border-emerald-500/40 bg-emerald-500/10 text-emerald-300"
            }`}
          >
            <div className="font-semibold">
              {verdict.risk.replace("_", " ")} · false-risk score {verdict.score}/100
            </div>
            <ul className="mt-1 list-inside list-disc text-[11px] opacity-90">
              {verdict.reasons.map((r, i) => (
                <li key={i}>{r}</li>
              ))}
            </ul>
          </div>
        )}
      </div>

      {/* ---- official signed alerts ---- */}
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-zinc-100">
          Official alert stream
        </h3>
        {towersDown && (
          <Badge className="border border-cyan-500/40 bg-cyan-500/10 text-[10px] text-cyan-300">
            mesh relay active — towers down
          </Badge>
        )}
      </div>

      <div className="suraksha-scroll -mr-1 flex-1 space-y-2 overflow-y-auto pr-1">
        {alerts.length === 0 && (
          <p className="rounded-lg border border-dashed border-white/10 p-4 text-center text-xs text-zinc-500">
            No alerts yet. Launch a scenario — every official alert will appear
            here <span className="text-zinc-300">cryptographically signed</span>.
          </p>
        )}
        {alerts.map((a) => (
          <div
            key={a.id}
            className="rounded-lg border border-white/10 bg-black/30 p-3"
          >
            <div className="flex flex-wrap items-center gap-1.5">
              <Badge
                className="border text-[10px] font-bold"
                style={{
                  borderColor: `${AGENCY_COLOR[a.agency] ?? "#888"}55`,
                  color: AGENCY_COLOR[a.agency] ?? "#aaa",
                  background: `${AGENCY_COLOR[a.agency] ?? "#888"}14`,
                }}
              >
                {a.agency}
              </Badge>
              <Badge className={`border text-[10px] ${SEV_STYLE[a.severity]}`}>
                {a.severity}
              </Badge>
              {a.hops > 0 && (
                <Badge className="border border-cyan-500/40 bg-cyan-500/10 text-[10px] text-cyan-300">
                  mesh ×{a.hops} hops
                </Badge>
              )}
              <span className="ml-auto font-mono text-[10px] text-zinc-500">
                {new Date(a.at).toLocaleTimeString("en-IN", { hour12: false })}
              </span>
            </div>
            <div className="mt-1.5 text-sm font-semibold leading-5 text-zinc-100">
              {a.headline}
            </div>
            <p className="mt-0.5 text-xs leading-5 text-zinc-400">{a.body}</p>
            <p className="mt-1 text-[11px] leading-4 text-zinc-500">
              <span className="mr-1 rounded bg-white/5 px-1">हिंदी</span>
              {a.hi}
            </p>
            <p className="text-[11px] leading-4 text-zinc-500">
              <span className="mr-1 rounded bg-white/5 px-1">తెలుగు</span>
              {a.te}
            </p>
            <div className="mt-2 flex items-center justify-between gap-2 border-t border-white/5 pt-2">
              <span className="font-mono text-[10px] text-emerald-400/90">
                ✓ ECDSA-P256 · sig {a.sig ? shortSig(a.sig) : "—"}
              </span>
              <Button
                size="sm"
                variant="outline"
                className="h-6 border-white/10 px-2 text-[10px] text-zinc-300"
                onClick={() => a.sig && check(a.id, a.agency, a.headline, a.at, a.sig)}
              >
                {checking[a.id] === undefined
                  ? "Verify"
                  : checking[a.id] === "pending"
                    ? "checking…"
                    : checking[a.id]
                      ? "✓ valid"
                      : "✗ invalid"}
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
