"use client";

import { useSuraksha } from "@/lib/store";
import { haversineKm } from "@/lib/geo";
import { Badge } from "@/components/ui/badge";

const SEV_STYLE: Record<string, string> = {
  P1: "bg-red-500/15 text-red-400 border-red-500/40",
  P2: "bg-orange-500/15 text-orange-400 border-orange-500/40",
  P3: "bg-yellow-500/15 text-yellow-300 border-yellow-500/40",
};

const STATUS_STYLE: Record<string, string> = {
  open: "text-zinc-400",
  assigned: "text-amber-400",
  enroute: "text-amber-300",
  onsite: "text-emerald-400",
  resolved: "text-zinc-600",
};

export default function TriagePanel() {
  const soss = useSuraksha((s) => s.soss);
  const responders = useSuraksha((s) => s.responders);
  const hospitals = useSuraksha((s) => s.hospitals);

  const active = soss.filter((s) => s.status !== "resolved");
  const order = { P1: 0, P2: 1, P3: 2 } as const;
  const sorted = [...active].sort(
    (a, b) => order[a.severity] - order[b.severity] || b.score - a.score
  );
  const counts = {
    P1: active.filter((s) => s.severity === "P1").length,
    P2: active.filter((s) => s.severity === "P2").length,
    P3: active.filter((s) => s.severity === "P3").length,
  };
  const notified = hospitals.filter((h) => h.notified);

  return (
    <div className="flex h-full flex-col gap-3 p-3">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-zinc-100">
          TriAI dispatch queue
        </h3>
        <div className="flex gap-1.5">
          <Badge className={`border text-[10px] ${SEV_STYLE.P1}`}>P1 · {counts.P1}</Badge>
          <Badge className={`border text-[10px] ${SEV_STYLE.P2}`}>P2 · {counts.P2}</Badge>
          <Badge className={`border text-[10px] ${SEV_STYLE.P3}`}>P3 · {counts.P3}</Badge>
        </div>
      </div>

      <div className="suraksha-scroll -mr-1 flex-1 space-y-2 overflow-y-auto pr-1">
        {sorted.length === 0 && (
          <p className="rounded-lg border border-dashed border-white/10 p-4 text-center text-xs text-zinc-500">
            No active SOS. Launch a scenario, or arm <span className="text-zinc-300">SOS mode</span> and click the map.
          </p>
        )}
        {sorted.map((s) => {
          const unit = responders.find((r) => r.id === s.assignedResponderId);
          const hosp = hospitals.find((h) => h.id === s.assignedHospitalId);
          const eta =
            unit && (s.status === "assigned" || s.status === "enroute")
              ? Math.max(1, Math.round((haversineKm(unit.pos, s.pos) / unit.speedKmph) * 60))
              : null;
          return (
            <div key={s.id} className="rounded-lg border border-white/10 bg-black/30 p-2.5">
              <div className="flex flex-wrap items-center gap-1.5">
                <Badge className={`border font-mono text-[10px] ${SEV_STYLE[s.severity]}`}>
                  {s.severity}
                </Badge>
                <span className="text-[11px] font-semibold uppercase tracking-wide text-zinc-300">
                  {s.type}
                </span>
                <span className="font-mono text-[10px] text-zinc-500">
                  score {s.score} · {(s.confidence * 100).toFixed(0)}%
                </span>
                {s.hops > 0 && (
                  <Badge className="border border-cyan-500/40 bg-cyan-500/10 text-[10px] text-cyan-300">
                    mesh ×{s.hops}
                  </Badge>
                )}
                <span className={`ml-auto text-[10px] font-semibold uppercase ${STATUS_STYLE[s.status]}`}>
                  {s.status}
                  {eta !== null && unit ? ` · ETA ${eta} min` : ""}
                </span>
              </div>
              <p className="mt-1 line-clamp-2 text-xs leading-5 text-zinc-300">{s.note}</p>
              <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-[10px] text-zinc-500">
                <span>{s.peopleCount} people</span>
                <span>{s.source === "citizen" ? "citizen SOS" : "auto-detected"}</span>
                {unit && (
                  <span className="text-amber-400/90">
                    → {unit.callsign} · {unit.agency}
                  </span>
                )}
                {hosp && (
                  <span className="text-emerald-400/90">
                    [hospital] {hosp.name} notified
                  </span>
                )}
              </div>
            </div>
          );
        })}

        {/* hospital desk */}
        <div className="pt-1">
          <h4 className="mb-1.5 text-[11px] font-semibold uppercase tracking-wide text-zinc-500">
            Hospital desk · {notified.length}/{hospitals.length} notified
          </h4>
          <div className="grid grid-cols-2 gap-1.5">
            {hospitals.map((h) => (
              <div
                key={h.id}
                className={`rounded border p-1.5 text-[10px] leading-4 ${
                  h.notified
                    ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-300"
                    : "border-white/5 bg-black/20 text-zinc-500"
                }`}
              >
                <div className="truncate font-semibold">{h.name}</div>
                <div>
                  beds free {h.bedsFree}
                  {h.notified ? " · ✓ alerted" : ""}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
