"use client";

import { useEffect, useRef, useState } from "react";
import { useSuraksha } from "@/lib/store";
import {
  StaLtaDetector,
  classify,
  ambientNoise,
  quakeWaveform,
  type SeismoSample,
} from "@/lib/seismo";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

type Mode = "sim" | "phone";

const SAMPLE_MS = 50; // synthetic waveform resolution

export default function SeismoPanel() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const samplesRef = useRef<SeismoSample[]>([]);
  const lastSampleTRef = useRef<number>(0);
  const detectorRef = useRef(new StaLtaDetector());
  const injectRef = useRef<{
    startAt: number;
    kind: "quake" | "bump";
    mag: number;
  } | null>(null);
  const firedRef = useRef(false);

  const [mode, setMode] = useState<Mode>("sim");
  const [phoneOk, setPhoneOk] = useState<"idle" | "on" | "denied">("idle");
  const [live, setLive] = useState({
    ratio: 1,
    hz: 0,
    verdict: "NOISE" as "NOISE" | "BUMP" | "QUAKE",
    conf: 0.8,
    mag: 0,
  });

  const detection = useSuraksha((s) => s.detection);
  const triggerDetection = useSuraksha((s) => s.triggerDetection);
  const phonesStreaming = useSuraksha((s) => s.phonesStreaming);

  // reset the one-shot latch whenever the store detection clears
  useEffect(() => {
    if (!detection) firedRef.current = false;
  }, [detection]);

  /** Synthetic acceleration at time t: ambient + scenario/injected quake. */
  const synthAt = (t: number): number => {
    let a = ambientNoise(t);
    const q = useSuraksha.getState().seismoQuake;
    if (q && t >= q.startAt && t <= q.startAt + 12_000)
      a += quakeWaveform(t - q.startAt, q.mag);
    const inj = injectRef.current;
    if (inj && t >= inj.startAt) {
      const el = t - inj.startAt;
      if (inj.kind === "bump" && el <= 900)
        a += 2.8 * Math.exp(-el / 260) * Math.sin(el / 9);
      if (inj.kind === "quake" && el <= 11_000) a += quakeWaveform(el, inj.mag);
    }
    return a;
  };

  // ---- shared classifier ----
  const runClassifierRef = useRef<(now: number) => void>(() => {});
  runClassifierRef.current = (now: number) => {
    const det = detectorRef.current;
    const ratio = det.ratio(now);
    const hz = det.dominantHz(now);
    const sus = det.sustainedS(now);
    const v = classify(ratio, hz, sus);
    setLive({
      ratio,
      hz,
      verdict: v.verdict,
      conf: v.confidence,
      mag: v.magnitude,
    });
    if (
      v.verdict === "QUAKE" &&
      !firedRef.current &&
      !useSuraksha.getState().detection
    ) {
      firedRef.current = true;
      triggerDetection({
        id: `det-${now}`,
        at: now,
        ratio,
        magnitude: v.magnitude,
        confidence: v.confidence,
        verdict: "QUAKE",
        dominantHz: hz,
        durationS: sus,
      });
    }
  };

  // ---- simulator: backfill sampling at 50 ms resolution ----
  // Timer throttling (background tabs, headless browsers) only changes HOW
  // OFTEN we tick — backfilling keeps the waveform and the detector
  // sampling-rate independent, so triggers fire identically everywhere.
  useEffect(() => {
    if (mode !== "sim") return;
    lastSampleTRef.current = Date.now();
    const iv = setInterval(() => {
      const now = Date.now();
      const from = Math.max(lastSampleTRef.current + SAMPLE_MS, now - 45_000);
      for (let t = from; t <= now; t += SAMPLE_MS) {
        const s = { t, a: synthAt(t) };
        samplesRef.current.push(s);
        detectorRef.current.push(s);
      }
      lastSampleTRef.current = now;
      if (samplesRef.current.length > 3000)
        samplesRef.current.splice(0, samplesRef.current.length - 3000);
      runClassifierRef.current(now);
    }, 250);
    return () => clearInterval(iv);
  }, [mode]);

  // ---- real phone accelerometer (phone mode) ----
  useEffect(() => {
    if (mode !== "phone") return;
    let n = 0;
    const handler = (e: DeviceMotionEvent) => {
      const acc = e.accelerationIncludingGravity;
      if (!acc || acc.x === null || acc.y === null || acc.z === null) return;
      const a = Math.abs(
        Math.sqrt(acc.x ** 2 + acc.y ** 2 + acc.z ** 2) - 9.81
      );
      const now = Date.now();
      const s = { t: now, a };
      samplesRef.current.push(s);
      if (samplesRef.current.length > 3000)
        samplesRef.current.splice(0, samplesRef.current.length - 3000);
      detectorRef.current.push(s);
      if (++n % 20 === 0) runClassifierRef.current(now);
    };
    let clean = () => {};
    (async () => {
      try {
        const dm = DeviceMotionEvent as unknown as {
          requestPermission?: () => Promise<string>;
        };
        if (typeof dm.requestPermission === "function") {
          const r = await dm.requestPermission();
          if (r !== "granted") {
            setPhoneOk("denied");
            return;
          }
        }
        window.addEventListener("devicemotion", handler);
        setPhoneOk("on");
        clean = () => window.removeEventListener("devicemotion", handler);
      } catch {
        setPhoneOk("denied");
      }
    })();
    return () => clean();
  }, [mode]);

  // ---- draw loop (rAF, draw only) ----
  useEffect(() => {
    let raf = 0;

    const loop = () => {
      raf = requestAnimationFrame(loop);
      const cv = canvasRef.current;
      if (!cv) return;
      const ctx = cv.getContext("2d");
      if (!ctx) return;

      const w = cv.clientWidth;
      const h = cv.clientHeight;
      const dpr = window.devicePixelRatio || 1;
      if (cv.width !== Math.round(w * dpr) || cv.height !== Math.round(h * dpr)) {
        cv.width = Math.round(w * dpr);
        cv.height = Math.round(h * dpr);
      }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, w, h);

      // grid
      ctx.strokeStyle = "rgba(255,255,255,0.06)";
      ctx.lineWidth = 1;
      for (let i = 1; i < 4; i++) {
        ctx.beginPath();
        ctx.moveTo(0, (h / 4) * i);
        ctx.lineTo(w, (h / 4) * i);
        ctx.stroke();
      }

      // waveform — last 30 s
      const now = Date.now();
      const win = 30_000;
      const xs = samplesRef.current.filter((s) => s.t >= now - win);
      const scale = h / 8;
      const mid = h / 2;
      ctx.strokeStyle =
        live.verdict === "QUAKE"
          ? "#ef4444"
          : live.ratio > 2.2
            ? "#f59e0b"
            : "#34d399";
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      let first = true;
      for (const s of xs) {
        const x = w - ((now - s.t) / win) * w;
        const y = mid - Math.max(-3.5, Math.min(3.5, s.a)) * scale;
        if (first) {
          ctx.moveTo(x, y);
          first = false;
        } else ctx.lineTo(x, y);
      }
      ctx.stroke();
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [live.verdict, live.ratio]);

  const sevStyle =
    live.verdict === "QUAKE"
      ? "bg-red-500/15 text-red-400 border-red-500/40 animate-pulse"
      : live.verdict === "BUMP"
        ? "bg-amber-500/15 text-amber-400 border-amber-500/40"
        : "bg-zinc-500/10 text-zinc-400 border-zinc-500/30";

  return (
    <div className="flex h-full flex-col gap-3 p-3">
      <div className="flex items-center justify-between gap-2">
        <div>
          <h3 className="text-sm font-semibold text-zinc-100">
            Seismic Sentinel
          </h3>
          <p className="text-[10px] text-zinc-500">
            phone seismometer · STA/LTA trigger
          </p>
        </div>
        <Badge className={`${sevStyle} border font-mono text-[10px]`}>
          {live.verdict}
          {live.verdict === "QUAKE" ? ` M${live.mag.toFixed(1)}` : ""}
        </Badge>
      </div>

      <div className="grid grid-cols-3 gap-2 text-center">
        <div className="rounded border border-white/5 bg-black/30 p-1.5">
          <div className="font-mono text-sm text-zinc-100">
            {live.ratio > 99 ? "∞" : live.ratio.toFixed(1)}
          </div>
          <div className="text-[9px] uppercase tracking-wide text-zinc-500">
            STA/LTA
          </div>
        </div>
        <div className="rounded border border-white/5 bg-black/30 p-1.5">
          <div className="font-mono text-sm text-zinc-100">
            {live.hz.toFixed(1)}
          </div>
          <div className="text-[9px] uppercase tracking-wide text-zinc-500">
            dom. Hz
          </div>
        </div>
        <div className="rounded border border-white/5 bg-black/30 p-1.5">
          <div className="font-mono text-sm text-zinc-100">
            {(live.conf * 100).toFixed(0)}%
          </div>
          <div className="text-[9px] uppercase tracking-wide text-zinc-500">
            confidence
          </div>
        </div>
      </div>

      <canvas
        ref={canvasRef}
        className="h-24 w-full rounded border border-white/5 bg-black/40"
      />

      {detection && (
        <div className="rounded-lg border border-red-500/50 bg-red-500/10 p-2.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-red-300">
              QUAKE DETECTED · M{detection.magnitude.toFixed(1)}
            </span>
            <span className="font-mono text-[10px] text-red-400/80">
              {(detection.confidence * 100).toFixed(0)}% conf
            </span>
          </div>
          <div className="mt-1 font-mono text-[10px] leading-4 text-red-200/80">
            STA/LTA {detection.ratio.toFixed(1)} ·{" "}
            {detection.dominantHz.toFixed(1)} Hz · sustained{" "}
            {detection.durationS.toFixed(1)} s ·{" "}
            {new Date(detection.at).toLocaleTimeString("en-IN", {
              hour12: false,
            })}
          </div>
        </div>
      )}

      <div className="flex flex-wrap gap-1.5">
        <Button
          size="sm"
          variant={mode === "sim" ? "default" : "outline"}
          className={`h-7 text-[11px] ${mode === "sim" ? "bg-amber-500 text-black hover:bg-amber-400" : "border-white/10 text-zinc-300"}`}
          onClick={() => setMode("sim")}
        >
          Simulator
        </Button>
        <Button
          size="sm"
          variant={mode === "phone" ? "default" : "outline"}
          className={`h-7 text-[11px] ${mode === "phone" ? "bg-amber-500 text-black hover:bg-amber-400" : "border-white/10 text-zinc-300"}`}
          onClick={() => setMode("phone")}
        >
          {phoneOk === "on"
            ? "Phone sensor ● live"
            : phoneOk === "denied"
              ? "Phone denied"
              : "Use my phone"}
        </Button>
        {mode === "sim" && (
          <>
            <Button
              size="sm"
              variant="outline"
              className="h-7 border-white/10 text-[11px] text-zinc-300"
              onClick={() =>
                (injectRef.current = {
                  startAt: Date.now(),
                  kind: "bump",
                  mag: 0,
                })
              }
            >
              Door-slam test
            </Button>
            <Button
              size="sm"
              className="h-7 bg-red-600 text-[11px] text-white hover:bg-red-500"
              onClick={() =>
                (injectRef.current = {
                  startAt: Date.now(),
                  kind: "quake",
                  mag: 5.7,
                })
              }
            >
              Inject M5.7
            </Button>
          </>
        )}
      </div>

      <p className="mt-auto text-[10px] leading-4 text-zinc-500">
        {mode === "phone"
          ? phoneOk === "on"
            ? "Reading your real accelerometer. Shake the phone — a genuine quake pattern (2–12 Hz, sustained) triggers detection. A bump gets rejected."
            : "Motion sensor unavailable — use the Simulator."
          : "Same STA/LTA algorithm used by real seismic networks: sustained 2–12 Hz energy = quake; short broadband spike = bump. 12,847 Indian phones are streaming."}
      </p>
    </div>
  );
}
