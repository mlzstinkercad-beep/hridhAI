"use client";

import { useSuraksha } from "@/lib/store";

function Stat({
  value,
  label,
  color = "text-zinc-100",
}: {
  value: string;
  label: string;
  color?: string;
}) {
  return (
    <div className="flex min-w-0 flex-col items-center px-2">
      <span className={`font-mono text-sm font-bold leading-5 tabular-nums sm:text-base ${color}`}>
        {value}
      </span>
      <span className="truncate text-[9px] uppercase tracking-wide text-zinc-500">
        {label}
      </span>
    </div>
  );
}

export default function StatsBar() {
  const peopleAlerted = useSuraksha((s) => s.peopleAlerted);
  const soss = useSuraksha((s) => s.soss);
  const responders = useSuraksha((s) => s.responders);
  const resolvedCount = useSuraksha((s) => s.resolvedCount);
  const phonesStreaming = useSuraksha((s) => s.phonesStreaming);
  const alerts = useSuraksha((s) => s.alerts);
  const dispatchedCount = useSuraksha((s) => s.dispatchedCount);

  const activeSos = soss.filter((s) => s.status !== "resolved").length;
  const enroute = responders.filter((r) => r.status === "enroute").length;
  const verifiedPct = alerts.length
    ? Math.round((alerts.filter((a) => a.verified).length / alerts.length) * 100)
    : 0;

  return (
    <div className="grid grid-cols-3 gap-y-1 divide-x divide-white/5 border-t border-white/10 bg-black/40 py-1 backdrop-blur sm:grid-cols-6 sm:gap-y-0 sm:py-0">
      <Stat
        value={peopleAlerted.toLocaleString("en-IN")}
        label="people alerted"
        color="text-amber-400"
      />
      <Stat value={String(activeSos)} label="active SOS" color="text-red-400" />
      <Stat value={String(enroute)} label="en route" color="text-amber-300" />
      <Stat value={String(dispatchedCount)} label="dispatched" />
      <Stat value={String(resolvedCount)} label="resolved" color="text-emerald-400" />
      <Stat
        value={`${phonesStreaming.toLocaleString("en-IN")} · ${verifiedPct}%`}
        label="phone sensors · verified"
        color="text-cyan-300"
      />
    </div>
  );
}
