/**
 * Seismic Sentinel — phone seismometer detector.
 *
 * Classic STA/LTA trigger with one production-grade refinement: the LTA
 * baseline is an event-gated EMA — it freezes while strong motion is in
 * progress so an event never dilutes its own reference (the failure mode
 * of naive trailing-window STA/LTA on long events). Runs fully on-device.
 */

export interface SeismoSample {
  t: number; // ms
  a: number; // acceleration magnitude (m/s²), gravity-removed
}

export class StaLtaDetector {
  private buf: SeismoSample[] = [];
  private maxAgeMs = 40_000;
  staWindowMs = 1_000;
  private lta = 0.15; // background rms estimate (m/s²)
  private lastT = 0;
  private aboveSince: number | null = null;

  push(s: SeismoSample) {
    this.buf.push(s);
    const cutoff = s.t - this.maxAgeMs;
    while (this.buf.length && this.buf[0].t < cutoff) this.buf.shift();
    if (this.buf.length > 6000) this.buf.splice(0, this.buf.length - 6000);

    const sta = this.rms(s.t - this.staWindowMs, s.t);
    const dt = this.lastT ? Math.min(2000, s.t - this.lastT) : 50;
    this.lastT = s.t;

    // Event-gated baseline: only relax the LTA when the current STA is at
    // background level (<= 2x baseline). During strong motion it freezes,
    // so STA/LTA peaks reflect real event contrast.
    if (sta <= 2.0 * Math.max(this.lta, 0.02)) {
      const alpha = Math.min(0.5, dt / 10_000);
      this.lta = Math.max(0.02, this.lta + (sta - this.lta) * alpha);
    }

    const threshold = Math.max(0.5, 1.5 * this.lta);
    if (sta >= threshold) {
      if (this.aboveSince === null) this.aboveSince = s.t;
    } else {
      this.aboveSince = null;
    }
  }

  private rms(fromMs: number, toMs: number): number {
    const xs = this.buf.filter((s) => s.t >= fromMs && s.t <= toMs);
    if (xs.length < 3) return 0;
    return Math.sqrt(xs.reduce((acc, s) => acc + s.a * s.a, 0) / xs.length);
  }

  /** Current STA/LTA ratio (STA 1 s vs gated baseline). */
  ratio(now: number): number {
    return this.rms(now - this.staWindowMs, now) / Math.max(this.lta, 0.02);
  }

  /** Dominant frequency (Hz) via zero-crossing count over the STA window. */
  dominantHz(now: number): number {
    const xs = this.buf.filter((s) => s.t >= now - this.staWindowMs);
    if (xs.length < 4) return 0;
    let crossings = 0;
    for (let i = 1; i < xs.length; i++) {
      if (xs[i - 1].a <= 0 && xs[i].a > 0) crossings++;
    }
    const spanS = (xs[xs.length - 1].t - xs[0].t) / 1000;
    if (spanS <= 0) return 0;
    return crossings / spanS; // positive-going crossings ≈ Hz
  }

  /** Seconds the STA has stayed above the trigger threshold. */
  sustainedS(now: number): number {
    if (this.aboveSince === null) return 0;
    return Math.min(20, (now - this.aboveSince) / 1000);
  }
}

export interface DetectorVerdict {
  verdict: "QUAKE" | "BUMP" | "NOISE";
  confidence: number; // 0..1
  magnitude: number; // rough estimate for display
  ratio: number;
  dominantHz: number;
}

/**
 * Classification: real quakes = sustained 2–12 Hz shaking with high STA/LTA
 * for >4 s. A door slam is short and broadband; walking is low-frequency.
 */
export function classify(
  ratio: number,
  dominantHz: number,
  sustainedS: number
): DetectorVerdict {
  let verdict: DetectorVerdict["verdict"] = "NOISE";
  const freqOk = dominantHz >= 1.5 && dominantHz <= 15;
  if (ratio >= 3.5 && sustainedS >= 4 && freqOk) verdict = "QUAKE";
  else if (ratio >= 3.0 && sustainedS < 3) verdict = "BUMP";

  const conf =
    verdict === "QUAKE"
      ? Math.min(0.98, 0.6 + (ratio - 3.5) * 0.06 + Math.min(4, sustainedS) * 0.05)
      : verdict === "BUMP"
        ? Math.min(0.9, 0.55 + ratio * 0.04)
        : 0.8;

  const magnitude =
    verdict === "QUAKE"
      ? Math.round((2.2 + Math.log10(Math.max(1, ratio)) * 2.4 + sustainedS * 0.12) * 10) / 10
      : 0;
  return { verdict, confidence: conf, magnitude, ratio, dominantHz };
}

/** Synthetic background noise (hand tremor / traffic) around ~0.15 m/s². */
export function ambientNoise(t: number): number {
  return (
    0.13 +
    0.05 * Math.sin(t / 470) +
    0.04 * Math.sin(t / 131 + 1.3) +
    0.03 * Math.sin(t / 61 + 0.7) +
    (Math.random() - 0.5) * 0.05
  );
}

/** Synthetic quake envelope: P-wave burst → S-wave peak → decay. */
export function quakeWaveform(elapsedMs: number, mag: number): number {
  if (elapsedMs < 0) return 0;
  const t = elapsedMs / 1000;
  const peak = 1.2 + (mag - 4) * 1.6;
  if (t < 0.8) return peak * 0.35 * Math.sin(t * 34) * (t / 0.8); // P
  if (t < 6) return peak * Math.sin(t * 18) * Math.exp(-(t - 0.8) * 0.28); // S
  return peak * 0.5 * Math.sin(t * 11) * Math.exp(-(t - 0.8) * 0.55); // coda
}
