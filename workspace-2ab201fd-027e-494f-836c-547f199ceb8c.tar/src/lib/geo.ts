import type { LatLng } from "./types";

const EARTH_R_KM = 6371;

export function haversineKm(a: LatLng, b: LatLng): number {
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLng = ((b.lng - a.lng) * Math.PI) / 180;
  const la1 = (a.lat * Math.PI) / 180;
  const la2 = (b.lat * Math.PI) / 180;
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(la1) * Math.cos(la2) * Math.sin(dLng / 2) ** 2;
  return 2 * EARTH_R_KM * Math.asin(Math.sqrt(h));
}

/** Move `from` towards `to` by `distKm`. Returns new point (or `to` if closer). */
export function moveTowards(from: LatLng, to: LatLng, distKm: number): LatLng {
  const d = haversineKm(from, to);
  if (d <= distKm || d === 0) return { ...to };
  const f = distKm / d;
  // equirectangular approx is fine at city scale
  const lat = from.lat + (to.lat - from.lat) * f;
  const lng = from.lng + (to.lng - from.lng) * f;
  return { lat, lng };
}

/** Random point uniformly inside a circle (km) around c. */
export function randomInCircle(c: LatLng, radiusKm: number): LatLng {
  const r = radiusKm * Math.sqrt(Math.random());
  const theta = Math.random() * 2 * Math.PI;
  const dLat = (r * Math.cos(theta)) / 110.574;
  const dLng =
    (r * Math.sin(theta)) / (111.32 * Math.cos((c.lat * Math.PI) / 180));
  return { lat: c.lat + dLat, lng: c.lng + dLng };
}

export function clamp(v: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, v));
}

/** Modeled strong-shaking radius (km) for a shallow crustal quake. */
export function quakeRadiusKm(mag: number): number {
  return Math.round(Math.pow(10, 0.4 * mag - 0.9));
}
