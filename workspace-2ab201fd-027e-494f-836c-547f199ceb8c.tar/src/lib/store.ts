"use client";

import { create } from "zustand";
import type {
  Detection,
  FireHotspot,
  HazardEvent,
  Hospital,
  LatLng,
  OfficialAlert,
  Responder,
  SafeZone,
  ScenarioKind,
  Sos,
  SosType,
  UsgsQuake,
  LoopStage,
} from "./types";
import {
  CYCLONE_TRACK,
  FLOOD_ZONES,
  HOSPITALS,
  QUAKE_EPICENTER,
  FIRE_ORIGIN,
  SAFE_ZONES,
  buildResponders,
} from "./data";
import { haversineKm, moveTowards, quakeRadiusKm, randomInCircle } from "./geo";
import { inHazardZone, triage } from "./triage";
import { signAlert } from "./crypto";

/** 1 real second = 30 sim seconds — demo time compression. */
const TIME_SCALE = 30;

const SOS_POOL: { type: SosType; note: string; people: number }[] = [
  { type: "trapped", note: "Building collapsed near metro pillar, 3 people trapped under debris", people: 3 },
  { type: "medical", note: "Elderly man unconscious, not breathing properly", people: 1 },
  { type: "medical", note: "Child injured and bleeding from head, need ambulance urgently", people: 2 },
  { type: "fire", note: "Smoke and flames spreading in apartment kitchen, ground floor", people: 6 },
  { type: "flood", note: "Pregnant woman needs evacuation, water rising fast in lane", people: 2 },
  { type: "flood", note: "Family of 5 stranded on rooftop, water at first floor", people: 5 },
  { type: "structural", note: "Wide crack in wall after tremor, shop occupants stuck inside", people: 4 },
  { type: "trapped", note: "Many people pinned under fallen scaffolding at site", people: 7 },
  { type: "medical", note: "Two-wheeler accident on service road, rider bleeding", people: 2 },
  { type: "general", note: "Power lines down across street, neighbours asking for help", people: 3 },
];

interface PendingAlert {
  alert: OfficialAlert;
  releaseAt: number;
}

interface SurakshaState {
  // sim control
  scenario: ScenarioKind | null;
  t: number; // scenario clock (real seconds since start)
  towersDown: boolean;
  sosArmed: boolean;
  showUsgs: boolean;
  viewCommand: { nonce: number; target: "hyderabad" | "coast" | "fire" } | null;

  // world
  hazards: HazardEvent[];
  soss: Sos[];
  responders: Responder[];
  hospitals: Hospital[];
  safeZones: SafeZone[];
  alerts: OfficialAlert[];
  pendingAlerts: PendingAlert[];
  detection: Detection | null;
  fireHotspots: FireHotspot[];
  seismoQuake: { startAt: number; mag: number } | null;
  usgsQuakes: UsgsQuake[];
  usgsFetchedAt: number | null;

  // stats
  peopleAlerted: number;
  peopleAlertedCap: number;
  phonesStreaming: number;
  dispatchedCount: number;
  resolvedCount: number;
  loopStage: LoopStage;

  // actions
  startScenario: (kind: ScenarioKind) => void;
  resetSim: () => void;
  tick: () => void;
  setTowersDown: (v: boolean) => void;
  toggleSosArmed: () => void;
  toggleUsgs: () => void;
  triggerDetection: (d: Detection) => void;
  addCitizenSos: (type: SosType, note: string, pos: LatLng) => void;
  setUsgs: (quakes: UsgsQuake[]) => void;
  setFirms: (hotspots: FireHotspot[]) => void;
}

const nowMs = () => Date.now();
const uid = (p: string) => `${p}-${Math.random().toString(36).slice(2, 8)}`;

function freshWorld() {
  return {
    hazards: [] as HazardEvent[],
    soss: [] as Sos[],
    responders: buildResponders(),
    hospitals: HOSPITALS.map((h) => ({ ...h })),
    safeZones: SAFE_ZONES.map((s) => ({ ...s })),
    alerts: [] as OfficialAlert[],
    pendingAlerts: [] as PendingAlert[],
    detection: null as Detection | null,
    fireHotspots: [] as FireHotspot[],
    seismoQuake: null as { startAt: number; mag: number } | null,
  };
}

async function buildAlert(
  agency: string,
  severity: OfficialAlert["severity"],
  headline: string,
  body: string,
  hi: string,
  te: string,
  kind: OfficialAlert["kind"],
  towersDown: boolean,
  affectedKm?: number
): Promise<OfficialAlert> {
  const at = nowMs();
  const sig = await signAlert(agency, headline, at);
  return {
    id: uid("al"),
    at,
    agency,
    severity,
    headline,
    body,
    hi,
    te,
    sig,
    verified: true,
    hops: towersDown ? 1 + Math.floor(Math.random() * 3) : 0,
    kind,
    affectedKm,
  };
}

export const useSuraksha = create<SurakshaState>((set, get) => ({
  scenario: null,
  t: 0,
  towersDown: false,
  sosArmed: false,
  showUsgs: false,
  viewCommand: null,
  ...freshWorld(),
  usgsQuakes: [],
  usgsFetchedAt: null,
  peopleAlerted: 0,
  peopleAlertedCap: 0,
  phonesStreaming: 12_847,
  dispatchedCount: 0,
  resolvedCount: 0,
  loopStage: "observe",

  setUsgs: (quakes) => set({ usgsQuakes: quakes, usgsFetchedAt: nowMs() }),
  setFirms: (hotspots) =>
    set((s) => (s.fireHotspots.length ? s : { fireHotspots: hotspots })),
  setTowersDown: (v) => set({ towersDown: v }),
  toggleSosArmed: () => set((s) => ({ sosArmed: !s.sosArmed })),
  toggleUsgs: () => set((s) => ({ showUsgs: !s.showUsgs })),

  startScenario: (kind) => {
    const world = freshWorld();
    set({
      scenario: kind,
      t: 0,
      peopleAlerted: 0,
      peopleAlertedCap: 0,
      dispatchedCount: 0,
      resolvedCount: 0,
      loopStage: "observe",
      ...world,
      viewCommand: {
        nonce: nowMs(),
        target:
          kind === "cyclone" ? "coast" : kind === "fire" ? "fire" : "hyderabad",
      },
    });
    if (kind === "quake") {
      set({
        peopleAlertedCap: 1_850_000,
        seismoQuake: { startAt: nowMs() + 1500, mag: 5.7 },
        hazards: [
          {
            id: uid("hz"),
            kind: "quake",
            title: "M5.7 — Medchal–Malkajgiri border (SIM)",
            source: "SMS-AI",
            epicenter: QUAKE_EPICENTER,
            radiusKm: 0,
            maxRadiusKm: quakeRadiusKm(5.7),
            startedAt: nowMs(),
            active: true,
          },
        ],
      });
    }
    if (kind === "cyclone") {
      set({
        peopleAlertedCap: 3_200_000,
        hazards: [
          {
            id: uid("hz"),
            kind: "cyclone",
            title: "SIM-CY 01 'Bhairavi' — severe cyclonic storm",
            source: "IMD/INCOIS",
            epicenter: CYCLONE_TRACK[0],
            track: CYCLONE_TRACK,
            trackIndex: 0,
            windKmph: 95,
            category: "Cyclonic Storm",
            radiusKm: 180,
            maxRadiusKm: 240,
            startedAt: nowMs(),
            active: true,
          },
        ],
      });
    }
    if (kind === "flood") {
      set({
        peopleAlertedCap: 1_200_000,
        hazards: [
          {
            id: uid("hz"),
            kind: "flood",
            title: "Flash flood — low-lying GHMC zones (SIM)",
            source: "IMD/GHMC",
            epicenter: { lat: 17.4126, lng: 78.4392 },
            radiusKm: 8,
            maxRadiusKm: 13,
            waterLevelM: 0.3,
            startedAt: nowMs(),
            active: true,
          },
        ],
      });
    }
    if (kind === "fire") {
      set({
        peopleAlertedCap: 64_000,
        hazards: [
          {
            id: uid("hz"),
            kind: "fire",
            title: "Wildfire — Ananthagiri Hills, Vikarabad (SIM)",
            source: "FSI / VIIRS",
            epicenter: FIRE_ORIGIN,
            radiusKm: 0.5,
            maxRadiusKm: 3.6,
            spreadKm: 0.5,
            windFromDeg: 250,
            startedAt: nowMs(),
            active: true,
          },
        ],
        fireHotspots: Array.from({ length: 12 }, (_, i) => ({
          id: `fh-${i}`,
          lat: FIRE_ORIGIN.lat + (Math.random() - 0.5) * 0.06,
          lng: FIRE_ORIGIN.lng + (Math.random() - 0.5) * 0.07,
          confidence: "h",
          frp: 40 + Math.round(Math.random() * 160),
          acquired: "VIIRS 375m · 05:47 IST",
          simulated: true,
        })),
      });
    }
  },

  resetSim: () =>
    set({
      scenario: null,
      t: 0,
      peopleAlerted: 0,
      peopleAlertedCap: 0,
      dispatchedCount: 0,
      resolvedCount: 0,
      loopStage: "observe",
      ...freshWorld(),
    }),

  triggerDetection: (d) => {
    const st = get();
    if (st.detection) return;
    set({ detection: d });
    if (d.verdict === "QUAKE") {
      const hz = st.hazards.find((h) => h.kind === "quake");
      if (hz) {
        const m = Math.max(4.2, d.magnitude);
        set({
          hazards: st.hazards.map((h) =>
            h.id === hz.id
              ? { ...h, magnitude: m, maxRadiusKm: quakeRadiusKm(m) }
              : h
          ),
        });
      }
      // detection evidence alert — signed like every official alert
      void buildAlert(
        "SURAKSHA-AI",
        "CRITICAL",
        `Quake signature confirmed · M${d.magnitude.toFixed(1)} · ${(d.confidence * 100).toFixed(0)}% confidence`,
        `Phone seismometer network: sustained ${d.dominantHz.toFixed(1)} Hz shaking for ${d.durationS.toFixed(1)} s, STA/LTA peak ${d.ratio.toFixed(1)}. Cross-checking USGS feed for corroboration.`,
 "फ़ोन सेंसर नेटवर्क ने भूकंप की पुष्टि की — सुरक्षित रहें।",
        "ఫోన్ సెన్సార్ నెట్‌వర్క్ భూకంపాన్ని నిర్ధారించింది — జాగ్రత్తగా ఉండండి.",
        "quake",
        st.towersDown
      ).then((a) => {
        set((prev) => ({
          pendingAlerts: [
            ...prev.pendingAlerts,
            { alert: a, releaseAt: nowMs() },
          ],
        }));
      });
    }
  },

  addCitizenSos: (type, note, pos) => {
    const st = get();
    const hz = st.hazards.find((h) => h.active) ?? null;
    const inZone = hz ? inHazardZone(pos, hz) : false;
    const tr = triage(type, note, 2, inZone);
    const sos: Sos = {
      id: uid("sos"),
      pos,
      type,
      note,
      peopleCount: 2,
      createdAt: nowMs(),
      severity: tr.severity,
      score: tr.score,
      confidence: tr.confidence,
      status: "open",
      hops: st.towersDown ? 1 + Math.floor(Math.random() * 3) : 0,
      source: "citizen",
    };
    const soss = [sos, ...st.soss];
    const res = dispatchNearestArrays({
      responders: st.responders,
      hospitals: st.hospitals,
      soss,
      sos,
    });
    set({
      soss: res.soss,
      responders: res.responders,
      hospitals: res.hospitals,
      dispatchedCount: st.dispatchedCount + (res.dispatched ? 1 : 0),
    });
  },

  tick: () => {
    const st = get();
    if (!st.scenario) return;
    const t = st.t + 1;
    const dtSim = 1 * TIME_SCALE; // sim-seconds elapsed

    let hazards = st.hazards;
    let soss = st.soss;
    let responders = st.responders;
    let hospitals = st.hospitals;
    let safeZones = st.safeZones;
    let alerts = st.alerts;
    let pending = st.pendingAlerts;
    let peopleAlerted = st.peopleAlerted;
    let loopStage: LoopStage = st.loopStage;

    const push = (a: OfficialAlert) => {
      const releaseAt = nowMs() + (st.towersDown ? 2000 + a.hops * 1500 : 0);
      set((prev) => ({
        pendingAlerts: [
          ...prev.pendingAlerts,
          { alert: a, releaseAt },
        ] as PendingAlert[],
      }));
      pending = get().pendingAlerts;
    };

    // ---- release mesh-delayed alerts ----
    const due = pending.filter((p) => p.releaseAt <= nowMs());
    if (due.length) {
      alerts = [...due.map((p) => p.alert), ...alerts].slice(0, 60);
      pending = pending.filter((p) => p.releaseAt > nowMs());
    }

    const hz = hazards[0];
    let dispatched = 0;
    const spawnSos = () => {
      const pick =
        SOS_POOL[Math.floor(Math.random() * SOS_POOL.length)];
      const center =
        st.scenario === "flood"
          ? FLOOD_ZONES[Math.floor(Math.random() * FLOOD_ZONES.length)].pos
          : hz.epicenter;
      const spread =
        st.scenario === "flood" ? 1.2 : Math.max(2, hz.radiusKm * 0.75);
      const pos = randomInCircle(center, spread);
      const inZone = inHazardZone(pos, hz);
      const tr = triage(pick.type, pick.note, pick.people, inZone);
      const sos: Sos = {
        id: uid("sos"),
        pos,
        type: pick.type,
        note: pick.note,
        peopleCount: pick.people,
        createdAt: nowMs(),
        severity: tr.severity,
        score: tr.score,
        confidence: tr.confidence,
        status: "open",
        hops: st.towersDown ? 1 + Math.floor(Math.random() * 3) : 0,
        source: "auto",
      };
      soss = [sos, ...soss];
      const res = dispatchNearestArrays({ responders, hospitals, soss, sos });
      responders = res.responders;
      hospitals = res.hospitals;
      soss = res.soss;
      if (res.dispatched) dispatched++;
    };

    // ================= scenario timelines =================
    if (st.scenario === "quake" && hz) {
      if (t >= 6 && !alerts.some((a) => a.agency === "IMD")) {
        void buildAlert(
          "IMD",
          "CRITICAL",
          `Earthquake early warning · M${hz.magnitude?.toFixed(1) ?? "5.7"} · Telangana`,
          `Shaking felt across Hyderabad metro. Take cover: DROP, COVER, HOLD. Stay away from glass and facades. Aftershocks likely for 48 h.`,
          "भूकंप की चेतावनी — झुकें, ढकें, थमें रहें। काँच और इमारतों के किनारों से दूर रहें।",
          "భూకంప హెచ్చరిక — కిందికి వంగి, కప్పుకోండి, ఆగి ఉండండి. గాజు, భవనాల అంచులకు దూరంగా ఉండండి.",
          "quake",
          st.towersDown,
          hz.maxRadiusKm
        ).then(push);
      }
      if (hz.radiusKm < hz.maxRadiusKm)
        hazards = hazards.map((h) =>
          h.id === hz.id
            ? { ...h, radiusKm: Math.min(h.maxRadiusKm, h.radiusKm + h.maxRadiusKm * 0.18) }
            : h
        );
      if (t > 8 && t < 46 && t % 4 === 0 && soss.filter((s) => s.status !== "resolved").length < 9) spawnSos();
    }

    if (st.scenario === "cyclone" && hz) {
      const legEvery = 12; // real seconds per track leg
      const idx = Math.min(CYCLONE_TRACK.length - 1, Math.floor(t / legEvery));
      const nextPos = CYCLONE_TRACK[idx];
      hazards = hazards.map((h) =>
        h.id === hz.id
          ? {
              ...h,
              trackIndex: idx,
              epicenter: nextPos,
              windKmph: Math.min(185, 95 + idx * 18),
              category:
                idx <= 1 ? "Cyclonic Storm" : idx <= 3 ? "Severe Cyclonic Storm" : "Very Severe Cyclonic Storm",
              radiusKm: Math.min(h.maxRadiusKm, 180 + idx * 15),
            }
          : h
      );
      if (t >= 3 && !alerts.some((a) => a.agency === "INCOIS")) {
        void buildAlert(
          "INCOIS",
          "WARNING",
          "Storm surge 1.5–2.5 m expected · Bapatla–Ongole coast",
          "Fishermen advised NOT to venture into Bay of Bengal. Low-lying coastal mandals: be ready to move to shelters.",
          "तटीय मंडलों में तूफ़ानी लहरें — मछुआरे समुद्र में न जाएँ, आश्रय के लिए तैयार रहें।",
          "తీర ప్రాంతాల్లో తుఫాను అలలు — మత్స్యకారులు సముద్రంలోకి వెళ్లవద్దు, షెల్టర్లకు సిద్ధంగా ఉండండి.",
          "cyclone",
          st.towersDown
        ).then(push);
      }
      if (t >= 10 && !alerts.some((a) => a.kind === "cyclone" && a.agency === "IMD")) {
        void buildAlert(
          "IMD",
          "WARNING",
          "Cyclone 'Bhairavi' (SIM) landfall near Bapatla in ~6 h",
          "Heavy to extremely heavy rainfall in coastal AP. Evacuation of low-lying mandals in progress. Follow NDMA instructions.",
          "चक्रवाती तूफ़ान — तटीय आंध्र में भारी वर्षा। निचले इलाकों से सुरक्षित स्थानों पर जाएँ।",
          "తుఫాను 'భైరవి' — తీర ఆంధ్రలో భారీ వర్ష. తక్కువ ప్రాంతాల నుండి సురక్షిత కేంద్రాలకు వెళ్లండి.",
          "cyclone",
          st.towersDown
        ).then(push);
      }
      if (t > 14 && t < 50 && t % 6 === 0 && soss.filter((s) => s.status !== "resolved").length < 6) spawnSos();
      safeZones = safeZones.map((z) => ({
        ...z,
        occupancy: Math.min(z.capacity, z.occupancy + Math.round(z.capacity * 0.02)),
      }));
    }

    if (st.scenario === "flood" && hz) {
      const level = Math.min(2.4, 0.3 + t * 0.045);
      hazards = hazards.map((h) =>
        h.id === hz.id
          ? { ...h, waterLevelM: level, radiusKm: Math.min(h.maxRadiusKm, 8 + t * 0.12) }
          : h
      );
      if (t >= 4 && !alerts.some((a) => a.kind === "flood")) {
        void buildAlert(
          "IMD",
          "WARNING",
          "Extreme rainfall 210 mm in 3 h · GHMC low-lying zones",
          "Balkapur, Falaknuma, Alwal, KPHB, Amberpet, Bandlaguda: water levels rising. Move to designated GHMC shelters. Do NOT enter waterlogged streets.",
          "कम ऊँचाई वाले इलाकों में बाढ़ — पानी भरे रास्तों में न जाएँ, आश्रय केंद्रों में जाएँ।",
          "తక్కువ ప్రాంతాల్లో వరద — నీరు నిలిచిన వీధుల్లోకి వెళ్లవద్దు, షెల్టర్లకు వెళ్లండి.",
          "flood",
          st.towersDown
        ).then(push);
      }
      if (t > 10 && t < 44 && t % 5 === 0 && soss.filter((s) => s.status !== "resolved").length < 7) spawnSos();
      if (t % 2 === 0)
        safeZones = safeZones.map((z) => ({
          ...z,
          occupancy: Math.min(z.capacity, z.occupancy + Math.round(z.capacity * 0.03)),
        }));
    }

    if (st.scenario === "fire" && hz) {
      const spread = Math.min(hz.maxRadiusKm, (hz.spreadKm ?? 0.5) + 0.12);
      hazards = hazards.map((h) =>
        h.id === hz.id ? { ...h, spreadKm: spread, radiusKm: spread } : h
      );
      if (t >= 3 && !alerts.some((a) => a.kind === "fire")) {
        void buildAlert(
          "FSI",
          "WARNING",
          "Active wildfire · Ananthagiri Hills (VIIRS 12 hotspots)",
          "Fire spreading NE with 18 km/h winds. Villages within 4 km: keep cattle shed doors clear, prepare to move toward Chevella road shelters.",
          "वनाग्नि — आसपास के गाँव सतर्क रहें, धुएँ से बचें, निर्धारित आश्रय की ओर बढ़ें।",
          "అడవి మంటలు — సమీప గ్రామాలు అప్రమత్తంగా ఉండండి, షెల్టర్ల వైపు కదలండి.",
          "fire",
          st.towersDown,
          4
        ).then(push);
      }
      if (t > 12 && t < 40 && t % 7 === 0 && soss.filter((s) => s.status !== "resolved").length < 4) spawnSos();
    }

    // ---- alert fan-out ramp ----
    const cap = st.peopleAlertedCap;
    if (cap > 0 && peopleAlerted < cap && hz?.active)
      peopleAlerted = Math.min(cap, peopleAlerted + Math.round(cap / 22));

    // ---- responder movement + status machine ----
    responders = responders.map((r) => {
      if (r.status === "enroute" && r.targetSosId) {
        const sos = soss.find((s) => s.id === r.targetSosId);
        if (!sos || sos.status === "resolved")
          return { ...r, status: "idle", targetSosId: undefined };
        const stepKm = (r.speedKmph * dtSim) / 3600;
        const pos = moveTowards(r.pos, sos.pos, stepKm);
        const d = haversineKm(pos, sos.pos);
        if (d < 0.05) {
          return { ...r, pos, status: "onsite", onsiteSince: nowMs() };
        }
        return { ...r, pos };
      }
      if (r.status === "onsite") {
        if (r.onsiteSince && nowMs() - r.onsiteSince > 4500 && r.targetSosId) {
          const targetId = r.targetSosId;
          soss = soss.map((s) =>
            s.id === targetId ? { ...s, status: "resolved" } : s
          );
          set({ resolvedCount: get().resolvedCount + 1 });
          return {
            ...r,
            status: "returning",
            targetSosId: undefined,
            onsiteSince: undefined,
          };
        }
        return r;
      }
      if (r.status === "returning") {
        const stepKm = (r.speedKmph * dtSim) / 3600;
        const pos = moveTowards(r.pos, r.homePos, stepKm);
        const d = haversineKm(pos, r.homePos);
        if (d < 0.05) return { ...r, pos, status: "idle" };
        return { ...r, pos };
      }
      return r;
    });

    // ---- hospital notify for P1 with assigned responder ----
    hospitals = hospitals.map((h) => {
      if (h.notified) return h;
      const p1 = soss.some(
        (s) => s.assignedHospitalId === h.id && s.severity === "P1"
      );
      return p1 ? { ...h, notified: true } : h;
    });

    // ---- loop stage (the rubric rail) ----
    loopStage =
      t > 3 && (st.detection || hz?.radiusKm)
        ? soss.length
          ? st.dispatchedCount > 0 || peopleAlerted > 1000
            ? "protect"
            : "assess"
          : "analyse"
        : "observe";

    set({
      t,
      hazards,
      soss,
      responders,
      hospitals,
      safeZones,
      alerts,
      pendingAlerts: pending,
      peopleAlerted,
      dispatchedCount: st.dispatchedCount + dispatched,
      loopStage,
      phonesStreaming: 12_847 + Math.round((Math.random() - 0.5) * 240),
    });
  },
}));

// ---------- dispatch ----------

function preferredKinds(type: SosType): Responder["kind"][] {
  switch (type) {
    case "medical":
      return ["ambulance"];
    case "fire":
      return ["fire", "ambulance"];
    case "trapped":
    case "structural":
      return ["rescue", "ambulance"];
    case "flood":
      return ["rescue", "ambulance"];
    default:
      return ["ambulance", "rescue"];
  }
}

interface DispatchCtx {
  responders: Responder[];
  hospitals: Hospital[];
  soss: Sos[];
  sos: Sos;
}

/** Dispatch nearest preferred responder + notify nearest trauma hospital for P1.
 *  Pure: operates on (and returns) the given arrays — callers own persistence. */
function dispatchNearestArrays(
  ctx: DispatchCtx
): {
  responders: Responder[];
  hospitals: Hospital[];
  soss: Sos[];
  dispatched: boolean;
} {
  const { hospitals, sos } = ctx;
  const prefs = preferredKinds(sos.type);
  let pool = ctx.responders.filter(
    (r) => r.status === "idle" && prefs.includes(r.kind)
  );
  if (!pool.length)
    pool = ctx.responders.filter((r) => r.status === "idle");
  if (!pool.length)
    return { responders: ctx.responders, hospitals, soss: ctx.soss, dispatched: false };
  pool.sort(
    (a, b) => haversineKm(a.pos, sos.pos) - haversineKm(b.pos, sos.pos)
  );
  const unit = pool[0];

  const newResponders = ctx.responders.map((r) =>
    r.id === unit.id
      ? { ...r, status: "enroute" as const, targetSosId: sos.id }
      : r
  );

  let newHospitals = hospitals;
  let hospitalId: string | undefined;
  if (sos.severity === "P1") {
    const trauma = hospitals
      .filter((h) => h.trauma && h.bedsFree > 0)
      .sort(
        (a, b) => haversineKm(a.pos, sos.pos) - haversineKm(b.pos, sos.pos)
      );
    if (trauma[0]) {
      hospitalId = trauma[0].id;
      newHospitals = hospitals.map((h) =>
        h.id === hospitalId
          ? { ...h, notified: true, bedsFree: h.bedsFree - 1 }
          : h
      );
    }
  }

  const newSoss = ctx.soss.map((s) =>
    s.id === sos.id
      ? {
          ...s,
          status: "assigned" as const,
          assignedResponderId: unit.id,
          assignedHospitalId: hospitalId,
        }
      : s
  );

  return { responders: newResponders, hospitals: newHospitals, soss: newSoss, dispatched: true };
}
