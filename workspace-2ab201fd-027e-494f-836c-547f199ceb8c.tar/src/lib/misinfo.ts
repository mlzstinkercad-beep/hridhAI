/**
 * Misinformation shield — disaster lies kill.
 * Heuristic classifier: urgent-forward language + unverifiable claims +
 * absence of an official signature → risk verdict. Explainable by design.
 */

export interface MisinfoVerdict {
  risk: "LIKELY_GENUINE" | "UNVERIFIED" | "LIKELY_FALSE";
  score: number; // 0..100 (higher = more likely false)
  reasons: string[];
}

const FALSE_CUES: { re: RegExp; w: number; label: string }[] = [
  { re: /dam (has )?(broke|breach|burst|crack)/i, w: 30, label: "catastrophic dam-breach claim" },
  { re: /blast|explosion|attack|terroris/i, w: 24, label: "unconfirmed attack claim" },
  { re: /share (this|max|widely)|forward (this|to all|max)|send to (all|every)/i, w: 20, label: "viral forward chain" },
  { re: /dead bodies|hundreds died|thousands died|mass death/i, w: 22, label: "unverified casualty figures" },
  { re: /!{3,}|\?{2,}/i, w: 10, label: "panic punctuation" },
  { re: /^[A-Z\s!5-9]{40,}$/m, w: 12, label: "ALL-CAPS block" },
  { re: /whatsapp|forwarded many times|viral/i, w: 12, label: "chain-message marker" },
  { re: /no (one|body) is (telling|saying)|media won'?t show/i, w: 14, label: "conspiracy framing" },
  { re: /god (forbid|help)|pray/i, w: 4, label: "emotional appeal" },
];

const GENUINE_CUES: { re: RegExp; w: number; label: string }[] = [
  { re: / IMD |IMD:|India Meteorological/i, w: 14, label: "cites IMD" },
  { re: / NDMA |SDRF|NDRF|INCOIS/i, w: 12, label: "cites official agency" },
  { re: /helpline|1(?:08|12)|toll[- ]?free/i, w: 8, label: "official helpline" },
  { re: /advisory|bulletin|update \d/i, w: 6, label: "bulletin style" },
];

export function analyzeForward(text: string): MisinfoVerdict {
  const reasons: string[] = [];
  let score = 18; // baseline: unknown origin

  for (const c of FALSE_CUES) {
    if (c.re.test(text)) {
      score += c.w;
      reasons.push(`⚠ ${c.label} (+${c.w})`);
    }
  }
  for (const c of GENUINE_CUES) {
    if (c.re.test(text)) {
      score -= c.w;
      reasons.push(`✓ ${c.label} (−${c.w})`);
    }
  }
  score = Math.max(0, Math.min(100, score));

  const risk: MisinfoVerdict["risk"] =
    score >= 55 ? "LIKELY_FALSE" : score >= 32 ? "UNVERIFIED" : "LIKELY_GENUINE";
  if (reasons.length === 0)
    reasons.push("no official signature, no official agency citation");
  return { risk, score, reasons };
}
