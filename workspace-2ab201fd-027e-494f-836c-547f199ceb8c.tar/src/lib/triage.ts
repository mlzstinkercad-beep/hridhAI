import type { HazardEvent, SosType, Severity } from "./types";

/**
 * TriAI — severity triage model v0.9 (demo)
 * Transparent scoring: type weight + lexical cues + hazard proximity.
 * Deliberately rule-based so judges can audit every point.
 */

const TYPE_WEIGHT: Record<SosType, number> = {
  trapped: 34,
  fire: 31,
  medical: 30,
  structural: 26,
  flood: 22,
  general: 12,
};

const CUES: { re: RegExp; w: number; label: string }[] = [
  { re: /unconscious|not breathing|no pulse/i, w: 12, label: "unconscious" },
  { re: /pregnan/i, w: 9, label: "pregnant" },
  { re: /child|baby|infant|kid/i, w: 8, label: "child involved" },
  { re: /elderly|old age|paralys/i, w: 7, label: "elderly" },
  { re: /bleed|blood/i, w: 8, label: "bleeding" },
  { re: /many people|lots of|several|family of/i, w: 6, label: "multiple victims" },
  { re: /trapped|pin|debris|rubble|collapsed/i, w: 6, label: "entrapment" },
  { re: /water rising|drowning|swept/i, w: 7, label: "active flooding" },
  { re: /smoke|flame|burn/i, w: 6, label: "active fire" },
];

export interface TriageResult {
  score: number;
  severity: Severity;
  confidence: number;
  reasons: string[];
}

export function triage(
  type: SosType,
  note: string,
  peopleCount: number,
  insideHazardZone: boolean
): TriageResult {
  let score = TYPE_WEIGHT[type];
  const reasons = [`type:${type}(+${TYPE_WEIGHT[type]})`];

  for (const c of CUES) {
    if (c.re.test(note)) {
      score += c.w;
      reasons.push(`${c.label}(+${c.w})`);
    }
  }
  if (peopleCount >= 5) {
    score += 6;
    reasons.push(`crowd(${peopleCount})(+6)`);
  } else if (peopleCount >= 2) {
    score += 3;
    reasons.push(`multi-person(+3)`);
  }
  if (insideHazardZone) {
    score += 8;
    reasons.push("inside active hazard zone(+8)");
  }
  score = Math.min(70, score);

  const severity: Severity = score >= 42 ? "P1" : score >= 28 ? "P2" : "P3";
  const confidence = Math.min(
    0.97,
    0.62 + reasons.length * 0.045 + (note.length > 24 ? 0.06 : 0)
  );
  return { score, severity, confidence, reasons };
}

/** Distance from a SOS to a hazard epicenter, with in-zone check. */
export function inHazardZone(pos: { lat: number; lng: number }, h: HazardEvent): boolean {
  if (!h.active) return false;
  const R = 6371;
  const dLat = ((pos.lat - h.epicenter.lat) * Math.PI) / 180;
  const dLng = ((pos.lng - h.epicenter.lng) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((h.epicenter.lat * Math.PI) / 180) *
      Math.cos((pos.lat * Math.PI) / 180) *
      Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a)) <= h.radiusKm;
}
