import type { Hospital, Responder, SafeZone, LatLng } from "./types";

/**
 * Static India / Hyderabad reference data for the demo build.
 * Hospitals, 108 EMRI bases, NDRF/SDRF, fire stations — real locations,
 * bed counts are representative values for the simulation.
 */

export const HYDERABAD_CENTER: LatLng = { lat: 17.4126, lng: 78.4392 };
export const KANHA_SHANTI_VANAM: LatLng = { lat: 17.262, lng: 78.156 }; // hackathon venue

export const HOSPITALS: Hospital[] = [
  { id: "h-gandhi", name: "Gandhi Hospital, Secunderabad", pos: { lat: 17.4344, lng: 78.5023 }, beds: 1800, bedsFree: 312, notified: false, kind: "govt", trauma: true },
  { id: "h-osmania", name: "Osmania General Hospital", pos: { lat: 17.3566, lng: 78.4821 }, beds: 1600, bedsFree: 268, notified: false, kind: "govt", trauma: true },
  { id: "h-nims", name: "NIMS, Punjagutta", pos: { lat: 17.4222, lng: 78.4443 }, beds: 1200, bedsFree: 190, notified: false, kind: "govt", trauma: true },
  { id: "h-aiims-bibinagar", name: "AIIMS Bibinagar", pos: { lat: 17.6097, lng: 78.9414 }, beds: 960, bedsFree: 240, notified: false, kind: "govt", trauma: true },
  { id: "h-yashoda", name: "Yashoda Hospitals, Somajiguda", pos: { lat: 17.4239, lng: 78.4492 }, beds: 400, bedsFree: 66, notified: false, kind: "private", trauma: true },
  { id: "h-kims", name: "KIMS Hospital, Secunderabad", pos: { lat: 17.4412, lng: 78.4967 }, beds: 500, bedsFree: 88, notified: false, kind: "private", trauma: true },
  { id: "h-aster", name: "Aster Prime Hospital, Ameerpet", pos: { lat: 17.4374, lng: 78.4487 }, beds: 350, bedsFree: 54, notified: false, kind: "private", trauma: false },
  { id: "h-rainbow", name: "Rainbow Children's Hospital", pos: { lat: 17.4166, lng: 78.4392 }, beds: 300, bedsFree: 41, notified: false, kind: "private", trauma: false },
];

const BASES: { pos: LatLng; kind: Responder["kind"]; agency: string; callsign: string; speed: number }[] = [
  { pos: { lat: 17.4239, lng: 78.5173 }, kind: "ambulance", agency: "108 EMRI", callsign: "108-HYD-C01", speed: 42 },
  { pos: { lat: 17.4849, lng: 78.4138 }, kind: "ambulance", agency: "108 EMRI", callsign: "108-HYD-K02", speed: 42 },
  { pos: { lat: 17.3457, lng: 78.5522 }, kind: "ambulance", agency: "108 EMRI", callsign: "108-HYD-L03", speed: 42 },
  { pos: { lat: 17.4401, lng: 78.3489 }, kind: "ambulance", agency: "108 EMRI", callsign: "108-HYD-G04", speed: 42 },
  { pos: { lat: 17.5311, lng: 78.4867 }, kind: "rescue", agency: "NDRF Bn-10 / SDRF", callsign: "NDRF10-ALPHA", speed: 36 },
  { pos: { lat: 17.5311, lng: 78.4867 }, kind: "rescue", agency: "NDRF Bn-10 / SDRF", callsign: "SDRF-TG-BRAVO", speed: 36 },
  { pos: { lat: 17.4364, lng: 78.5013 }, kind: "fire", agency: "TG Fire Services", callsign: "FIRE-SEC-1", speed: 38 },
  { pos: { lat: 17.3616, lng: 78.5214 }, kind: "fire", agency: "TG Fire Services", callsign: "FIRE-MLKP-2", speed: 38 },
  { pos: { lat: 17.4483, lng: 78.3915 }, kind: "fire", agency: "TG Fire Services", callsign: "FIRE-MDHP-3", speed: 38 },
];

export function buildResponders(): Responder[] {
  return BASES.map((b, i) => ({
    id: `r-${i}`,
    kind: b.kind,
    callsign: b.callsign,
    agency: b.agency,
    pos: { ...b.pos },
    homePos: { ...b.pos },
    speedKmph: b.speed,
    status: "idle" as const,
  }));
}

export const SAFE_ZONES: SafeZone[] = [
  { id: "sz-kanha", name: "Kanha Shanti Vanam (mega shelter)", pos: { lat: 17.262, lng: 78.156 }, radiusKm: 1.2, capacity: 5000, occupancy: 0, kind: "shelter" },
  { id: "sz-nampally", name: "Govt. Degree College ground, Nampally", pos: { lat: 17.386, lng: 78.462 }, radiusKm: 0.5, capacity: 1200, occupancy: 0, kind: "school" },
  { id: "sz-alwal", name: "Community Hall, Alwal", pos: { lat: 17.503, lng: 78.51 }, radiusKm: 0.4, capacity: 800, occupancy: 0, kind: "community" },
  { id: "sz-kukatpally", name: "GHMC ground, Kukatpally", pos: { lat: 17.485, lng: 78.415 }, radiusKm: 0.45, capacity: 1000, occupancy: 0, kind: "open-ground" },
  { id: "sz-necklace", name: "Necklace Road open ground", pos: { lat: 17.4229, lng: 78.4691 }, radiusKm: 0.5, capacity: 1500, occupancy: 0, kind: "open-ground" },
  { id: "sz-uppal", name: "Uppal Stadium evac point", pos: { lat: 17.401, lng: 78.56 }, radiusKm: 0.5, capacity: 2000, occupancy: 0, kind: "open-ground" },
];

/** Low-lying localities that flooded in Hyderabad 2020 — flood scenario zones. */
export const FLOOD_ZONES: { name: string; pos: LatLng; radiusKm: number }[] = [
  { name: "Balkapur nala, Borabanda", pos: { lat: 17.445, lng: 78.44 }, radiusKm: 1.1 },
  { name: "Falaknuma", pos: { lat: 17.33, lng: 78.478 }, radiusKm: 1.0 },
  { name: "Alwal lake outflow", pos: { lat: 17.504, lng: 78.512 }, radiusKm: 1.0 },
  { name: "KPHB colony", pos: { lat: 17.483, lng: 78.413 }, radiusKm: 1.1 },
  { name: "Amberpet", pos: { lat: 17.376, lng: 78.53 }, radiusKm: 0.9 },
  { name: "Bandlaguda", pos: { lat: 17.32, lng: 78.43 }, radiusKm: 1.0 },
];

export const QUAKE_EPICENTER: LatLng = { lat: 17.55, lng: 78.47 }; // Medchal–Malkajgiri border (simulated)
export const FIRE_ORIGIN: LatLng = { lat: 17.332, lng: 78.098 }; // Ananthagiri Hills, Vikarabad forest

/** Simulated cyclone track: Bay of Bengal → landfall near Bapatla coast, AP. */
export const CYCLONE_TRACK: LatLng[] = [
  { lat: 16.8, lng: 84.6 },
  { lat: 16.45, lng: 83.4 },
  { lat: 16.15, lng: 82.3 },
  { lat: 15.95, lng: 81.2 },
  { lat: 15.85, lng: 80.35 }, // landfall
  { lat: 15.7, lng: 79.6 }, // decay
];

export const CYCLONE_COAST_VIEW: [number, number][] = [
  [14.6, 79.0],
  [17.6, 85.2],
];
