// SURAKSHA-AI core types — multi-hazard guardian for India

export type HazardKind = "quake" | "cyclone" | "flood" | "fire";
export type Severity = "P1" | "P2" | "P3";
export type SosType =
  | "medical"
  | "trapped"
  | "fire"
  | "structural"
  | "flood"
  | "general";
export type ResponderKind = "ambulance" | "rescue" | "fire";

export interface LatLng {
  lat: number;
  lng: number;
}

export interface HazardEvent {
  id: string;
  kind: HazardKind;
  title: string;
  source: string; // IMD | NDMA | INCOIS | FSI | USGS | SMS-AI
  epicenter: LatLng;
  magnitude?: number; // quake
  radiusKm: number; // current modeled impact radius
  maxRadiusKm: number;
  startedAt: number; // engine ms
  active: boolean;
  // cyclone
  track?: LatLng[];
  trackIndex?: number;
  windKmph?: number;
  category?: string;
  // fire
  spreadKm?: number;
  windFromDeg?: number;
  // flood
  waterLevelM?: number;
}

export interface Sos {
  id: string;
  pos: LatLng;
  type: SosType;
  note: string;
  peopleCount: number;
  createdAt: number;
  severity: Severity;
  score: number;
  confidence: number;
  assignedResponderId?: string;
  assignedHospitalId?: string;
  status: "open" | "assigned" | "enroute" | "onsite" | "resolved";
  hops: number; // mesh-relay hops used when towers are down
  source: "auto" | "citizen";
}

export interface Responder {
  id: string;
  kind: ResponderKind;
  callsign: string;
  agency: string; // 108 EMRI | SDRF | NDRF | TG Fire Services
  pos: LatLng;
  homePos: LatLng;
  targetSosId?: string;
  speedKmph: number;
  status: "idle" | "enroute" | "onsite" | "returning";
  onsiteSince?: number;
}

export interface Hospital {
  id: string;
  name: string;
  pos: LatLng;
  beds: number;
  bedsFree: number;
  notified: boolean;
  kind: "govt" | "private";
  trauma: boolean;
}

export interface SafeZone {
  id: string;
  name: string;
  pos: LatLng;
  radiusKm: number;
  capacity: number;
  occupancy: number;
  kind: "school" | "community" | "shelter" | "open-ground";
}

export interface OfficialAlert {
  id: string;
  at: number; // wall-clock ms
  agency: string; // IMD | NDMA | INCOIS | SDRF | FSI | SURAKSHA-AI
  severity: "ADVISORY" | "WARNING" | "CRITICAL";
  headline: string;
  body: string;
  hi: string; // Hindi
  te: string; // Telugu
  sig?: string; // ECDSA P-256 signature (hex, truncated for display)
  verified: boolean;
  hops: number; // mesh hops when towers are down (0 = direct tower)
  kind: HazardKind | "system";
  affectedKm?: number;
}

export interface Detection {
  id: string;
  at: number;
  ratio: number; // STA/LTA ratio at trigger
  magnitude: number; // estimated
  confidence: number; // 0..1
  verdict: "QUAKE" | "BUMP" | "NOISE";
  dominantHz: number;
  durationS: number;
}

export interface UsgsQuake {
  id: string;
  mag: number;
  place: string;
  time: number;
  lat: number;
  lng: number;
  depth: number;
}

export interface FireHotspot {
  id: string;
  lat: number;
  lng: number;
  confidence: string; // VIIRS confidence l..h
  frp: number; // fire radiative power
  acquired: string;
  simulated: boolean;
}

export type ScenarioKind = "quake" | "cyclone" | "flood" | "fire";
export type LoopStage = "observe" | "analyse" | "assess" | "protect";
