// Dossier content — sections 6-9
const { h1, h2, h3, body, bullet, caption, note, mkTable } = require("./dossier_helpers");

function sections_B() {
  const c = [];

  // ── 6. Model 4 — Dispatch ──
  c.push(h1("6. Model 4: SOS Triage and Responder-Hospital Matching"));
  c.push(h2("6.1 Honest framing and the three-part decomposition"));
  c.push(body("There is no public dataset of labelled Indian SOS messages, and none will exist before the hackathon — pretending otherwise would be the weakest point of the project. The correct decomposition has three AI components wrapped around one deterministic optimiser: a triage classifier that reads a multilingual SOS message and estimates severity; a demand-forecasting component that learns when and where emergency demand surges; and an assignment optimiser that matches responders to SOS cases and pre-notifies hospitals under capacity constraints. Each part is trainable, demonstrable, and testable on its own, and together they cover the full chain from an SOS ping to a hospital being notified."));
  c.push(h2("6.2 Triage NLP in Telugu, Hindi and English"));
  c.push(body("Base model: MuRIL (Google's multilingual representation model for 17 Indian languages) or IndicBERT (AI4Bharat) — both publicly available and fine-tunable on Colab. Training data must be generated: a template-based synthetic corpus of SOS texts in Telugu, Hindi and English (hundreds per severity class per language, with paraphrase variation), plus a few hundred hand-written messages by the team for validation. Classes: critical (trapped, bleeding, water rising, structural collapse), serious (injured, stranded, medical need), minor (information, offers of help). The keyword-rules baseline (regex over distress vocabulary) is part of the story: it shows judges why a learned model matters when messages arrive in mixed transliteration like water ikkadundi. Metrics: macro-F1 overall and per language, and confusion between adjacent severities."));
  c.push(h2("6.3 Demand forecasting on a proxy dataset"));
  c.push(body("The best public proxy is the Montgomery County (Pennsylvania) 911 calls dataset on Kaggle (mchirico/montcoalert): roughly 424,000 calls from December 2015 to August 2016 with latitude, longitude, category embedded in the title field (EMS, Traffic, Fire), timestamp, township and address. Train an hourly, per-township demand model (XGBoost with time features, or a small temporal model) that predicts call volume per zone for the next hours. The skill transfers directly: swap the township layer for Hyderabad wards, and the same pipeline forecasts SOS surge during a simulated cyclone or flood phase — this is what lets the platform pre-position responders before demand peaks."));
  c.push(h2("6.4 Assignment optimiser: responders, SOS cases, hospitals"));
  c.push(body("Matching is a bipartite assignment problem: responders on one side, SOS cases on the other, with a cost matrix of weighted travel time and urgency. The Hungarian algorithm (scipy.optimize.linear_sum_assignment) solves the optimal one-to-one assignment in milliseconds; ambulance capacity is handled by expanding each vehicle into multiple slots (each slot a copy of the row) or, for hospital capacity constraints, by a min-cost flow formulation. ETAs come from OSRM's open routing server, with a haversine-times-congestion fallback for offline demos. The cost function is the heart of the product: cost equals w1 times ETA plus w2 times urgency deficit minus w3 times hospital slack — and the weights are a demo variable, letting judges watch the assignment change as criticality rises. Academic grounding exists (risk-based ambulance allocation is a studied mixed-integer problem), which is worth citing on a roadmap slide."));
  c.push(h2("6.5 The simulation: the dataset you will generate"));
  c.push(body("Because no real Indian dispatch dataset is public, build a simulator as the fourth model's benchmark environment: a Hyderabad-style grid of wards, 20 ambulances with home bases, 8 hospitals with capacities, SOS arrivals as a Poisson process whose rate spikes during a scripted hazard phase, and a severity mix of roughly 10 percent critical, 30 percent serious, 60 percent minor. Run policy A (nearest-greedy) against policy B (the optimiser) over many random seeds and report the deltas. The simulator doubles as the live demo: SOS pins appear, the triage classifier colours them, the optimiser draws assignment lines, hospitals fill their capacity bars."));
  c.push(bullet([{ t: "Metrics: ", b: true }, { t: "mean and 90th-percentile response time; share of critical cases reached within 8 and 10 minutes; hospital overflow events; vehicle utilisation; and per-ward fairness (no zone systematically starved). Expected headline: the optimiser concentrates its gains on critical cases, which is exactly the golden-hour argument." }]));
  c.push(bullet([{ t: "What to know first: ", b: true }, { t: "the 911 dataset field meanings, Hungarian-algorithm assumptions (square or padded cost matrix), how capacity expansion changes optimality, and OSRM's demo-server rate limits." }]));

  // ── 7. Platform governance ──
  c.push(h1("7. Platform Governance: Map v2, Safe Zones, P2P and Signed Broadcasts"));
  c.push(h2("7.1 Map v2: layers, sensor registry and tracking"));
  c.push(body("Map v2 is a Leaflet application with an explicit layer catalogue so that judges can toggle the situation picture piece by piece. Sensor location tracking comes from a node registry: each node registers once (id, position, node certificate) and then sends heartbeats (battery, last detection, status), so the map shows a live health view of the sensing network — a feature agencies genuinely lack at neighbourhood scale."));
  c.push(caption("Table 6 — Map v2 layer catalogue"));
  c.push(mkTable(
    ["Layer", "Source", "Notes"],
    [
      ["Base maps (2)", "OpenStreetMap; Esri World Imagery", "Street and satellite toggle"],
      ["Sensor nodes", "Node registry + heartbeats", "Status colours; last-seen time"],
      ["Seismic events", "Consensus layer output; USGS/NCS feed", "Circle size by magnitude; recency fade"],
      ["Fire hotspots", "NASA FIRMS (NOAA-20/21 VIIRS)", "3-hour latency; confidence filter"],
      ["Cyclone track + impact", "IMD advisory translation layer", "Track, cone, ward-level IMD wind categories"],
      ["SOS pins", "Device SOS (signed)", "Colour by triage severity; cluster when dense"],
      ["Responders + hospitals", "Dispatch module", "Assignment lines; hospital capacity bars"],
      ["Safe zones", "Signed government layer (7.2)", "Verified badge; capacity and type on tap"],
      ["Alert polygons", "CAP-style signed broadcasts (7.4)", "Expiry times; severity styling"],
    ],
    [24, 38, 38]
  ));
  c.push(h2("7.2 Government-authorised safe zones"));
  c.push(body("Safe zones are government data, not crowd guesses. The precedent is Odisha, where the state disaster authority built and maintains a network of over a hundred multipurpose cyclone shelters (with hundreds more flood shelters added by the rural development department), and where the evacuation of roughly 1.5 million people ahead of Cyclone Fani in 2019 demonstrated what shelter-led warning works. State SDMAs publish shelter lists; the platform ingests them into a schema of id, name, latitude and longitude, capacity, shelter type, applicable hazards, verified_by and verified_at. Only entries whose verification is signed by a state emergency-operation-centre key display the Government verified badge; community suggestions appear in a separate, visually distinct layer. This keeps the platform honest — it never invents safety information — while demonstrating exactly the government-authorised flow the team specified."));
  c.push(h2("7.3 Signing and identity: the alert-authenticity layer"));
  c.push(body("Every message the platform carries is signed, and the design doubles as the disaster-misinformation defence the team wanted. The trust hierarchy is a small certificate authority: a national root (NDMA-equivalent) signs state emergency-operation-centre keys; state keys sign officials, responders and sensor nodes; citizens generate device keypairs locally and stay pseudonymous — no Aadhaar, no phone number binding, which preserves privacy while still making spam and forgery expensive. Signatures use Ed25519 (small keys, fast verification, works offline on cheap hardware). Message schema: type, sender public-key hash, certificate chain, payload (event, urgency, severity, certainty, area, expires), timestamp, nonce, signature — with canonical JSON serialisation before signing, a timestamp validity window and a nonce cache for replay protection. An SOS signed by a device key tells a responder the ping comes from a real registered device; a broadcast signed by an official key verifies offline, even on a mesh with no server. This is the cryptographic continuity of the team's original cipher curiosity, applied where it genuinely saves lives: nobody can impersonate a government alert."));
  c.push(h2("7.4 SACHET and CAP alignment"));
  c.push(body("India's official alerting backbone is NDMA's SACHET — a CAP-based Integrated Alert System operational across all 36 States and Union Territories, developed with C-DoT, disseminating alerts through SMS, cell broadcast and media partners; NDMA has been rolling out its indigenous cell broadcast system through 2026. CAP (Common Alerting Protocol, ITU-T X.1303) structures an alert as an Alert element carrying one or more Info elements (language, event, urgency, severity, certainty, response type) and Area elements (polygons or circles) with expiry. Our broadcast payload deliberately mirrors these fields, so a bridge component can ingest SACHET alerts (verify the chain, shape the radius, render in Telugu, Hindi and English) and export our official broadcasts in CAP form. On the pitch slide this is one sentence: the platform speaks India's alert language by design."));
  c.push(h2("7.5 Peer-to-peer mesh with a government switch"));
  c.push(body("When cyclones knock out towers, phones within Bluetooth range can still relay messages — Bridgefy popularised this mesh pattern for disaster use. Our design adds the governance the team asked for: a signed mesh-authorisation token, issued by the government side, that enables relaying for a defined area and validity window; devices verify the token signature and only then forward traffic, and revocation is a broadcast with a new expiry. Hop-by-hop signature verification keeps forged messages out of the mesh, and store-and-forward with TTL keeps SOS traffic moving through intermittent contacts. On regulation: public wireless operation in India falls under the Telegraph Act and Wireless Telegraphs Act framework, which is precisely why the government-authorised, government-revocable design is not a weakness but the compliance story — the demo never runs an unlicensed network, it runs a government-switched emergency facility."));
  c.push(h2("7.6 Registration, roles and the emergency handoff"));
  c.push(body("Registration binds a public key to a role — citizen, responder, official.state, official.national — with the issuing authority's signature on the binding. The broadcast endpoint enforces the rule that only officials may broadcast, both server-side (role check against the certificate chain) and offline in the mesh (signature verification against known authority keys). Emergency handoff keeps human systems in command: the responder card shows 112 (the ERSS single emergency number) and 108 (ambulance) as conference targets, and hospital pre-notification is a structured packet (triage class, ETA, count) rather than a raw phone call. The privacy stance closes the loop: fixed sensors, pseudonymous devices, SOS location shared only while active and only to verified responders, and derived spectrogram features instead of raw personal signals."));

  // ── 8. Master list ──
  c.push(h1("8. Master Dataset List and Pre-Training Checklist"));
  c.push(body("The table consolidates every dataset, feed and model asset referenced in Sections 3 to 7, with access mode and licence notes. Licence notes marked check should be re-verified at download time — several portals require registration or attribution wording that changes between releases."));
  c.push(caption("Table 7 — Dataset shopping list for all four models"));
  c.push(mkTable(
    ["Model", "Dataset / source", "What it gives", "Format", "Access", "Licence note"],
    [
      ["M1 Quake", "STEAD (Stanford)", "1 M+ labelled quake + noise waveforms, P/S picks, magnitude, station geometry", "HDF5 + CSV (~85 GB total; train from one chunk)", "Direct download links on GitHub (smousavi05/STEAD)", "CC-BY-4.0; cite Mousavi et al. 2019"],
      ["M1 Quake", "EQTransformer weights (GitHub)", "Pre-trained detector/picker to fine-tune", "Keras/TF weights", "github.com/smousavi05/EQTransformer", "Check repo licence"],
      ["M1 Quake", "Raspberry Shake, or Pi + ADXL345/MPU6050", "Live spectrogram source for the demo; privacy-clean nodes", "Hardware", "Purchase (~Rs 300-800 for MEMS board)", "n/a"],
      ["M1 Quake", "NCS catalogue (seismo.gov.in)", "Indian quake ground truth; official bulletins", "Web/CSV", "Public portal", "Government open use"],
      ["M2 Cyclone", "IBTrACS v04r01 (NOAA NCEI)", "Global best tracks since 1840s; NI basin subset; wind radii", "CSV / NetCDF / shapefile", "ncei.noaa.gov direct", "US government — public domain"],
      ["M2 Cyclone", "ERA5 (Copernicus CDS)", "SST, winds, pressure, humidity reanalysis", "GRIB / NetCDF", "Free CDS account", "CC-BY-4.0 (Copernicus)"],
      ["M2 Cyclone", "INSAT-3D cyclone imagery (Kaggle, 2012-2021)", "Indian-satellite IR images with intensity labels", "Images", "Kaggle account", "Check dataset page"],
      ["M2 Cyclone", "MOSDAC (ISRO)", "Authoritative INSAT-3D/3DR data", "HDF / images", "Free registration", "ISRO policy"],
      ["M2 Damage", "xView2 / xBD", "~850k building polygons, 19 events, 4 damage classes, pre/post imagery", "1024x1024 GeoTIFF + JSON", "Free registration at xview2.org", "Check terms at download"],
      ["M3 Fire", "NASA FIRMS (VIIRS NOAA-20/21, MODIS)", "Near-real-time + archive hotspots; labels and live layer", "CSV / GeoJSON / SHP", "firms.modaps.eosdis.nasa.gov with free MAP_KEY", "Open (NASA Earth science)"],
      ["M3 Fire", "Open-Meteo API", "Weather features (temp, RH, wind, rain)", "JSON", "Free, no key (research)", "CC-BY-4.0"],
      ["M3 Fire", "MODIS NDVI, ESA WorldCover, SRTM", "Vegetation, land cover, terrain features", "GeoTIFF", "Public portals (AppEEARS, ESA, USGS)", "Open"],
      ["M3 Fire", "Kaggle Wildfire Prediction Dataset (Satellite Images)", "~42,850 labelled 350x350 tiles for detection demo", "Images", "Kaggle", "Check dataset page"],
      ["M4 Dispatch", "Montgomery County 911 calls (Kaggle montcoalert)", "~424k real emergency calls for demand forecasting", "CSV", "Kaggle", "Open community dataset"],
      ["M4 Dispatch", "MuRIL / IndicBERT weights", "Multilingual bases for Telugu/Hindi/English triage", "TF / PyTorch", "Hugging Face / AI4Bharat", "Open (check model cards)"],
      ["M4 Dispatch", "OSRM", "Road-distance ETAs for assignment costs", "Service", "Demo server or Docker", "Open (OLSL)"],
      ["Platform", "OSDMA / state SDMA shelter lists", "Government safe zones", "Web / PDF / CSV", "osdma.org and SDMA portals", "Government open use"],
      ["Platform", "SACHET / CAP specification", "Official alert schema to mirror", "XML / web", "sachet.ndma.gov.in; ITU X.1303", "Standard (open spec)"],
    ],
    [11, 22, 26, 13, 15, 13]
  ));
  c.push(h2("8.1 Know-before-you-train checklist"));
  c.push(bullet([{ t: "M1 (STEAD): ", b: true }, { t: "sampling rate 100 Hz; 60 s windows; download only chunk2 plus a noise subsample; filter by p_status/s_status and snr_db; split by source_origin_time; subsample noise to balance classes; plan MEMS-domain augmentation." }]));
  c.push(bullet([{ t: "M2 (IBTrACS): ", b: true }, { t: "6-hourly cadence; group by SID; time-based split by SEASON; NI-basin filter; WMO vs USA wind fields and how to coalesce them; R34 missingness strategy." }]));
  c.push(bullet([{ t: "M2 (xBD): ", b: true }, { t: "split by disaster event; per-class F1; tile subsampling for Colab disk; verify licence wording at registration." }]));
  c.push(bullet([{ t: "M3 (FIRMS): ", b: true }, { t: "confidence semantics differ between VIIRS (l/h/n) and MODIS (0-100); 3-hour latency; spatial-block CV; rare-positive label construction; calibrate probabilities." }]));
  c.push(bullet([{ t: "M4: ", b: true }, { t: "synthetic corpus needs per-language balance; 911 title field embeds category; Hungarian needs a square (padded) matrix; capacity via slot expansion; simulate many seeds before quoting numbers." }]));
  c.push(h2("8.2 Compute reality"));
  c.push(body("Every main model here fits a free Colab T4 session: STEAD training works from one earthquake chunk with a noise subsample (tens of gigabytes streamed or pre-cached on Drive), IBTrACS is tabular and tiny, the wildfire image set is 43 thousand small images, and xBD needs tile subsampling but no exotic hardware. The realistic risk to the timeline is not compute but data plumbing — downloads, coordinate reference systems, label construction — which is exactly what the checklist above front-loads."));

  // ── 9. Open decisions ──
  c.push(h1("9. Open Decisions and Build Order"));
  c.push(h2("9.1 Decisions needed from the team"));
  c.push(bullet([{ t: "Sensor path for the demo: ", b: true }, { t: "physical shake table with a Pi + MEMS node feeding a real spectrogram (strongest theatre), or a purely software-simulated node network. The research supports either; the hardware path needs a purchase decision early." }]));
  c.push(bullet([{ t: "Demo geography: ", b: true }, { t: "recommend Hyderabad city grid for dispatch, one Bay of Bengal historical cyclone for the translation demo (Fani 2019 has the best-documented impact), and one Telangana forest beat for fire risk." }]));
  c.push(bullet([{ t: "Stretch choices: ", b: true }, { t: "fine-tuning EQTransformer (M1) versus U-Net on xBD (M2) — pick one stretch, not both, given the timeline." }]));
  c.push(bullet([{ t: "Language set: ", b: true }, { t: "Telugu, Hindi and English confirmed as the alert and triage languages; assign who on the team writes and validates the synthetic SOS corpus." }]));
  c.push(bullet([{ t: "Training ownership: ", b: true }, { t: "one owner per model; the owner runs the training notebook and reports metrics back into the pitch deck." }]));
  c.push(h2("9.2 Recommended build order"));
  c.push(body("Build and train in the order M1, M3, M2, M4. Model 1 carries the theatrical centre of the demo and its dataset is the most demanding, so it goes first. Model 3 delivers real live data on the map within days because FIRMS needs only a MAP_KEY. Model 2's differentiator is the translation layer, which is engineering rather than training and slots in late. Model 4's simulator is independent and can proceed in parallel once triage labels exist. Say the word and the next deliverable is the Model 1 training code to the specification in Section 3 — notebook form, Colab-ready, with the consensus-layer experiment included."));
  c.push(body([{ t: "Administrative reminder: ", b: true }, { t: "HridhAI 2026 registration closes on 5 November 2026, and final problem statements are released only to registered schools — confirm the school's registration before the team locks its build plan." }]));

  return c;
}
module.exports = { sections_B };
