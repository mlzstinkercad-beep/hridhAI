#!/usr/bin/env python3
"""Post-process dossier docx: patch footer PAGE field format switch + strip empty pgNumType (WPS compat)."""
import re, shutil, sys, zipfile, os

SRC = "/home/z/my-project/download/HridhAI2026_DisasterAI_Research_Dossier.docx"
TMP = SRC + ".tmp"

with zipfile.ZipFile(SRC, "r") as zin:
    names = zin.namelist()
    data = {n: zin.read(n) for n in names}

# 1) Patch every footer's bare PAGE instrText -> explicit arabic switch
patched = 0
for n in names:
    if re.match(r"word/footer\d*\.xml$", n):
        xml = data[n].decode("utf-8")
        new_xml, k = re.subn(
            r"(<w:instrText[^>]*>)\s*PAGE\s*(</w:instrText>)",
            r"\1 PAGE \\* arabic \\* MERGEFORMAT \2",
            xml,
        )
        if k:
            data[n] = new_xml.encode("utf-8")
            patched += k

# 2) Remove empty <w:pgNumType/> from document.xml (confuses WPS on cover section)
docxml = data["word/document.xml"].decode("utf-8")
docxml2, k2 = re.subn(r"<w:pgNumType/>", "", docxml)
data["word/document.xml"] = docxml2.encode("utf-8")

with zipfile.ZipFile(TMP, "w", zipfile.ZIP_DEFLATED) as zout:
    for n in names:
        zout.writestr(n, data[n])
shutil.move(TMP, SRC)
print(f"patched footer PAGE fields: {patched}; removed empty pgNumType: {k2}")
