// Main assembler — research dossier docx
const {
  Document, Packer, Paragraph, TextRun, Header, Footer, PageNumber,
  AlignmentType, HeadingLevel, SectionType, NumberFormat, TableOfContents,
} = require("docx");
const fs = require("fs");
const { PAL, FONT, buildCoverR1 } = require("./dossier_helpers");
const { sections_A } = require("./dossier_content_a");
const { sections_B } = require("./dossier_content_b");

const OUT = "/home/z/my-project/download/HridhAI2026_DisasterAI_Research_Dossier.docx";

// ── Cover config (Recipe R1, palette DM-1) ──
const coverConfig = {
  title: "Multi-Hazard Disaster AI Platform",
  subtitle: "Research Dossier: Datasets, Architectures and Governance",
  englishLabel: "HRIDHAI 2026 \u00B7 AI THAT PROTECTS",
  metaLines: [
    "Prepared for: HridhAI 2026 hackathon team (senior category, Grade 9-12)",
    "Scope: Four AI models and the platform governance layer, Indian system",
    "Date: 3 November 2026 \u00B7 Registration closes 5 November 2026",
  ],
  footerLeft: "Model & Data Research Dossier",
  footerRight: "Version 1.0",
  palette: PAL.cover,
};

// ── Shared footer (page number) ──
function pageNumFooter() {
  return new Footer({
    children: [new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ children: [PageNumber.CURRENT], size: 18, color: "808080", font: FONT })],
    })],
  });
}
function docHeader() {
  return new Header({
    children: [new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ text: "Multi-Hazard Disaster AI Platform \u2014 Research Dossier", size: 18, color: "808080", font: FONT })],
    })],
  });
}

// ── TOC section children ──
const tocChildren = [
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 480, after: 360 },
    children: [new TextRun({ text: "Table of Contents", bold: true, size: 32, color: PAL.primary, font: FONT })],
  }),
  new TableOfContents("Table of Contents", { hyperlink: true, headingStyleRange: "1-3" }),
  new Paragraph({
    spacing: { before: 200 },
    children: [new TextRun({
      text: "Note: This Table of Contents is generated via field codes. To ensure page number accuracy after editing, please right-click the TOC and select \"Update Field.\"",
      italics: true, size: 18, color: "888888", font: FONT,
    })],
  }),
];

// ── Document ──
const doc = new Document({
  styles: {
    default: {
      document: {
        run: { font: FONT, size: 24, color: "000000" },
        paragraph: { spacing: { line: 312 } },
      },
      heading1: {
        run: { font: FONT, size: 32, bold: true, color: PAL.primary },
        paragraph: { spacing: { before: 360, after: 160, line: 312 }, outlineLevel: 0 },
      },
      heading2: {
        run: { font: FONT, size: 28, bold: true, color: PAL.primary },
        paragraph: { spacing: { before: 260, after: 120, line: 312 }, outlineLevel: 1 },
      },
      heading3: {
        run: { font: FONT, size: 25, bold: true, color: PAL.accent },
        paragraph: { spacing: { before: 200, after: 100, line: 312 }, outlineLevel: 2 },
      },
    },
  },
  sections: [
    { // Section 1: Cover — margin 0, no header/footer, no page number
      properties: {
        page: { size: { width: 11906, height: 16838 }, margin: { top: 0, bottom: 0, left: 0, right: 0 } },
      },
      children: buildCoverR1(coverConfig),
    },
    { // Section 2: TOC — no footer (page number hidden), inherits cover's (none)
      properties: {
        type: SectionType.NEXT_PAGE,
        page: { size: { width: 11906, height: 16838 }, margin: { top: 1440, bottom: 1440, left: 1701, right: 1417 } },
      },
      children: tocChildren,
    },
    { // Section 3: Body — Arabic page numbers starting at 1
      properties: {
        type: SectionType.NEXT_PAGE,
        page: {
          size: { width: 11906, height: 16838 },
          margin: { top: 1440, bottom: 1440, left: 1701, right: 1417 },
          pageNumbers: { start: 1, formatType: NumberFormat.DECIMAL },
        },
      },
      headers: { default: docHeader() },
      footers: { default: pageNumFooter() },
      children: [...sections_A(), ...sections_B()],
    },
  ],
});

Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync(OUT, buf);
  console.log("WROTE", OUT, buf.length, "bytes");
});
