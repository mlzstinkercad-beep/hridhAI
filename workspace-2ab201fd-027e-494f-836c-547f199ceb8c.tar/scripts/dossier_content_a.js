// Dossier content — sections 1-5
const { h1, h2, h3, body, bullet, caption, note, mkTable } = require("./dossier_helpers");

function sections_A() {
  const c = [];

  // ── 1. Executive Summary ──
  c.push(h1("1. Executive Summary"));
  c.push(body("This dossier is the research deliverable for the four-model training plan of the multi-hazard disaster platform targeted at HridhAI 2026 (Track 2: AI That Protects). It answers, for each model, the questions that must be settled before any code is written: what exactly the model predicts, which dataset supplies the training signal and what every important field in that dataset means, which architecture to start with and which to grow into, how the data must be split so that results are honest, and which metrics the judges should see. The model training itself will be done by the team; this document supplies the verified research base behind that work."));
  c.push(body([
    { t: "The four models and their anchors are: " },
    { t: "(1) Earthquake detection", b: true },
    { t: " — trained on the STEAD seismogram dataset (Stanford; CC-BY-4.0) with a CNN-plus-GRU detector on spectrograms and a multi-node consensus layer; " },
    { t: "(2) Cyclone track, intensity and damage", b: true },
    { t: " — trained on NOAA's IBTrACS best-track archive with ERA5 weather features, plus the xView2/xBD satellite dataset for building-damage assessment, always framed as translating IMD's official forecasts, never competing with them; " },
    { t: "(3) Forest fire risk", b: true },
    { t: " — trained on NASA FIRMS active-fire history with open weather and vegetation features, using XGBoost for risk and a small CNN on the Kaggle wildfire image dataset for the detection demo; " },
    { t: "(4) Responder-SOS-hospital matching", b: true },
    { t: " — a multilingual triage classifier (MuRIL/IndicBERT) feeding a demand-forecast step and an optimal assignment solver, demonstrated on a simulated Indian city." },
  ]));
  c.push(body("Five design principles run through everything that follows. First, hazard declarations require consensus across many independent sensors, never a single detector, because false alarms in disaster alerting destroy trust. Second, the platform complements and localises India's official agencies — IMD forecasts, NCS bulletins, NDMA's SACHET alerts — instead of duplicating them. Third, privacy is structural: fixed spectrographic sensor nodes replace personal phone streams, and even a phone layer would only ever transmit derived spectrogram features, following the on-device design proven by Google's Android Earthquake Alerts. Fourth, every alert, safe zone and responder identity is cryptographically signed, and only government-authorised officials can broadcast. Fifth, all four models are trainable on a free Google Colab GPU with subsampled data, so the hackathon timeline is realistic."));
  c.push(body("Sections 3 to 6 cover the models, Section 7 covers the platform and governance research (map layers, safe zones, peer-to-peer mesh, signed broadcasts), Section 8 consolidates the dataset shopping list with a pre-training checklist, and Section 9 lists the open decisions and the recommended build order."));

  // ── 2. System Overview ──
  c.push(h1("2. System Overview and India Integration Map"));
  c.push(body("The platform's pipeline is Sense, then Model, then Decide, then Act, and it maps one-to-one onto the printed judging loop of Track 2: Observe, Analyse, Assess risk, Protect. Sensors and public feeds observe (vibration nodes, NASA FIRMS satellites, IMD cyclone advisories). The four models analyse (detection, forecasting, triage). Risk assessment converts model output into graded, mapped risk (magnitude plus distance into shaking bands; forecast track into ward-level wind categories; hotspot density into fire tiers; SOS text into triage severity). Protection is the visible product: alert fan-out with risk radius, signed government broadcasts, safe-zone guidance, responder dispatch and hospital notification."));
  c.push(body("Because the event is judged in India and the pitch is built for the Indian system, every module has an official-system counterpart. The table below states, for each hazard chain, what the platform ingests from Indian official sources and what it outputs that those sources do not currently provide at street level. This complement-not-compete principle is itself a judging argument: the platform is designed as a last-mile layer on top of IMD, NCS and NDMA infrastructure, which is exactly the role a student-built system can credibly play."));
  c.push(caption("Table 1 — India integration points: what we ingest and what we add"));
  c.push(mkTable(
    ["Hazard / Function", "Official source (ingest)", "What the platform adds"],
    [
      ["Earthquake", "NCS bulletins and catalogue (seismo.gov.in, MoES); USGS global feed as live demo data", "Local sensor-node detections with consensus confirmation; second-level P-wave alerting at ward level; aftershock watchlist"],
      ["Cyclone", "IMD advisories and categories (mausam.imd.gov.in); NDMA SACHET CAP alerts", "Track translated into ward-level wind categories via wind-profile model; damage hotspots from satellite after landfall"],
      ["Forest fire", "Forest Survey of India large-fire alerts; NRSC Bhuvan fire layers", "Next-24/48-hour risk tiers per forest beat before ignition, calibrated on FIRMS history"],
      ["Official alerts", "NDMA SACHET (CAP-based Integrated Alert System, sachet.ndma.gov.in)", "Verification and fan-out of signed CAP-style alerts; Telugu/Hindi/English rendering with risk-radius shaping"],
      ["Response", "112 (ERSS) and 108 (ambulance) networks", "SOS triage, responder-hospital assignment with capacity constraints, hospital pre-notification packets"],
      ["Safe zones", "State SDMA shelter lists (e.g., OSDMA multipurpose cyclone/flood shelters)", "Government-verified safe-zone layer with capacity, hazard type and signed verification badge"],
    ],
    [22, 36, 42]
  ));
  c.push(note("Sourcing note: SACHET is NDMA's operational CAP-based Integrated Alert System covering all 36 States and Union Territories, built with C-DoT; CAP (Common Alerting Protocol) is the ITU-T X.1303 international alert-interchange standard. Aligning our broadcast schema with CAP is therefore not cosmetic — it makes the platform drop-in compatible with India's official alerting backbone."));

  // ── 3. Model 1 — Earthquake ──
  c.push(h1("3. Model 1: Earthquake Detection from Spectrograms"));
  c.push(h2("3.1 Privacy-first sensing design"));
  c.push(body("The team's design decision is correct and has strong precedent: hazard sensing should run on dedicated spectrographic sensor nodes, not on personal phones, because fixed infrastructure generates no personal data at all. The consensus idea behind the platform — only declare an earthquake when many independent detections agree — is exactly how Google's Android Earthquake Alerts works, in which every Android handset (Samsungs included) acts as a mini seismometer and the server declares an event only when a cluster of phones triggers together. The system was published in Science in 2025 (Global earthquake detection and warning using Android phones, Stogaitis et al.): it reaches roughly 2.5 billion people across 98 countries, delivered about 18 million alerts per month for earthquakes of magnitude 4.5 and above over a three-year study period, and in surveyed events 36 percent of alert recipients received the alert before shaking arrived. MyShake, built by UC Berkeley, proved the same pattern at smaller scale with a smartphone seismic network."));
  c.push(body("Our hardware interpretation is a school-deployable node: a Raspberry Shake unit, or a Raspberry Pi plus a low-cost MEMS accelerometer board (ADXL345 or MPU6050, a few hundred rupees), placed on a stable floor. Each node computes spectrograms locally, runs the trained detector, and uploads only derived features (detection probability, pick times, coarse amplitude) with its node certificate — never raw continuous vibration, never location history beyond its fixed registered position. This gives the demo a clean privacy story: the same consensus logic Google runs across billions of phones, implemented on infrastructure that cannot leak personal data."));
  c.push(h2("3.2 Dataset: STEAD — what it is and what every key field means"));
  c.push(body("The Stanford Earthquake Dataset (STEAD) is the global benchmark for machine-learning seismic detection: Mousavi, Sheng, Zhu and Beroza (IEEE Access, 2019). It ships as about 85 GB of HDF5 waveforms in six chunks (five earthquake chunks of roughly 13.7 to 15.7 GB plus one noise chunk of about 14.6 GB) with a companion CSV metadata file; the licence is CC-BY-4.0, so citation is the only obligation. EQTransformer, the reference model of this field, was trained on a 1.3-million-observation subset: one million earthquake and three hundred thousand noise waveforms recorded by about 2,600 stations at epicentral distances up to 300 km, mostly below magnitude 2.5. Waveforms are one minute long at 100 Hz sampling, bandpass-filtered 1 to 45 Hz. For Colab, download only one earthquake chunk (chunk2) and subsample the noise chunk — that is enough to train all variants in this plan."));
  c.push(caption("Table 2 — STEAD metadata CSV: the columns that matter and what they are used for"));
  c.push(mkTable(
    ["Column", "Meaning", "Use in our training"],
    [
      ["trace_name / trace_category", "Pointer into the HDF5 file; label earthquake vs noise", "Sample lookup; binary detection label"],
      ["trace_start_time", "Window start time (UTC)", "Temporal grouping; splitting by event time"],
      ["p_arrival_sample / s_arrival_sample", "Sample index of P-wave and S-wave onset", "Supervision signal for the two picker heads"],
      ["coda_end_sample", "End of the earthquake signal", "Window trimming; duration features"],
      ["source_origin_time", "True event origin time", "Consensus-layer grouping key (all recordings of one quake)"],
      ["source_latitude / source_longitude / source_depth", "Hypocentre location", "Event location for map output; depth for shaking estimate"],
      ["source_magnitude (+ type)", "Published magnitude of the event", "Regression head label (magnitude estimation)"],
      ["source_distance_km / back_azimuth_deg", "Station-to-epicentre distance and bearing", "Distance features; magnitude-from-distance calibration"],
      ["network_code / receiver_code / receiver_type", "Station identity and sensor type", "Network simulation for the consensus layer"],
      ["receiver_latitude / longitude / elevation", "Station position", "Geometry features; plotting the simulated network"],
      ["snr_db (per component)", "Signal-to-noise ratio of the trace", "Quality filtering; hard-example mining"],
      ["p_status / s_status", "Analyst quality flags for picks", "Dropping unreliable labels from training"],
    ],
    [30, 34, 36]
  ));
  c.push(body("Beyond STEAD, the Italian INSTANCE dataset is the standard larger alternative, and EQTransformer's released weights were trained on both — meaning fine-tuning our version is a shortcut that respects the state of the art."));
  c.push(h2("3.3 Preprocessing: from waveform to spectrogram"));
  c.push(body("Each three-component trace is resampled to a common 100 Hz, detrended, and bandpass-filtered to 1 to 20 Hz — a deliberately conservative band because MEMS accelerometers are noisier than the professional seismometers in STEAD. Windows are fixed at 60 seconds, then normalised by z-scoring each component independently. A short-time Fourier transform (one-second window, 0.25-second hop) with a logarithmic magnitude scale produces a three-channel spectrogram image, the CRED-style input representation (Mousavi et al., 2019, CRED: a deep residual network of convolutional and recurrent units). Augmentation is where the domain gap between STEAD and our MEMS nodes is closed: random time shifts, added Gaussian noise, amplitude scaling, and random channel dropout make the detector robust to cheaper hardware."));
  c.push(h2("3.4 Architecture ladder"));
  c.push(bullet([{ t: "Baseline (build first, always shows on the slide): ", b: true }, { t: "classic STA/LTA energy trigger plus a logistic-regression classifier on simple features (peak amplitude, duration, zero crossings). It fails on cultural noise in a visible way, which motivates the deep model." }]));
  c.push(bullet([{ t: "Main model: ", b: true }, { t: "a CRED-style network — 2D CNN encoder over the spectrogram feeding a residual GRU — with three heads: detection probability, P-pick offset, S-pick offset, plus a small magnitude-regression head. Multi-task binary cross-entropy for the probabilistic heads and Huber loss for magnitude." }]));
  c.push(bullet([{ t: "Stretch (the credibility card): ", b: true }, { t: "fine-tune the released pre-trained EQTransformer weights (github.com/smousavi05/EQTransformer), the field's reference model — a hierarchical attentive encoder with detector, P-picker and S-picker decoders, trained on 1.3 million local earthquakes and reported to pick arrivals with a mean absolute error around 0.06 seconds against human analysts." }]));
  c.push(h2("3.5 The consensus layer — the many-sensors rule as code"));
  c.push(body("A single node's high detection probability is not an earthquake; it might be a truck. The consensus layer clusters detector triggers in space and time — triggers within roughly 30 seconds and 100 km of each other are pooled (Haversine distance; DBSCAN or simple grid clustering) — and declares an event only when at least N nodes agree, then estimates location as the centroid of agreeing nodes adjusted by back-azimuth, and magnitude from source-distance and amplitude relationships learned from STEAD labels. STEAD is ideal for training and tuning this layer because its metadata lets us simulate realistic networks: group all traces sharing a source_origin_time, and for each historical event test whether a random subset of 5, 10 or 20 stations would have reached consensus, producing a curve of detection rate versus false-alarm rate as N increases. That curve is a strong judging slide: it quantifies exactly the many-phones-agree principle the team chose."));
  c.push(h2("3.6 Metrics, splits and leakage"));
  c.push(bullet([{ t: "Metrics: ", b: true }, { t: "detection precision and recall; false alarms per node-day at the consensus level (target below one per day); P and S pick error in seconds; magnitude mean absolute error; detection latency relative to the P-wave arrival." }]));
  c.push(bullet([{ t: "Split rule (critical): ", b: true }, { t: "split by event, grouping all windows of one source_origin_time together — random window splits leak because adjacent windows of the same quake appear in both train and test. Additionally hold out one geographic region as an unseen-region test." }]));
  c.push(bullet([{ t: "What to know first: ", b: true }, { t: "sampling rate (100 Hz), window length (60 s), class balance after noise subsampling, the meaning of snr_db and status flags, and the chunk-size reality of 85 GB total against Colab disk limits." }]));
  c.push(h2("3.7 India integration"));
  c.push(body("The National Centre for Seismology (NCS) under the Ministry of Earth Sciences operates India's national seismological network — more than 80 permanent observatories (84 as of 2017, expanded since) — and publishes bulletins and the historical catalogue on seismo.gov.in. Our positioning: NCS bulletins serve as official ground truth and the authoritative alert source, while our node network densifies coverage at neighbourhood level and can issue second-level P-wave alerts and aftershock watchlists from the consensus layer. For the demo, Telangana sits in a low seismic zone, which is precisely why the live module pairs the physical shake table with real USGS global feeds: the region is quiet, the network is not."));

  // ── 4. Model 2 — Cyclone ──
  c.push(h1("4. Model 2: Cyclone Track, Intensity and Damage"));
  c.push(h2("4.1 The translate-not-compete rule"));
  c.push(body("IMD is the legal forecasting authority for Indian cyclones, and no student model will out-forecast its operational pipeline. The product is therefore translation: ingest the official advisory (position, forecast track, intensity), then convert it into street-level impact — which wards will experience which IMD wind category, where evacuation matters first, and which hospitals should pre-position. The trained models exist to make that translation sharper (local intensity and damage estimation) and to demonstrate machine-learning competence to judges, not to replace IMD bulletins."));
  c.push(h2("4.2 Datasets and what every key field means"));
  c.push(body("IBTrACS version 04r01, maintained by NOAA's National Centers for Environmental Information, is the global best-track archive merging every regional agency's cyclone records; it reaches back to the 1840s, and the since-1980 subset is the recommended working set because satellite-era observations are reliable. For India, filter to the North Indian (NI) basin. ERA5, the Copernicus hourly reanalysis, supplies environmental features (winds, pressure, humidity, sea-surface temperature). For imagery, a Kaggle collection of INSAT-3D infrared and raw cyclone imagery over the Indian Ocean from 2012 to 2021 with intensity labels is the fastest Indian-satellite path, while MOSDAC (ISRO's portal, free registration) is the authoritative source for INSAT-3D/3DR data."));
  c.push(caption("Table 3 — IBTrACS columns that matter (NI basin)"));
  c.push(mkTable(
    ["Column", "Meaning", "Use in our training"],
    [
      ["SID", "Globally unique storm identifier", "Grouping key — splits must be by SID, never by row"],
      ["ISO_TIME", "6-hourly fix time", "Sequence time axis"],
      ["LAT / LON", "Storm centre position", "Track prediction targets"],
      ["WMO_WIND / WMO_PRES", "Officially reported 1-min sustained wind (kt) and central pressure", "Intensity targets (WMO-agency consensus)"],
      ["USA_WIND / USA_PRES", "JTWC intensity fields", "Fill gaps in WMO fields for NI basin"],
      ["USA_R34_NE/SE/SW/NW", "Radii of 34-kt winds per quadrant", "Wind-field footprint for impact translation"],
      ["BASIN / NATURE", "Basin (NI) and storm nature (TS, SS)", "Filtering and stratification"],
      ["SEASON", "Year of the storm", "Time-based train/val/test split"],
    ],
    [26, 38, 36]
  ));
  c.push(h2("4.3 Track and intensity model"));
  c.push(body("The sequence task: given the last 24 hours of a storm (four 6-hourly fixes), forecast the next 72 hours (twelve steps) of position and wind. The baseline is persistence plus climatology — the storm continues on its current heading and recent intensification rate — which every serious forecast evaluation beats first. The main model is a modest LSTM or GRU (one to two million parameters) over per-fix features: latitude, longitude, Vmax, pressure, translation speed and heading (differenced positions), sea-surface temperature, and a vertical wind-shear proxy from ERA5. Loss is Huber on position and wind. Honesty note for the pitch: IMD operational track errors are of the order of a hundred kilometres at 24 hours; the student model will not beat that, and saying so to judges is a strength — the model's value is the impact-translation layer built on top of any track, ours or IMD's."));
  c.push(h2("4.4 Impact translation: IMD categories and the wind-profile model"));
  c.push(caption("Table 4 — IMD cyclone classification (verified against IMD's Cyclone Warning SOP)"));
  c.push(mkTable(
    ["IMD category", "Wind (kt)", "Wind (km/h)"],
    [
      ["Depression", "17-27", "31-49"],
      ["Deep Depression", "28-33", "50-61"],
      ["Cyclonic Storm", "34-47", "62-88"],
      ["Severe Cyclonic Storm", "48-63", "89-117"],
      ["Very Severe Cyclonic Storm", "64-89", "118-165"],
      ["Extremely Severe Cyclonic Storm", "90-119", "166-220"],
      ["Super Cyclonic Storm", "120 and above", "221 and above"],
    ],
    [50, 25, 25]
  ));
  c.push(body("Translation works like this: from a forecast fix (Vmax and the 34-kt radius), a Rankine-vortex wind profile estimates wind speed as a function of distance from the centre; each coastal ward's expected wind is then labelled with its IMD category, and alert templates in Telugu, Hindi and English are generated per ward with expiry times. This is deterministic engineering (no ML), and it is the part judges will remember, because it turns a forecast cone into a named list of wards and what to do."));
  c.push(h2("4.5 Damage assessment with xView2/xBD"));
  c.push(body("Post-landfall damage assessment uses the xBD dataset from the xView2 challenge (Maxar with UC Berkeley and the World Bank): roughly 850,000 building polygons across 19 disaster events, with pre- and post-event Maxar imagery (about half-metre resolution, 1024 by 1024 GeoTIFF tiles) and four ordinal labels per building — No Damage, Minor Damage, Major Damage, Destroyed. Download requires free registration at xview2.org. Plan: a ResNet-50 tile classifier as baseline, then U-Net or DeepLabV3+ segmentation plus per-building classification as the main model; report macro-F1 on the damaged classes (no-damage dominates the label distribution). The split rule is absolute: hold out entire disaster events, never random tiles, since neighbouring tiles from the same event are near-duplicates."));
  c.push(h2("4.6 Splits and leakage"));
  c.push(bullet("Track model: split storms by SID, and additionally by season — train on storms before 2018, validate on 2018-2019, test on 2020 and later; never let fixes from one storm straddle the split."));
  c.push(bullet("Damage model: split by disaster event; report per-class F1, not accuracy."));
  c.push(bullet("What to know first: the 6-hourly fix cadence, WMO versus agency-specific wind conventions (1-minute sustained), and which NI storms have complete R34 radii — a real missing-data exercise."));

  // ── 5. Model 3 — Forest fire ──
  c.push(h1("5. Model 3: Forest Fire Risk and Detection"));
  c.push(h2("5.1 Two layers with different jobs"));
  c.push(body("The live fire layer is not an AI task at all: NASA FIRMS provides near-real-time active-fire detections from VIIRS (375 m resolution; Suomi NPP since 2012, NOAA-20 since 2020, NOAA-21 since 2024) and MODIS (1 km; Terra and Aqua), globally within about three hours of observation, as CSV or GeoJSON behind a free MAP_KEY. One operational note straight from NASA: Suomi NPP science products end in November 2026, so the integration should default to NOAA-20 and NOAA-21. The AI layer is what FIRMS cannot do: predict where fire will occur next, before ignition, per forest beat."));
  c.push(caption("Table 5 — FIRMS CSV/GeoJSON fields (VIIRS 375 m)"));
  c.push(mkTable(
    ["Field", "Meaning", "Use"],
    [
      ["latitude / longitude", "Detection centre coordinates", "Map layer; gridding into 1 km cells"],
      ["bright_ti4 / bright_ti5", "Brightness temperature at ~4 and ~11 micrometres (K)", "Fire intensity features"],
      ["frp", "Fire radiative power (MW)", "Fire strength feature"],
      ["confidence", "Detection confidence (l/h/n for VIIRS)", "Filtering training labels and map noise"],
      ["acq_date / acq_time", "Acquisition date and UTC time", "Temporal aggregation; label windows"],
      ["satellite / instrument / version", "Source satellite, sensor, collection", "Provenance; sensor-specific calibration"],
      ["scan / track", "Pixel size along/across scan (km)", "Effective-resolution feature"],
      ["daynight", "Day or night observation", "Context feature"],
    ],
    [28, 42, 30]
  ));
  c.push(h2("5.2 Risk model: labels, features, architecture"));
  c.push(body("Labels: a 1 km grid cell over a chosen state (Telangana and Andhra Pradesh fit the demo geography) is positive for a given day if a FIRMS detection with adequate confidence falls inside it within the next 24 or 48 hours. Features: Open-Meteo weather (temperature, relative humidity, wind speed, recent precipitation — free API, no key for research use), vegetation greenness (MODIS NDVI), land cover (ESA WorldCover), elevation and slope (SRTM), 30-day FIRMS history of the cell and its neighbours, and distance to roads and settlements. The model ladder starts with XGBoost on tabular features — fast, explainable via feature importance, strong on this problem class — with a temporal CNN or GRU over multi-day feature sequences as the stretch. Fire is a rare-event problem, so the honest metrics are AUC-PR, recall at a fixed false-positive rate, and calibration (Brier score), because dispatch decisions need probabilities, not rankings alone."));
  c.push(h2("5.3 Split discipline and India validation"));
  c.push(body("Spatial block cross-validation is mandatory: adjacent cells share vegetation and weather, so random cell splits leak. Split by district or by 25-km blocks, and keep one full fire season as a temporal test set. For India-facing credibility, cross-check the model's top-risk beats against the Forest Survey of India's near-real-time large-fire alert system (FAST, which itself consumes MODIS and VIIRS data) and NRSC's Bhuvan fire alerts; India records tens of thousands of satellite fire detections annually, concentrated in the February-to-June season, so seasonal evaluation is the right framing."));
  c.push(h2("5.4 Detection demo (image CNN)"));
  c.push(body("For the visible demo — showing a satellite tile and having the model say fire or no fire — use the Kaggle Wildfire Prediction Dataset (Satellite Images): about 42,850 images at 350 by 350 pixels (22,710 fire, 20,140 no-fire) from Canadian wildfire areas. A fine-tuned ResNet-18 reaches high accuracy in minutes on Colab. Position it honestly in the pitch: it is the visual proof of image-based detection, while the operational risk model runs on FIRMS history and weather."));
  c.push(bullet([{ t: "What to know first: ", b: true }, { t: "FIRMS confidence semantics (VIIRS uses l/h/n, MODIS uses 0-100), the 3-hour latency, label sparsity (a positive cell is rare), and the fire-season window that defines fair test sets." }]));

  return c;
}
module.exports = { sections_A };
