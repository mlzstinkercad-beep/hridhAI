"""Run diagnostic experiments on the raw activation mixer.

These are engineering diagnostics, NOT cryptographic proofs or attack certifications.
The script writes a JSON report and a known-plaintext sample CSV into ./results/.
"""
from __future__ import annotations

import csv
import json
import os
import statistics
import time
from pathlib import Path

import numpy as np
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from vectorshield import (
    _activation_transform,
    _derive_subkeys,
    _feistel_block,
    generate_master_key,
)


RESULTS = Path("results")
RESULTS.mkdir(exist_ok=True)
RNG = np.random.default_rng(20261102)


def hamming_bits(a: bytes, b: bytes) -> int:
    return sum((x ^ y).bit_count() for x, y in zip(a, b))


def activation_round_trip_trials(key: bytes, trials: int = 100) -> dict:
    mix_key, _ = _derive_subkeys(key)
    passed = 0
    for _ in range(trials):
        block = RNG.integers(0, 256, size=128, dtype=np.uint8).tobytes()
        encrypted = _feistel_block(block, mix_key, 0)
        decrypted = _feistel_block(encrypted, mix_key, 0, decrypt=True)
        passed += decrypted == block
    return {"trials": trials, "exact_inverse_passes": passed, "all_passed": passed == trials}


def avalanche_experiment(key: bytes, trials: int = 64) -> dict:
    """Flip one input bit and report output-bit change rate (not a security proof)."""
    mix_key, _ = _derive_subkeys(key)
    rates = []
    for i in range(trials):
        base = RNG.integers(0, 256, size=128, dtype=np.uint8)
        bit_index = int(RNG.integers(0, 1024))
        changed = base.copy()
        changed[bit_index // 8] ^= np.uint8(1 << (bit_index % 8))
        c1 = _feistel_block(base.tobytes(), mix_key, 0)
        c2 = _feistel_block(changed.tobytes(), mix_key, 0)
        rates.append(hamming_bits(c1, c2) / 1024.0)
    return {
        "trials": trials,
        "mean_output_bit_flip_fraction": float(statistics.mean(rates)),
        "min": float(min(rates)),
        "max": float(max(rates)),
        "idealized_random_permutation_reference": 0.5,
        "interpretation": "Diagnostic only. A result near 0.5 does not prove security.",
    }


def key_sensitivity_experiment(master_key: bytes, trials: int = 32) -> dict:
    """Flip one bit in the master key and compare raw activation outputs."""
    mix_key, _ = _derive_subkeys(master_key)
    sample = RNG.integers(0, 256, size=128, dtype=np.uint8).tobytes()
    baseline = _activation_transform(sample, mix_key)
    rates = []
    for i in range(trials):
        altered = bytearray(master_key)
        bit_index = i % (len(altered) * 8)
        altered[bit_index // 8] ^= 1 << (bit_index % 8)
        altered_mix, _ = _derive_subkeys(bytes(altered))
        changed = _activation_transform(sample, altered_mix)
        rates.append(hamming_bits(baseline, changed) / (len(baseline) * 8))
    return {
        "trials": trials,
        "mean_output_bit_flip_fraction": float(statistics.mean(rates)),
        "min": float(min(rates)),
        "max": float(max(rates)),
        "interpretation": "Key sensitivity diagnostic only; not a key-recovery resistance proof.",
    }


def bit_balance_experiment(key: bytes, samples: int = 256) -> dict:
    mix_key, _ = _derive_subkeys(key)
    outputs = []
    for _ in range(samples):
        block = RNG.integers(0, 256, size=128, dtype=np.uint8).tobytes()
        outputs.append(_feistel_block(block, mix_key, 0))
    joined = b"".join(outputs)
    ones = sum(byte.bit_count() for byte in joined)
    total = len(joined) * 8
    return {
        "random_input_blocks": samples,
        "output_one_bit_fraction": ones / total,
        "reference": 0.5,
        "interpretation": "Aggregate bit balance only; does not test higher-order correlations.",
    }


def chosen_known_plaintext_demo(key: bytes) -> dict:
    """Create a small chosen/known-plaintext dataset for follow-on cryptanalysis."""
    mix_key, _ = _derive_subkeys(key)
    chosen = [
        bytes(128),
        bytes([0xFF]) * 128,
        bytes([0xAA]) * 128,
        bytes([0x55]) * 128,
        bytes(range(128)),
    ]
    for bit in range(0, 1024, 64):
        block = bytearray(128)
        block[bit // 8] = 1 << (bit % 8)
        chosen.append(bytes(block))

    path = RESULTS / "known_plaintext_pairs.csv"
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["case", "plaintext_hex", "activation_output_hex"])
        for index, plaintext in enumerate(chosen):
            transformed = _activation_transform(plaintext, mix_key)
            writer.writerow([index, plaintext.hex(), transformed.hex()])
    return {
        "pairs_written": len(chosen),
        "file": str(path),
        "what_this_is": "A dataset of chosen inputs and raw mixer outputs for later analysis.",
        "what_this_is_not": "It is not a successful key-recovery attack or a security proof.",
    }



def reduced_keyspace_attack(key_space_bits: int = 8) -> dict:
    """Brute-force a deliberately tiny key space using one known plaintext pair.

    This does NOT attack a random 256-bit key. It demonstrates why key entropy,
    rather than the vector dimension count, determines brute-force resistance.
    """
    if not 1 <= key_space_bits <= 12:
        raise ValueError("For a fast classroom demo, key_space_bits must be 1..12")
    secret_value = 173 % (1 << key_space_bits)
    weak_master = bytes([secret_value]) * 32
    known_plaintext = b"known plaintext: VECTORSHIELD"
    true_mix_key, _ = _derive_subkeys(weak_master)
    observed = _activation_transform(known_plaintext, true_mix_key)

    attempts = 0
    recovered_value = None
    for candidate_value in range(1 << key_space_bits):
        attempts += 1
        candidate_master = bytes([candidate_value]) * 32
        candidate_mix_key, _ = _derive_subkeys(candidate_master)
        try:
            candidate_plaintext = _activation_transform(observed, candidate_mix_key, decrypt=True)
        except Exception:
            # Most wrong candidate keys fail the embedded-length sanity check.
            continue
        if candidate_plaintext == known_plaintext:
            recovered_value = candidate_value
            break
    return {
        "toy_key_entropy_bits": key_space_bits,
        "candidate_keys": 1 << key_space_bits,
        "attempts_until_recovery": attempts,
        "key_recovered": recovered_value == secret_value,
        "warning": "This intentionally weak repeated-byte toy key is not representative of a random 256-bit key.",
    }

def performance_benchmark(key: bytes, repetitions: int = 8) -> dict:
    """Compare AEAD-only to the full prototype pipeline. Timings are machine-specific."""
    _, aead_key = _derive_subkeys(key)
    aes = AESGCM(aead_key)
    sizes = [16, 128, 1024, 8192]
    report = {}
    for size in sizes:
        payload = bytes((i % 256 for i in range(size)))
        # Warm up
        aes.encrypt(os.urandom(12), payload, None)
        start = time.perf_counter()
        for _ in range(repetitions):
            aes.encrypt(os.urandom(12), payload, None)
        aes_ms = (time.perf_counter() - start) * 1000 / repetitions

        start = time.perf_counter()
        for _ in range(repetitions):
            transformed = _activation_transform(payload, _derive_subkeys(key)[0])
            aes.encrypt(os.urandom(12), transformed, None)
        full_ms = (time.perf_counter() - start) * 1000 / repetitions
        report[str(size)] = {
            "message_bytes": size,
            "aes_gcm_only_mean_ms": aes_ms,
            "activation_plus_aes_gcm_mean_ms": full_ms,
            "measured_extra_ms": max(0.0, full_ms - aes_ms),
        }
    return report


def main() -> None:
    key = generate_master_key()
    result = {
        "prototype": "VectorShield research kit",
        "warning": "Diagnostics are not a cryptographic security proof.",
        "activation_inverse": activation_round_trip_trials(key),
        "plaintext_avalanche": avalanche_experiment(key),
        "key_sensitivity": key_sensitivity_experiment(key),
        "output_bit_balance": bit_balance_experiment(key),
        "chosen_known_plaintext_dataset": chosen_known_plaintext_demo(key),
        "reduced_keyspace_known_plaintext_attack": reduced_keyspace_attack(),
        "performance": performance_benchmark(key),
    }
    output = RESULTS / "experiment_report.json"
    output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))
    print(f"\nSaved report: {output}")


if __name__ == "__main__":
    main()
