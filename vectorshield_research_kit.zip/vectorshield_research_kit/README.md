# VectorShield research kit

A runnable research prototype for testing the proposed idea: a secret key controls a Transformer-inspired activation function, which is used as the round function in a reversible Feistel network. The network is then wrapped in AES-256-GCM.

## Important: what is and is not being tested

- The activation component uses message-derived queries and key-derived keys/values in a small cross-attention-style calculation.
- Its Q/K/V representation has 8 × 128 = 1,024 values.
- The attention calculation is **not a trained Transformer or language model**. It is a small fixed mathematical experiment.
- A Feistel construction makes the activation-mixer permutation exactly reversible, even though the round function itself is not invertible.
- AES-256-GCM is the component providing confidentiality and integrity in the complete message API.
- This version uses a pre-shared random 32-byte key. It does not implement ML-KEM, public-key key exchange, a network transport, or a post-quantum protocol.
- Nothing here establishes that the activation mixer is a secure cipher or provides an advantage against quantum computers.

## Requirements

- Python 3.10+
- A normal CPU; no GPU required
- Packages in `requirements.txt`

## Install

```bash
python -m venv .venv
```

Windows:

```powershell
.venv\\Scripts\\activate
```

macOS/Linux:

```bash
source .venv/bin/activate
```

Then:

```bash
python -m pip install -r requirements.txt
```

## Run the code smoke test

```bash
python vectorshield.py
```

## Run the actual automated test suite

```bash
python -m pytest -v
```

The tests cover exact inversion, boundary message sizes, Unicode, arbitrary binary data, 100 randomized round trips, wrong-key rejection, ciphertext and nonce tampering, associated-data authentication, malformed packets, and nonce-randomized packets.

## Run research diagnostics and benchmarks

```bash
python run_experiments.py
```

This writes:

- `results/experiment_report.json`
- `results/known_plaintext_pairs.csv`

Diagnostics include activation inverse trials, input-bit avalanche measurements, key sensitivity, coarse output-bit balance, a chosen/known-plaintext sample set, a deliberately reduced-keyspace known-plaintext brute-force demonstration, and speed comparisons against AES-GCM alone.

These are exploratory diagnostics. In particular, a good avalanche score or bit balance does **not** prove resistance to known-plaintext, chosen-plaintext, differential, linear, algebraic, side-channel, or quantum attacks.

## Minimal Alice/Bob example

```python
from vectorshield import generate_master_key, encrypt_message, decrypt_message

# For the demo, Alice and Bob must already share this key securely.
shared_key = generate_master_key()

# Alice:
packet = encrypt_message(shared_key, "Meet me at 5 PM")
print("Send this packet to Bob:", packet.encoded)

# Bob:
message = decrypt_message(shared_key, packet.encoded)
print("Recovered:", message)
```

Do not transmit the shared key alongside the packet. Do not use this prototype to protect real confidential information.
