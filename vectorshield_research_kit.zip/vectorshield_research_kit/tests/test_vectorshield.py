import base64
import os
import random

import pytest

from run_experiments import reduced_keyspace_attack

from vectorshield import (
    EncryptedPacket,
    PacketFormatError,
    VectorShieldError,
    _activation_transform,
    _derive_subkeys,
    _feistel_block,
    decrypt_message,
    encrypt_message,
    generate_master_key,
)


@pytest.fixture
def key():
    return generate_master_key()


def test_text_round_trip(key):
    message = "Hello Bob — नमस्ते — 🔐 — 你好"
    packet = encrypt_message(key, message)
    assert decrypt_message(key, packet) == message


@pytest.mark.parametrize("length", [0, 1, 2, 7, 8, 63, 64, 119, 120, 121, 127, 128, 129, 255, 256, 1024, 4097])
def test_activation_transform_exact_inverse_for_lengths(key, length):
    mix_key, _ = _derive_subkeys(key)
    rng = random.Random(length)
    message = bytes(rng.randrange(256) for _ in range(length))
    transformed = _activation_transform(message, mix_key)
    assert _activation_transform(transformed, mix_key, decrypt=True) == message


def test_feistel_block_is_exactly_reversible(key):
    mix_key, _ = _derive_subkeys(key)
    rng = random.Random(12345)
    for _ in range(30):
        block = bytes(rng.randrange(256) for _ in range(128))
        encrypted = _feistel_block(block, mix_key, block_index=0)
        recovered = _feistel_block(encrypted, mix_key, block_index=0, decrypt=True)
        assert recovered == block


def test_bytes_round_trip(key):
    message = bytes(range(256)) + os.urandom(37)
    packet = encrypt_message(key, message)
    assert decrypt_message(key, packet, as_text=False) == message


def test_invalid_utf8_is_not_silently_accepted(key):
    packet = encrypt_message(key, b"\xff\xfe")
    with pytest.raises(VectorShieldError, match="valid UTF-8"):
        decrypt_message(key, packet, as_text=True)
    assert decrypt_message(key, packet, as_text=False) == b"\xff\xfe"


def test_wrong_key_rejected(key):
    packet = encrypt_message(key, "secret")
    with pytest.raises(VectorShieldError, match="Authentication failed"):
        decrypt_message(generate_master_key(), packet)


def test_tampered_ciphertext_rejected(key):
    packet = encrypt_message(key, "tamper me")
    raw = bytearray(base64.urlsafe_b64decode(packet.encoded.encode("ascii")))
    raw[-1] ^= 0x01
    tampered = base64.urlsafe_b64encode(raw).decode("ascii")
    with pytest.raises(VectorShieldError, match="Authentication failed"):
        decrypt_message(key, tampered)


def test_tampered_nonce_rejected(key):
    packet = encrypt_message(key, "tamper nonce")
    raw = bytearray(base64.urlsafe_b64decode(packet.encoded.encode("ascii")))
    raw[3] ^= 0x01  # first nonce byte follows the 3-byte version string
    tampered = base64.urlsafe_b64encode(raw).decode("ascii")
    with pytest.raises(VectorShieldError, match="Authentication failed"):
        decrypt_message(key, tampered)


def test_associated_data_is_authenticated(key):
    packet = encrypt_message(key, "bound to context", associated_data=b"alice->bob")
    assert decrypt_message(key, packet, associated_data=b"alice->bob") == "bound to context"
    with pytest.raises(VectorShieldError, match="Authentication failed"):
        decrypt_message(key, packet, associated_data=b"alice->mallory")


def test_same_message_uses_fresh_randomized_packet(key):
    first = encrypt_message(key, "repeat")
    second = encrypt_message(key, "repeat")
    assert first.encoded != second.encoded
    assert decrypt_message(key, first) == "repeat"
    assert decrypt_message(key, second) == "repeat"


def test_raw_activation_transform_is_deterministic_and_not_randomized(key):
    """Important research observation: the inner transform is deterministic."""
    mix_key, _ = _derive_subkeys(key)
    message = b"known plaintext test" * 10
    first = _activation_transform(message, mix_key)
    second = _activation_transform(message, mix_key)
    assert first == second


def test_different_mix_keys_change_raw_transform(key):
    mix_key_1, _ = _derive_subkeys(key)
    changed = bytearray(key)
    changed[0] ^= 1
    mix_key_2, _ = _derive_subkeys(bytes(changed))
    sample = bytes(range(128))
    assert _activation_transform(sample, mix_key_1) != _activation_transform(sample, mix_key_2)


def test_many_random_messages_round_trip(key):
    rng = random.Random(20261102)
    for _ in range(100):
        length = rng.randrange(0, 5000)
        data = bytes(rng.randrange(256) for _ in range(length))
        packet = encrypt_message(key, data)
        assert decrypt_message(key, packet, as_text=False) == data


def test_malformed_base64_rejected(key):
    with pytest.raises(PacketFormatError):
        decrypt_message(key, "%%%not-base64%%")


def test_unknown_version_rejected(key):
    packet = encrypt_message(key, "version")
    raw = bytearray(base64.urlsafe_b64decode(packet.encoded.encode("ascii")))
    raw[0:3] = b"BAD"
    malformed = base64.urlsafe_b64encode(raw).decode("ascii")
    with pytest.raises(PacketFormatError, match="unknown version"):
        decrypt_message(key, malformed)


def test_key_length_checked():
    with pytest.raises(ValueError, match="exactly 32"):
        encrypt_message(b"short", "message")


def test_packet_object_and_string_both_work(key):
    packet = encrypt_message(key, "packet compatibility")
    assert isinstance(packet, EncryptedPacket)
    assert decrypt_message(key, packet) == "packet compatibility"
    assert decrypt_message(key, packet.encoded) == "packet compatibility"


def test_known_plaintext_bruteforce_recovers_deliberately_weak_toy_key():
    result = reduced_keyspace_attack(key_space_bits=8)
    assert result["key_recovered"] is True
    assert result["candidate_keys"] == 256
    assert 1 <= result["attempts_until_recovery"] <= 256
