"""VectorShield research kit — an educational, key-conditioned activation-mixer prototype.

SECURITY STATUS
---------------
This is a research demo, NOT a novel or independently reviewed cipher.
The reversible neural-style layer is experimental and contributes no proven
cryptographic security. Confidentiality and integrity in this demo come from
AES-256-GCM. The two users must already share a random 256-bit master key.
There is no post-quantum key-establishment step (such as ML-KEM) in v0.

The activation mixer is a tiny, deterministic, single-head cross-attention
function used inside a Feistel network. The Feistel structure is exactly
reversible; its round function does not need to be invertible.

Install:
    python -m pip install cryptography numpy

Run tests:
    python vectorshield_v0.py
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import secrets
import struct
from dataclasses import dataclass
from typing import Final

import numpy as np
from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF


VERSION: Final[bytes] = b"VS1"
NONCE_LEN: Final[int] = 12
MASTER_KEY_LEN: Final[int] = 32
BLOCK_LEN: Final[int] = 128       # 1,024 bits; two 64-byte Feistel halves
HALF_LEN: Final[int] = BLOCK_LEN // 2
ROUNDS: Final[int] = 8
TOKEN_COUNT: Final[int] = 8
FEATURES: Final[int] = 8
HIDDEN_DIM: Final[int] = 128      # 8 tokens × 128 hidden units = 1,024 activations


class VectorShieldError(Exception):
    """Base exception for VectorShield errors."""


class PacketFormatError(VectorShieldError):
    """Raised when a packet is malformed or uses an unsupported version."""


def generate_master_key() -> bytes:
    """Generate a uniformly random 256-bit key for out-of-band sharing."""
    return secrets.token_bytes(MASTER_KEY_LEN)


def _check_master_key(master_key: bytes) -> None:
    if not isinstance(master_key, bytes) or len(master_key) != MASTER_KEY_LEN:
        raise ValueError("master_key must be exactly 32 random bytes")


def _derive_subkeys(master_key: bytes) -> tuple[bytes, bytes]:
    """Derive independent mixer and AEAD keys from the shared master key."""
    _check_master_key(master_key)
    salt = b"VectorShield-research-public-salt"
    mix_key = HKDF(
        algorithm=hashes.SHA256(), length=32, salt=salt,
        info=b"VectorShield-research/activation-mixer",
    ).derive(master_key)
    aead_key = HKDF(
        algorithm=hashes.SHA256(), length=32, salt=salt,
        info=b"VectorShield-research/aes-256-gcm",
    ).derive(master_key)
    return mix_key, aead_key


def _expand_bytes(seed: bytes, label: bytes, count: int) -> np.ndarray:
    """Deterministically expand a seed into bytes using SHAKE256."""
    raw = hashlib.shake_256(seed + b"|" + label).digest(count)
    return np.frombuffer(raw, dtype=np.uint8).copy()


def _keyed_matrix(seed: bytes, label: bytes, rows: int, cols: int,
                  scale: float = 0.65) -> np.ndarray:
    raw = _expand_bytes(seed, label, rows * cols)
    # Fixed conversion: identical bytes produce identical float32 inputs.
    vals = (raw.astype(np.float32) - np.float32(127.5)) / np.float32(127.5)
    return (vals.reshape(rows, cols) * np.float32(scale)).astype(np.float32)


def _softmax_rows(x: np.ndarray) -> np.ndarray:
    # Float64 softmax reduces numerical sensitivity for this prototype.
    x64 = x.astype(np.float64)
    x64 -= np.max(x64, axis=1, keepdims=True)
    e = np.exp(x64)
    return (e / np.sum(e, axis=1, keepdims=True)).astype(np.float32)


def _activation_mask(right_half: bytes, mix_key: bytes,
                     block_index: int, round_index: int) -> bytes:
    """Key-conditioned cross-attention activation function -> 64-byte mask.

    Message-derived bytes form queries. Key-derived bytes form keys and values.
    The generated mask is used by an exactly reversible Feistel round.
    This is a tiny Transformer-style block, not a trained language model.
    """
    if len(right_half) != HALF_LEN:
        raise ValueError("right_half must be exactly 64 bytes")

    context = struct.pack(">QI", block_index, round_index)
    round_seed = hmac.new(mix_key, b"VS0-round/" + context, hashlib.sha256).digest()

    # Eight message tokens, each with eight features.
    message_tokens = np.frombuffer(right_half, dtype=np.uint8).astype(np.float32)
    message_tokens = (message_tokens.reshape(TOKEN_COUNT, FEATURES) - 127.5) / 127.5

    # Key-derived tokens: the key and message interact through attention.
    key_raw = _expand_bytes(round_seed, b"key-tokens", TOKEN_COUNT * FEATURES)
    key_tokens = key_raw.astype(np.float32).reshape(TOKEN_COUNT, FEATURES)
    key_tokens = (key_tokens - 127.5) / 127.5

    wq = _keyed_matrix(round_seed, b"Wq", FEATURES, HIDDEN_DIM)
    wk = _keyed_matrix(round_seed, b"Wk", FEATURES, HIDDEN_DIM)
    wv = _keyed_matrix(round_seed, b"Wv", FEATURES, HIDDEN_DIM)
    wo = _keyed_matrix(round_seed, b"Wo", HIDDEN_DIM, FEATURES)
    wr = _keyed_matrix(round_seed, b"Wr", FEATURES, FEATURES, scale=0.20)
    bias_raw = _expand_bytes(round_seed, b"bias", TOKEN_COUNT * FEATURES)
    bias = ((bias_raw.astype(np.float32) - 127.5) / 127.5 * 0.15).reshape(
        TOKEN_COUNT, FEATURES
    )

    # One-head cross-attention: message queries attend to key-derived K/V.
    # Q, K and V each carry 8 × 128 = 1,024 hidden activation values.
    q = message_tokens @ wq
    k = key_tokens @ wk
    v = key_tokens @ wv
    scores = (q @ k.T) / np.float32(np.sqrt(HIDDEN_DIM))
    attention = _softmax_rows(scores)
    activations = attention @ v
    activations = activations @ wo + np.float32(0.25) * (message_tokens @ wr) + bias
    activations = np.tanh(activations).astype(np.float32)

    # Quantise activations to a byte mask for the byte-oriented Feistel network.
    mask = np.rint((activations + 1.0) * 127.5).clip(0, 255).astype(np.uint8)
    return mask.reshape(HALF_LEN).tobytes()


def _xor_bytes(a: bytes, b: bytes) -> bytes:
    return bytes(x ^ y for x, y in zip(a, b))


def _feistel_block(block: bytes, mix_key: bytes, block_index: int,
                   decrypt: bool = False) -> bytes:
    if len(block) != BLOCK_LEN:
        raise ValueError("Feistel block must be 128 bytes")
    left, right = block[:HALF_LEN], block[HALF_LEN:]

    if not decrypt:
        for r in range(ROUNDS):
            mask = _activation_mask(right, mix_key, block_index, r)
            left, right = right, _xor_bytes(left, mask)
    else:
        for r in reversed(range(ROUNDS)):
            # Inverse Feistel step: L = R' XOR F(L'); R = L'.
            old_left = _xor_bytes(right, _activation_mask(left, mix_key, block_index, r))
            left, right = old_left, left

    return left + right


def _activation_transform(data: bytes, mix_key: bytes, decrypt: bool = False) -> bytes:
    """Apply the invertible activation Feistel network to an arbitrary byte string."""
    if not decrypt:
        framed = len(data).to_bytes(8, "big") + data
        padded_len = ((len(framed) + BLOCK_LEN - 1) // BLOCK_LEN) * BLOCK_LEN
        framed += b"\x00" * (padded_len - len(framed))
        out = bytearray()
        for block_index, start in enumerate(range(0, len(framed), BLOCK_LEN)):
            out.extend(_feistel_block(framed[start:start + BLOCK_LEN], mix_key, block_index))
        return bytes(out)

    if len(data) == 0 or len(data) % BLOCK_LEN != 0:
        raise PacketFormatError("Invalid transformed payload length")
    out = bytearray()
    for block_index, start in enumerate(range(0, len(data), BLOCK_LEN)):
        out.extend(_feistel_block(data[start:start + BLOCK_LEN], mix_key, block_index, decrypt=True))
    if len(out) < 8:
        raise PacketFormatError("Transformed payload is too short")
    original_len = int.from_bytes(out[:8], "big")
    if original_len > len(out) - 8:
        raise PacketFormatError("Invalid embedded message length")
    return bytes(out[8:8 + original_len])


@dataclass(frozen=True)
class EncryptedPacket:
    """Base64-url packet wrapper suitable for copying between two users."""
    encoded: str

    def __str__(self) -> str:
        return self.encoded


def encrypt_message(master_key: bytes, plaintext: str | bytes,
                    associated_data: bytes = b"") -> EncryptedPacket:
    """Encrypt a message. Alice and Bob must already share master_key."""
    if isinstance(plaintext, str):
        plaintext_bytes = plaintext.encode("utf-8")
    elif isinstance(plaintext, bytes):
        plaintext_bytes = plaintext
    else:
        raise TypeError("plaintext must be str or bytes")
    if not isinstance(associated_data, bytes):
        raise TypeError("associated_data must be bytes")

    mix_key, aead_key = _derive_subkeys(master_key)
    mixed = _activation_transform(plaintext_bytes, mix_key, decrypt=False)
    nonce = secrets.token_bytes(NONCE_LEN)
    ciphertext = AESGCM(aead_key).encrypt(nonce, mixed, associated_data)
    packet = VERSION + nonce + ciphertext
    return EncryptedPacket(base64.urlsafe_b64encode(packet).decode("ascii"))


def decrypt_message(master_key: bytes, packet: EncryptedPacket | str,
                    associated_data: bytes = b"", as_text: bool = True) -> str | bytes:
    """Authenticate, decrypt, then reverse the activation mixer."""
    _check_master_key(master_key)
    encoded = packet.encoded if isinstance(packet, EncryptedPacket) else packet
    if not isinstance(encoded, str):
        raise TypeError("packet must be EncryptedPacket or base64 string")
    if not isinstance(associated_data, bytes):
        raise TypeError("associated_data must be bytes")
    try:
        raw = base64.b64decode(encoded.encode("ascii"), altchars=b"-_", validate=True)
    except Exception as exc:
        raise PacketFormatError("Packet is not valid Base64-url") from exc
    prefix_len = len(VERSION)
    if len(raw) < prefix_len + NONCE_LEN + 16 or raw[:prefix_len] != VERSION:
        raise PacketFormatError("Packet is too short or has an unknown version")
    nonce = raw[prefix_len:prefix_len + NONCE_LEN]
    ciphertext = raw[prefix_len + NONCE_LEN:]
    mix_key, aead_key = _derive_subkeys(master_key)
    try:
        mixed = AESGCM(aead_key).decrypt(nonce, ciphertext, associated_data)
    except InvalidTag as exc:
        raise VectorShieldError("Authentication failed: wrong key, modified packet, or wrong associated data") from exc
    plaintext = _activation_transform(mixed, mix_key, decrypt=True)
    if as_text:
        try:
            return plaintext.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise VectorShieldError("Decrypted bytes are not valid UTF-8; use as_text=False") from exc
    return plaintext


def self_test() -> None:
    """Quick smoke test; the comprehensive suite lives in tests/."""
    key = generate_master_key()
    samples: list[str | bytes] = [
        "Hello Bob — VectorShield research kit.",
        "",
        "A" * 700,
        bytes(range(256)),
    ]
    for sample in samples:
        packet = encrypt_message(key, sample)
        recovered = decrypt_message(key, packet, as_text=isinstance(sample, str))
        assert recovered == sample, "round-trip mismatch"

    packet = encrypt_message(key, "tamper test")
    raw = bytearray(base64.urlsafe_b64decode(packet.encoded.encode("ascii")))
    raw[-1] ^= 1
    tampered = base64.urlsafe_b64encode(raw).decode("ascii")
    try:
        decrypt_message(key, tampered)
    except VectorShieldError:
        pass
    else:
        raise AssertionError("tampering was not detected")

    print("VectorShield smoke test: PASS")
    print("- exact text/bytes round trips: PASS")
    print("- tamper detection: PASS")
    print("- wrong-key rejection: checked in pytest suite")
    print("NOTE: This does not prove the activation mixer is secure or quantum-resistant.")


def _cli() -> None:
    import argparse
    import sys

    parser = argparse.ArgumentParser(description="VectorShield educational research prototype")
    parser.add_argument("command", nargs="?", choices=["selftest"], default="selftest")
    args = parser.parse_args()
    if args.command == "selftest":
        self_test()


if __name__ == "__main__":
    _cli()
