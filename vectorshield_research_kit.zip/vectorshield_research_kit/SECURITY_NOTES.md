# Security notes and honest interpretation

## Security boundary

In `encrypt_message`, the raw activation transform is applied first and AES-256-GCM encrypts and authenticates the transformed bytes. The activation transform is deterministic for a fixed input and derived key. The outer AEAD uses a fresh random 96-bit nonce per packet.

The security claim for this prototype is therefore limited to the standard AES-GCM construction, assuming a uniformly random 256-bit pre-shared key, correct nonce use, and correct library implementation. The activation mixer has no independent security claim. It may add computational cost and implementation complexity without adding meaningful security.

## What the tests establish

- The implementation reverses its own Feistel transform for tested inputs.
- The wrapper recovers tested messages exactly.
- AES-GCM rejects tested wrong-key, wrong-associated-data, and tampering cases.
- The activation output is sensitive to the specific test inputs and keys in the measured diagnostics.

## What the tests do not establish

- A proof that the mixer is a pseudorandom permutation.
- Resistance to known-plaintext or chosen-plaintext key recovery.
- Resistance to differential, linear, algebraic, neural, side-channel, fault, or quantum attacks.
- Interoperability across different hardware / BLAS implementations. The activation calculation uses floating-point operations, so tiny platform-specific numerical differences could affect byte quantisation.
- A quantum-resistant key-establishment protocol. There is no ML-KEM in this version.

## Key insight for the research question

A 1,024-value activation vector is a representation size, not 1,024 bits of secret entropy. Neural-network complexity is not a hardness assumption. To claim a cryptographic contribution, the design needs a formal threat model, a precise construction, independent cryptanalysis, and comparison with established cryptographic baselines.

For a real system, the activation mixer should not replace standard encryption. A sensible next milestone is to integrate a vetted ML-KEM implementation for post-quantum key establishment, retain a standard AEAD for messages, and separately evaluate whether the activation component has any measurable benefit.
