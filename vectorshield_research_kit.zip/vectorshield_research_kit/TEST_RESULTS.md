# VectorShield research kit — actual run results

Run date: 2026-11-02 (container test environment)
Python: 3.13.5

## Automated tests

`python -m pytest -v`

**Result: 34 passed in 3.60 seconds.**

Coverage includes exact Feistel inversion, transform round trips around block/padding boundaries, Unicode, empty and long messages, arbitrary binary payloads, 100 randomized message round trips, invalid UTF-8 handling, wrong-key rejection, ciphertext tampering, nonce tampering, associated-data authentication, fresh packet randomization, malformed packets, key-length validation, and a deliberately weak-key known-plaintext brute-force demonstration.

## Research diagnostics

`python run_experiments.py`

| Diagnostic | Measured result | Interpretation |
|---|---:|---|
| Activation inverse | 100 / 100 passed | Exact reversibility for tested blocks |
| Plaintext avalanche | 4.68% average output bits changed | Serious diffusion warning; far below the ~50% idealized reference |
| Key sensitivity | 49.99% average output bits changed | One-bit key changes strongly alter this output; not a security proof |
| Output bit balance | 50.04% ones | Coarse balance looks near 50%; this alone is weak evidence |
| 8-bit toy-key search | Recovered in 174 of 256 guesses | Demonstrates brute-force recovery when key entropy is deliberately tiny |

## Timing sample from this container

| Message size | AES-GCM-only mean | Activation + AES-GCM mean |
|---:|---:|---:|
| 16 bytes | 0.0012 ms | 0.69 ms |
| 128 bytes | 0.0007 ms | 1.38 ms |
| 1 KiB | 0.0009 ms | 6.81 ms |
| 8 KiB | 0.0017 ms | 49.12 ms |

These are highly environment-dependent microbenchmarks, not promises about a user's laptop. They show the current Python activation mixer adds substantial overhead compared with the native AES-GCM operation.

## Bottom line

The implementation is reversible and the authenticated wrapper passes its tests. However, the poor plaintext avalanche and the overhead mean this activation design is **not ready to be treated as a cipher**. The results justify another research iteration, not a claim of quantum resistance. The AES-GCM wrapper is what protects the demo messages; this kit has no post-quantum key exchange.
