@echo off
rem ECHO-AI one-shot pipeline: fetch online data -> build dataset -> train -> demo wav.
rem Windows twin of run.sh. Safe to re-run; each stage is resumable.
cd /d "%~dp0"
if not defined PYTHON set "PYTHON=python"

echo == [1/4] Fetching ESC-50 real-audio subset (online) ==
%PYTHON% -m echoai.cli fetch --esc-cap 20 || goto :fail

echo == [2/4] Building feature dataset (synthetic physics corpus + ESC-50) ==
%PYTHON% -m echoai.cli dataset --n 400 || goto :fail

echo == [3/4] Training ensemble classifier ==
%PYTHON% -m echoai.cli train || goto :fail

echo == [4/4] Writing demo rescue scene WAV ==
%PYTHON% -m echoai.cli demo-wav || goto :fail

echo.
echo Done. Launch with:  %PYTHON% -m echoai.cli launch   (mode: sim, file or live)
exit /b 0

:fail
echo.
echo FAILED - see the error above.
exit /b 1
