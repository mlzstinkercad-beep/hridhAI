"""End-to-end offline test suite for ECHO-AI (no mic, no network).

Runs: feature determinism/finiteness, corpus labels, pattern state
machine, briefing generation, persistence round-trip, processor gating,
and a full simulated distress scenario -> DistressAlert -> briefing.
"""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from echoai.classifier import AcousticClassifier, ImpactEvent
from echoai.config import SAMPLE_RATE
from echoai.pattern import DistressAlert, PatternEngine
from echoai.processor import SignalProcessor
from echoai.synth_corpus import (generate_corpus, make_negative_clip,
                                 make_structural_tap_clip)
from echoai.features import extract_features
from echoai.briefing import BriefingContext, generate as gen_briefing
from echoai.persistence import EventStore

PASS = 0


def ok(name, cond, detail=""):
    global PASS
    assert cond, f"FAIL {name} {detail}"
    PASS += 1
    print(f"  ok - {name}")


def test_features():
    print("[features]")
    rng = np.random.default_rng(3)
    tap, _ = make_structural_tap_clip(rng, n_taps=3)
    r = extract_features(tap, SAMPLE_RATE)
    ok("16-dim vector", r["vector"].shape == (16,))
    ok("finite", bool(np.all(np.isfinite(r["vector"]))))
    r2 = extract_features(tap, SAMPLE_RATE)
    ok("deterministic", np.allclose(r["vector"], r2["vector"]))
    noise, _ = make_negative_clip(np.random.default_rng(4))
    rn = extract_features(noise, SAMPLE_RATE)
    ok("tap vs noise separable (centroid)",
       r["telemetry"]["centroid_hz"] < rn["telemetry"]["centroid_hz"],
       f"{r['telemetry']['centroid_hz']:.0f} vs {rn['telemetry']['centroid_hz']:.0f}")
    ok("flatness within [0,1]", 0.0 <= r["telemetry"]["flatness"] <= 1.0)


def test_corpus():
    print("[corpus]")
    rng = np.random.default_rng(5)
    tap_c, noise_c, clat_c = [], [], []
    gen = generate_corpus(n_per_class=30, seed=5)
    for clip, label, _ in gen:
        f = extract_features(clip)["telemetry"]
        {"structural_tap": tap_c, "ambient_noise": noise_c,
         "surface_clatter": clat_c}[label].append(f)
    ok("labels balanced", len(tap_c) == 30 and len(noise_c) + len(clat_c) == 30,
       f"tap={len(tap_c)} amb={len(noise_c)} clat={len(clat_c)}")
    tm = np.mean([f["centroid_hz"] for f in tap_c])
    cm = np.mean([f["centroid_hz"] for f in clat_c])
    ok("taps darker than clatter (centroid)", tm < cm, f"{tm:.0f} vs {cm:.0f}")
    om = np.mean([f["onset_density"] for f in tap_c])
    onm = np.mean([f["onset_density"] for f in noise_c])
    ok("taps more percussive than ambience", om > onm, f"{om:.2f} vs {onm:.2f}")


def test_pattern():
    print("[pattern]")
    pe = PatternEngine()
    t0 = 100.0
    evs = [ImpactEvent(t_mono=t0 + i * 0.6, confidence=80.0,
                       label="structural_tap", telemetry={}) for i in range(3)]
    alerts = [pe.register_tap(e) for e in evs]
    ok("fires exactly on 3rd", sum(a is not None for a in alerts) == 1)
    a = alerts[-1]
    ok("avg conf", abs(a.avg_conf - 80.0) < 1e-6)
    ok("cadence mean ~0.6", abs(a.cadence_s[1] - 0.6) < 0.05)
    # cooldown: immediate 4th burst should NOT alert
    ev4 = ImpactEvent(t_mono=t0 + 10, confidence=90, label="structural_tap", telemetry={})
    pe2 = PatternEngine()
    for e in evs[:3]:
        pe2.register_tap(e)
    a2 = pe2.register_tap(ImpactEvent(t_mono=t0 + 2.6, confidence=90,
                                      label="structural_tap", telemetry={}))
    ok("cooldown suppresses immediate re-alert", a2 is None)


def test_briefing():
    print("[briefing]")
    alert = DistressAlert(t_trigger=1.0, n_taps=3, avg_conf=82.4, min_conf=76.1,
                           cadence_s=(0.55, 0.62, 0.11), tap_times=[1, 2, 3])
    text = gen_briefing(alert, BriefingContext())
    for needle in ("AI RESCUE INTELLIGENCE BRIEFING", "Building B, Grid Sector 4",
                   "82.4%", "USAR Team 7", "RECOMMENDED ACTIONS", "burial depth"):
        ok("contains: " + needle[:30], needle in text)


def test_persistence():
    print("[persistence]")
    with tempfile.TemporaryDirectory() as d:
        store = EventStore(Path(d) / "t.db")
        ev = ImpactEvent(t_mono=1.0, confidence=77.5, label="structural_tap",
                         telemetry={"centroid_hz": 600, "flatness": 0.2, "zcr": 0.05,
                                    "band_ratio": 0.4, "onset_density": 0.1,
                                    "peak": 0.4},
                         feature_vector=np.zeros(16, dtype=np.float32))
        store.log_tap(ev)
        store.log_alert(DistressAlert(1.0, 3, 80, 70, (0.5, 0.6, 0.1), [1, 2, 3]),
                        "briefing text")
        c = store.counts()
        ok("roundtrip", c["taps"] == 1 and c["alerts"] == 1)
        store.close()


def test_processor_and_classifier():
    print("[processor+classifier]")
    clf = AcousticClassifier()
    ok("classifier loads (or fallback)", clf.available or clf.last_error)
    sp = SignalProcessor(classifier=clf, pattern=PatternEngine())
    rng = np.random.default_rng(9)
    quiet = 0.001 * rng.standard_normal(int(0.15 * SAMPLE_RATE))
    f = sp.process_chunk(quiet)
    ok("quiet chunk ignored", f["event"] is None and not f["tap_verified"])
    tap_clip, _ = make_structural_tap_clip(np.random.default_rng(10), n_taps=3)
    # feed a loud tap segment
    seg = tap_clip[: int(0.15 * SAMPLE_RATE)]
    seg = (seg / max(np.max(np.abs(seg)), 1e-9) * 0.6).astype(np.float32)
    f = sp.process_chunk(seg)
    ok("loud transient gated in", f["event"] is not None)
    ok("confidence in range", 0 <= f["confidence"] <= 100)


def test_end_to_end_scenario():
    print("[scenario: 3-tap SOS -> alert -> briefing]")
    # craft a scenario: 3 verified taps 0.55s apart using classifier+pattern
    rng = np.random.default_rng(42)
    clf = AcousticClassifier()
    proc = SignalProcessor(classifier=clf, pattern=PatternEngine())
    tap_clip, positions = make_structural_tap_clip(rng, n_taps=3)
    win = int(0.15 * SAMPLE_RATE)
    fired = None
    t_sim = 0.0
    for i in range(0, len(tap_clip) - win, win):
        chunk = (tap_clip[i:i + win] / max(1e-9, np.max(np.abs(tap_clip))) * 0.7).astype(np.float32)
        f = proc.process_chunk(chunk)
        t_sim += 0.15
        if f["alert"] is not None:
            fired = f["alert"]
            break
    ok("distress alert fired", fired is not None)
    if fired:
        ok(">=3 taps", fired.n_taps >= 3)
        text = gen_briefing(fired, BriefingContext())
        ok("briefing generated", "AI RESCUE INTELLIGENCE BRIEFING" in text)


if __name__ == "__main__":
    test_features()
    test_corpus()
    test_pattern()
    test_briefing()
    test_persistence()
    test_processor_and_classifier()
    test_end_to_end_scenario()
    print(f"\nALL {PASS} CHECKS PASSED")
