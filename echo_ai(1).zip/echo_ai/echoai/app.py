"""ECHO-AI mission-control console (PyQt6).

Layout mirrors the reference design: deep navy canvas, glass panels,
teal->cyan + purple gradient accents. Top status bar; left column
telemetry (donut AI gauge, gradient bars, vertical level meter, mini
bars); center waveform + spectrogram-ish strip + pattern stepper;
right column event log + briefing viewer + LLM analyst console.

Run:  python -m echoai.app      (from the echo_ai project root)
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import numpy as np
import yaml

from PyQt6.QtCore import QObject, Qt, QThread, QTimer, pyqtSignal
from PyQt6.QtGui import QColor, QFont
from PyQt6.QtWidgets import (QApplication, QFrame, QGridLayout,
                             QHBoxLayout, QLabel, QMainWindow, QPlainTextEdit,
                             QPushButton, QSizePolicy, QVBoxLayout, QWidget)

import pyqtgraph as pg

from .briefing import BriefingContext, generate as gen_briefing
from .classifier import AcousticClassifier
from .config import CONFIG_PATH, DATA_DIR, LOG_DIR, SAMPLE_RATE
from .llm_analyst import LLMAnalyst
from .persistence import EventStore
from .pattern import DistressAlert
from .processor import SignalProcessor
from .stream import FileStream, LiveMicStream, SimulatorStream
from . import ui_widgets as uw

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


class ConsoleBridge(QObject):
    frame_ready = pyqtSignal(object)


class AudioWorker(QObject):
    """Bridges the audio stream (Python thread) to the GUI thread.

    Every cross-thread signal is emitted with Qt.AutoConnection => queued
    into the GUI event loop; no widget is ever touched off the GUI thread.
    """
    frame_ready = pyqtSignal(object)
    alert_ready = pyqtSignal(object)
    tap_logged = pyqtSignal(object)

    def __init__(self, mode, cfg):
        super().__init__()
        self.mode = mode
        self.cfg = cfg
        self.processor = SignalProcessor(classifier=AcousticClassifier())
        self.store = EventStore() if cfg["persistence"]["enabled"] else None
        self.alert_count = 0

    def callback(self, chunk):
        frame = self.processor.process_chunk(chunk, SAMPLE_RATE)
        self.frame_ready.emit(frame)
        if frame["tap_verified"] and frame["event"] is not None:
            if self.store:
                self.store.log_tap(frame["event"])
            self.tap_logged.emit(frame["event"])
        if frame["alert"] is not None:
            self.alert_ready.emit(frame["alert"])


class EchoMainWindow(QMainWindow):
    _llm_result = pyqtSignal(str)          # marshals LLM text to the GUI thread

    def __init__(self, mode="sim", cfg=None):
        super().__init__()
        self.cfg = cfg or {}
        self.mode = mode
        self.setWindowTitle("ECHO-AI // Acoustic Intelligence Grid")
        self.resize(1240, 800)
        self._apply_styles()

        self.worker = AudioWorker(mode, self._full_cfg())
        self.worker.frame_ready.connect(self.on_frame)
        self.worker.tap_logged.connect(self.on_tap)
        self.worker.alert_ready.connect(self.on_alert)

        self.brief_ctx = BriefingContext(
            sector=self.cfg.get("dispatch", {}).get("sector", "Building B, Grid Sector 4"),
            team=self.cfg.get("dispatch", {}).get("team", "USAR Team 7"),
            operator=self.cfg.get("dispatch", {}).get("operator", "Unassigned"))
        llm_cfg = self.cfg.get("dispatch", {})
        self.llm = LLMAnalyst(model=llm_cfg.get("llm_model", "glm-4-flash"),
                              enabled=llm_cfg.get("llm_enabled", True))

        self._llm_result.connect(self._show_llm_result)
        self._build_ui()
        self._start_stream()
        self.log("ECHO-AI console online. Mode: %s | classifier: %s" %
                 (mode.upper(), "ENSEMBLE v2" if self.worker.processor.classifier.available else "DSP FALLBACK"))

    # ------------------------------------------------------------- config --
    def _full_cfg(self):
        try:
            with open(CONFIG_PATH) as f:
                return yaml.safe_load(f) or {}
        except Exception:
            return {"persistence": {"enabled": True}}

    def _apply_styles(self):
        self.setStyleSheet(f"""
        QMainWindow {{ background-color: {uw.BG}; }}
        QWidget {{ color: {uw.TXT}; font-family: 'Inter','Segoe UI',sans-serif; }}
        QPlainTextEdit {{
            background-color: {uw.PANEL_INSET}; color: #C9D3E6;
            border: 1px solid rgba(255,255,255,20); border-radius: 10px;
            font-family: 'JetBrains Mono','Consolas',monospace; font-size: 9.5px;
            padding: 8px 10px 8px 8px;
        }}
        QPlainTextEdit#logbox {{
            line-wrap-mode: NoWrap;
        }}
        QPushButton {{
            background-color: {uw.PANEL_INSET}; color: {uw.TXT};
            border: 1px solid rgba(255,255,255,30); border-radius: 14px;
            padding: 5px 14px; font-size: 11px;
        }}
        QPushButton:hover {{ border-color: {uw.TEAL}; }}
        """)

    # ---------------------------------------------------------------- ui ---
    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(16, 14, 16, 14)
        root.setSpacing(12)

        root.addWidget(self._header())
        root.addWidget(self._center_row(), stretch=3)
        root.addWidget(self._bottom_row(), stretch=2)

    def _header(self):
        h = QWidget(); h.setFixedHeight(46)
        lay = QHBoxLayout(h); lay.setContentsMargins(0, 0, 0, 0)
        title = QLabel("ECHO-AI  //  ACOUSTIC INTELLIGENCE GRID")
        title.setFont(QFont("Inter", 17, QFont.Weight.Bold))
        title.setStyleSheet(f"color: {uw.TEAL}; background: transparent;")
        lay.addWidget(title)
        lay.addStretch()
        self.status_badge = QLabel(" AI MODEL ARMED ")
        self.status_badge.setFont(QFont("Inter", 10, QFont.Weight.Bold))
        self.status_badge.setStyleSheet(f"""
            color: {uw.TEAL}; background: {uw.PANEL_INSET};
            border: 1px solid {uw.TEAL}; border-radius: 11px; padding: 4px 12px;""")
        lay.addWidget(self.status_badge)
        self.llm_badge = QLabel("LLM READY" if self.llm.api_key else "LLM STANDBY")
        self.llm_badge.setFont(QFont("Inter", 9))
        self.llm_badge.setToolTip(
            "Optional LLM analyst (augments briefings when ZAI_API_KEY is set).\n"
            "The acoustic ensemble runs fully offline — LLM STANDBY is normal.")
        self.llm_badge.setStyleSheet(f"""
            color: {uw.MUT}; background: {uw.PANEL_INSET};
            border: 1px solid rgba(255,255,255,25); border-radius: 11px; padding: 4px 12px;""")
        lay.addWidget(self.llm_badge)
        return h

    def _center_row(self):
        row = QWidget()
        lay = QHBoxLayout(row); lay.setContentsMargins(0, 0, 0, 0); lay.setSpacing(12)

        # ---- left telemetry column ----
        left = uw.GlassPanel("AI TELEMETRY")
        lv = QVBoxLayout(left); lv.setContentsMargins(14, 14, 14, 14); lv.setSpacing(10)
        gauge_row = QHBoxLayout()
        self.gauge = uw.DonutGauge(size=118, line1="--%", line2="AI CONF")
        gauge_row.addWidget(self.gauge)
        vr = QVBoxLayout(); vr.setSpacing(6)
        self.vslider = uw.VSliderBar()
        gauge_row.addWidget(self.vslider)
        self.vslider.setFixedHeight(118)
        gauge_row.addLayout(vr)
        lv.addLayout(gauge_row)

        bars = {}
        for name, c1, c2 in (("FLATNESS", uw.TEAL, uw.CYAN),
                             ("ZERO-X RATE", uw.PURPLE, uw.VIOLET),
                             ("BAND RATIO", uw.TEAL, uw.CYAN)):
            l = QHBoxLayout()
            lab = QLabel(name); lab.setStyleSheet(f"color: {uw.MUT}; font-size: 8.5px; background:transparent;")
            l.addWidget(lab); l.addStretch()
            bar = uw.GradientBar(color1=c1, color2=c2, height=7)
            bars[name] = bar
            l.addWidget(bar, stretch=2)
            lv.addLayout(l)
        self._bars = bars

        self.bars = uw.MiniBars(n=16)
        lv.addWidget(self.bars)
        lv.addStretch()

        # model stats card (fills dead space, shows training provenance)
        stats = self.worker.processor.classifier.info.get("metrics") or {}
        cv = stats.get("cv_grouped_macro_f1", {})
        ho = stats.get("holdout_mixed", {})
        stat_lines = []
        if ho:
            stat_lines.append("holdout acc ......... %.1f%%" % (100 * ho.get("accuracy", 0)))
        if cv:
            stat_lines.append("grouped CV F1 ...... %.3f" % cv.get("mean", 0))
        stat_lines.append("model .............. ensemble v2 (RF+ET+MLP)")
        stat_lines.append("training data ...... %s clips" %
                         (stats.get("n_samples", "—")))
        card = QLabel("\n".join(stat_lines))
        card.setStyleSheet(f"""
            color: {uw.MUT}; font-size: 9px; background-color: {uw.PANEL_INSET};
            border: 1px solid rgba(255,255,255,18); border-radius: 8px;
            padding: 8px;""")
        card.setWordWrap(True)
        lv.addWidget(card)
        left.setFixedWidth(300)
        lay.addWidget(left, stretch=0)

        # ---- center: waveform + stepper ----
        center = uw.GlassPanel("REAL-TIME WAVEFORM // TRANSIENT MONITOR")
        cv = QVBoxLayout(center); cv.setContentsMargins(14, 14, 14, 14); cv.setSpacing(8)
        pg.setConfigOptions(antialias=True, useOpenGL=False, exitCleanup=False)
        self.plot = pg.PlotWidget()
        self.plot.setBackground(uw.PANEL_INSET)
        self.plot.setMouseEnabled(x=False, y=False)
        self.plot.hideAxis('bottom'); self.plot.hideAxis('left')
        self.plot.setYRange(-1.05, 1.05)
        pen = pg.mkPen(color=(34, 211, 197), width=1.6)
        self.wave = self.plot.plot(pen=pen)
        # threshold line
        thr_pen = pg.mkPen(color=(255, 92, 122), width=1, style=Qt.PenStyle.DashLine)
        self.plot.addItem(pg.InfiniteLine(pos=0.045, angle=0, pen=thr_pen))
        self.plot.addItem(pg.InfiniteLine(pos=-0.045, angle=0, pen=thr_pen))
        cv.addWidget(self.plot, stretch=5)

        legend = QLabel("waveform amplitude (normalised FS) · dashed = trigger threshold · AI CONF = last classified transient")
        legend.setStyleSheet(f"color: {uw.MUT}; font-size: 8.5px; background: transparent;")
        cv.addWidget(legend)

        stepper_row = QHBoxLayout()
        self.stepper = uw.StepperDots(labels=("ARM", "TAP 1", "TAP 2", "SOS"))
        stepper_row.addWidget(self.stepper, stretch=3)
        self.class_label = QLabel("CLASSIFICATION: IDLE")
        self.class_label.setStyleSheet(f"color: {uw.MUT}; font-size: 10px; background: transparent;")
        stepper_row.addWidget(self.class_label, stretch=2)
        cv.addLayout(stepper_row)
        lay.addWidget(center, stretch=5)

        # ---- right: event log ----
        right = uw.GlassPanel("MISSION EVENT LOG")
        rv = QVBoxLayout(right); rv.setContentsMargins(14, 14, 14, 14); rv.setSpacing(8)
        self.logbox = QPlainTextEdit(); self.logbox.setReadOnly(True)
        self.logbox.setObjectName("logbox")
        self.logbox.setLineWrapMode(QPlainTextEdit.LineWrapMode.WidgetWidth)
        rv.addWidget(self.logbox)
        right.setFixedWidth(330)
        lay.addWidget(right, stretch=0)
        return row

    def _bottom_row(self):
        row = QWidget()
        lay = QHBoxLayout(row); lay.setContentsMargins(0, 0, 0, 0); lay.setSpacing(12)

        # ---- briefing viewer ----
        b = uw.GlassPanel("RESCUE DISPATCH BRIEFING")
        bv = QVBoxLayout(b); bv.setContentsMargins(14, 14, 14, 14)
        self.brief_box = QPlainTextEdit(); self.brief_box.setReadOnly(True)
        self.brief_box.setPlaceholderText("No verified distress pattern yet. Briefing appears here automatically on SOS verification.")
        bv.addWidget(self.brief_box)
        b.setFixedWidth(430)
        lay.addWidget(b, stretch=0)

        # ---- LLM analyst console ----
        a = uw.GlassPanel("LLM ANALYST CONSOLE")
        av = QVBoxLayout(a); av.setContentsMargins(14, 14, 14, 14); av.setSpacing(8)
        self.llm_box = QPlainTextEdit(); self.llm_box.setReadOnly(True)
        self.llm_box.setPlaceholderText("LLM augmentation lines will appear here after each verified distress pattern.\nRequires ZAI_API_KEY for live narrative; falls back to local tactical line.")
        av.addWidget(self.llm_box, stretch=3)
        qrow = QHBoxLayout()
        self.q_edit = QPlainTextEdit(); self.q_edit.setPlaceholderText("Ask the analyst...")
        self.q_edit.setFixedHeight(34)
        qrow.addWidget(self.q_edit, stretch=4)
        ask = QPushButton("ASK"); ask.clicked.connect(self._ask_llm)
        ask.setFixedWidth(56)
        qrow.addWidget(ask, stretch=0)
        av.addLayout(qrow)
        lay.addWidget(a, stretch=2)
        return row

    # ------------------------------------------------------------ streams --
    def _start_stream(self):
        audio = self.cfg.get("audio", {}) or {}
        if self.mode == "live":
            self.stream = LiveMicStream(device=audio.get("input_device"))
        elif self.mode == "file":
            src = audio.get("file_source") or str(DATA_DIR / "demo_rescue_scene.wav")
            self.stream = FileStream(Path(src), loop=True)
        else:
            self.stream = SimulatorStream()
        ok = self.stream.start(self.worker.callback)
        if not ok:
            self.log("[CRITICAL] audio stream failed to start")

    # ------------------------------------------------------------ events ---
    def on_frame(self, frame):
        wave = frame["wave"]
        if wave.size:
            self.wave.setData(wave)
        peak = frame["peak"]
        self.vslider.set_value(peak)
        # gauge holds the last event for 2.5s, then fades to '--'
        import time as _t
        ev = frame["event"]
        if ev is not None:
            self._last_ev_t = _t.monotonic()
        fresh = (_t.monotonic() - getattr(self, "_last_ev_t", 0.0)) < 2.5
        conf = frame["confidence"] if (ev is not None or fresh) else -1.0
        self.gauge.set_values(max(conf, 0) / 100.0, min(peak / 0.5, 1.0))
        self.gauge.set_text(("%.0f%%" % conf) if conf >= 0 else "--", "AI CONF")
        self.bars.push(max(conf, 0) / 100.0)
        tel = frame["telemetry"] or {}
        if tel:
            self._bars["FLATNESS"].set_value(tel.get("flatness", 0.0))
            self._bars["ZERO-X RATE"].set_value(tel.get("zcr", 0.0) / 0.25)
            self._bars["BAND RATIO"].set_value(
                np.log10(max(tel.get("band_ratio", 1e-3), 1e-3)) / 4 + 0.5)
        n = frame["pattern"]["taps_in_window"]
        self.stepper.set_step(min(n, 3))
        self.class_label.setText("CLASSIFICATION: %s" % frame["classification"])
        self.class_label.setStyleSheet(
            "color: %s; font-size: 10px; background: transparent;" %
            (uw.TEAL if frame["classification"] == "structural_tap" else uw.MUT))

    def on_tap(self, ev):
        self.log("TAP verified  conf=%.1f%%  centroid=%.0fHz  flat=%.3f  zcr=%.4f" %
                 (ev.confidence, ev.telemetry["centroid_hz"],
                  ev.telemetry["flatness"], ev.telemetry["zcr"]))

    def on_alert(self, alert):
        self.alert_count = getattr(self, "alert_count", 0) + 1
        briefing = gen_briefing(alert, self.brief_ctx,
                                 window_s=self.worker.processor.pattern.window_s)
        self.brief_box.setPlainText(briefing)
        self.log("!! TRIPLE-TAP DISTRESS PATTERN CONFIRMED - BRIEFING #%d DISPATCHED !!" % self.alert_count)
        self.status_badge.setText(" !!! DISTRESS BRIEFING DISPATCHED !!! ")
        self.status_badge.setStyleSheet(f"""
            color: #FFFFFF; background: #3A1220;
            border: 1px solid #FF5C7A; border-radius: 11px; padding: 4px 12px;""")
        QTimer.singleShot(4000, self._reset_badge)
        if self.worker.store:
            self.worker.store.log_alert(alert, briefing)
        # LLM augmentation (async-ish: timeboxed thread)
        self._request_llm_augmentation(briefing, alert)

    def _request_llm_augmentation(self, briefing, alert):
        import threading
        def work():
            tel = {"gmin": alert.cadence_s[0], "gmean": alert.cadence_s[1],
                   "cv": alert.cadence_s[2],
                   "avg_conf": alert.avg_conf, "n_taps": alert.n_taps}
            return self.llm.augment_briefing(briefing, tel)
        def done():
            res = work()
            # marshal back onto the GUI thread via queued signal
            self._llm_result.emit(str(res) if res else "")
        t = threading.Thread(target=done, daemon=True)
        t.start()

    def _ask_llm(self):
        q = self.q_edit.toPlainText().strip()
        if not q:
            return
        import threading
        ctx = "mode=%s; classifier=%s; alerts=%d" % (
            self.mode, "ensemble" if self.worker.processor.classifier.available else "fallback",
            self.worker.processor.pattern.total_alerts)
        def work():
            res = self.llm.console_answer(q, ctx)
            self._llm_result.emit("Q: %s\n\n%s" % (q, res))
        threading.Thread(target=work, daemon=True).start()

    def _show_llm_result(self, text: str):
        if text:
            self.llm_box.setPlainText(text)

    # ------------------------------------------------------------ helpers --
    def _reset_badge(self):
        self.status_badge.setText(" AI MODEL ARMED ")
        self.status_badge.setStyleSheet(f"""
            color: {uw.TEAL}; background: {uw.PANEL_INSET};
            border: 1px solid {uw.TEAL}; border-radius: 11px; padding: 4px 12px;""")

    def log(self, msg):
        ts = time.strftime("%H:%M:%S")
        self.logbox.appendPlainText("[%s] %s" % (ts, msg))
        sb = self.logbox.verticalScrollBar()
        sb.setValue(sb.maximum())          # autoscroll the mission log

    def closeEvent(self, ev):
        try:
            self.stream.stop()
        except Exception:
            pass
        if self.worker.store:
            self.worker.store.close()
        ev.accept()


def run(mode="sim"):
    app = QApplication(sys.argv)
    win = EchoMainWindow(mode=mode)
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "sim"
    run(mode)
