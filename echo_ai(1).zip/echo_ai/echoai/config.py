"""Global tunables for the ECHO-AI acoustic intelligence system."""
from pathlib import Path

# ---------------------------------------------------------------- paths ----
ROOT = Path(__file__).resolve().parent          # .../echo_ai package dir
DATA_DIR = ROOT.parent / "data"
MODEL_DIR = ROOT.parent / "models"
LOG_DIR = ROOT.parent / "logs"
CONFIG_PATH = ROOT.parent / "config.yaml"

# ------------------------------------------------------------- audio ops ----
SAMPLE_RATE = 44100            # Hz, project-wide operating rate
CHUNK_SECONDS = 0.15           # audio read granularity
CHUNK_SAMPLES = int(SAMPLE_RATE * CHUNK_SECONDS)
FFT_SIZE = 1024                # analysis frame for spectral features
HOP_SIZE = 512

# Pre-emphasis filter (y[n] = x[n] - a*x[n-1]) for spectral flattening.
PRE_EMPHASIS = 0.97

# ------------------------------------------------------ detection tuning ----
# Peak envelope must cross this fraction of full-scale before AI runs.
TRIGGER_RATIO = 0.045          # ~3000 counts on int16 scale
MIN_INTER_TAP_GAP_S = 0.12     # debounce, s
TAP_WINDOW_S = 3.0             # pattern window, s
PATTERN_TRIPLE = 3             # taps required for distress pattern
PATTERN_QUADRUPLE = 5          # taps for priority escalation
PATTERN_RESET_S = 4.0          # cooldown after an alert before re-arm

# Classifier gating at runtime.
AI_CONF_MIN = 52.0              # % confidence floor for tap acceptance
AI_STRONG_CONF = 75.0          # % where UI/LLM escalates emphasis

# ------------------------------------------------------------- synthetic ----
# 1.6 s clips so a 3-tap SOS burst (gaps 0.3-0.7 s) fits realistically,
# matching the runtime debounce and the pattern window.
CORPUS_SECONDS_PER_EXAMPLE = 1.6
CORPUS_TAPS_PER_POSITIVE = 3   # 3-tap bursts inside each positive clip
CORPUS_NOISE_MIN_DB = -38.0    # ambient floor for noise-only clips
CORPUS_NOISE_MAX_DB = -12.0

# ------------------------------------------------------------ persistence ----
DB_NAME = "echo_events.db"
