"""Build the feature-matrix training dataset (synthetic + ESC-50 real).

Writes data/dataset.npz  with X (n,16), y (n,), class names, and a
source tag (synthetic / esc50) per row so training reports can break
out real-vs-synthetic accuracy. ESC-50 clips are sliced into 0.4 s
windows; only windows whose peak exceeds the trigger ratio are kept
for impact classes (mirrors runtime gating), ambient rows keep all.
"""
from __future__ import annotations

import csv
from pathlib import Path

import numpy as np
import soundfile as sf

from .config import (DATA_DIR, CORPUS_SECONDS_PER_EXAMPLE, SAMPLE_RATE,
                     TRIGGER_RATIO)
from .features import extract_features
from .synth_corpus import generate_corpus

CLASSES = ("structural_tap", "ambient_noise", "surface_clatter")


def _esc50_rows(esc_dir: Path):
    man = esc_dir / "manifest.csv"
    if not man.exists():
        return []
    with open(man, newline="") as f:
        return [r for r in csv.DictReader(f)]


def build(out_path: Path | None = None, n_synthetic_per_class=400,
          esc50_cap_per_file=6, seed=7, verbose=True):
    out_path = out_path or (DATA_DIR / "dataset.npz")
    X, y, src, groups = [], [], [], []

    # ---- synthetic -----------------------------------------------------
    for clip, label, _extra in generate_corpus(n_per_class=n_synthetic_per_class, seed=seed):
        X.append(extract_features(clip)["vector"])
        y.append(label)
        src.append("synthetic")
        groups.append(f"synth_{len(groups)}")
    if verbose:
        print(f"synthetic rows: {len(X)}")

    # ---- ESC-50 --------------------------------------------------------
    esc_dir = DATA_DIR / "esc50"
    rows = _esc50_rows(esc_dir)
    n_esc = 0
    rng = np.random.default_rng(seed + 1)
    for row in rows:
        path = esc_dir / "audio" / row["filename"]
        if not path.exists():
            continue
        wav, sr = sf.read(path, dtype="float32")
        if wav.ndim > 1:
            wav = wav.mean(axis=1)
        if sr != SAMPLE_RATE:
            import resampy  # noqa
        win = int(CORPUS_SECONDS_PER_EXAMPLE * SAMPLE_RATE)
        n_win = min(esc50_cap_per_file, max(1, len(wav) // win))
        for i in range(n_win):
            seg = wav[i * win:(i + 1) * win]
            if len(seg) < win:
                seg = np.pad(seg, (0, win - len(seg)))
            peak = float(np.max(np.abs(seg)))
            # keep segments that mirror runtime gating
            if row["our_label"] == "ambient_noise" or peak > TRIGGER_RATIO * 1.4:
                X.append(extract_features(seg)["vector"])
                y.append(row["our_label"])
                src.append("esc50")
                groups.append(row["filename"])      # one group per source file
                n_esc += 1
    if verbose:
        print(f"esc50 rows: {n_esc} (from {len(rows)} files)")

    X = np.asarray(X, dtype=np.float32)
    y = np.asarray([CLASSES.index(v) for v in y])
    src = np.asarray(src)
    groups = np.asarray(groups)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(out_path, X=X, y=y, src=src, classes=np.asarray(CLASSES),
                        groups=groups)
    print(f"dataset -> {out_path}  X{X.shape} classes={CLASSES}")
    return out_path


if __name__ == "__main__":
    build()
