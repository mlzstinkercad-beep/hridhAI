"""Runtime acoustic event classification (loads the trained ensemble)."""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
from joblib import load

from .config import MODEL_DIR, AI_CONF_MIN
from .features import extract_features

MODEL_PATH = MODEL_DIR / "model.joblib"


@dataclass
class ImpactEvent:
    """One classified transient."""
    t_mono: float                       # monotonic wall-clock seconds
    confidence: float                   # P(structural_tap) * 100
    label: str
    telemetry: dict
    feature_vector: np.ndarray = field(repr=False, default=None)


class AcousticClassifier:
    def __init__(self, model_path: Path = MODEL_PATH):
        self.available = False
        self.bundle = None
        self.last_error = None
        try:
            self.bundle = load(model_path)
            self.classes = [str(c) for c in self.bundle["classes"]]
            self.available = True
        except Exception as e:                       # model missing -> DSP fallback
            self.last_error = f"model load failed: {e}"
            self.classes = ["structural_tap", "ambient_noise", "surface_clatter"]
        self.predicts_total = 0

    # ---------------------------------------------------------------- api --
    def classify_chunk(self, chunk: np.ndarray, sr: int = 44100) -> ImpactEvent:
        t_mono = time.monotonic()
        feats = extract_features(chunk, sr)
        vec = feats["vector"]
        if self.available:
            proba = self.bundle["model"].predict_proba(vec.reshape(1, -1))[0]
            idx = int(np.argmax(proba))
            conf = float(proba[self.classes.index("structural_tap")] * 100.0)
            label = self.classes[idx]
            # trust boost: ensemble proba blended with structural-prior heuristic
            tel = feats["telemetry"]
            prior = self._structural_prior(tel)
            conf = 100.0 * (0.75 * (conf / 100.0) + 0.25 * prior)
        else:
            tel = feats["telemetry"]
            conf = 100.0 * self._structural_prior(tel)
            label = "structural_tap" if conf >= AI_CONF_MIN else "ambient_noise"
        self.predicts_total += 1
        return ImpactEvent(t_mono, conf, label, tel, vec)

    def _structural_prior(self, tel: dict) -> float:
        """Legacy-style physics gate as ensemble sanity blend/fallback.

        Calibrated against the measured class statistics:
        taps: centroid ~4 kHz, flatness ~0.36, ZCR ~0.02;
        ambience: centroid 6-8 kHz, flatness 0.6+.
        """
        c = tel["centroid_hz"]; f = tel["flatness"]; z = tel["zcr"]
        s_c = _band(c, 1500.0, 6500.0, 2500.0)
        s_f = _band(f, 0.02, 0.55, 0.25)
        s_z = 1.0 - min(z / 0.10, 1.0)
        return float(s_c * (0.6 + 0.4 * s_f) * (0.7 + 0.3 * s_z))

    @property
    def info(self) -> dict:
        return {
            "available": self.available,
            "version": (self.bundle or {}).get("version", "fallback"),
            "metrics": (self.bundle or {}).get("metrics", {}),
            "last_error": self.last_error,
            "predicts_total": self.predicts_total,
        }


def _band(v, lo, hi, soft):
    if v < lo:
        return max(0.0, 1.0 - (lo - v) / soft)
    if v > hi:
        return max(0.0, 1.0 - (v - hi) / soft)
    return 1.0
