"""Train the ECHO-AI acoustic impact classifier.

Ensemble (soft voting, all CPU-light):
    RandomForest(300, depth 12)   - tabular robustness
    ExtraTrees(300, depth 12)    - variance reduction
    MLP(64->32)                  - smooth boundary, calibratable

Pipeline: features are first scaled (StandardScaler) + PCA(8) whitened.

Three honest evaluations:
    1. MIXED holdout  - stratified 80/20 over the full dataset (real+synth)
    2. CV grouped     - 5-fold grouped by esc50 SOURCE FILE so windows from
                       one recording never leak across folds
    3. TRANSFER diag  - train on synthetic only, test on esc50 only:
                       domain-gap diagnostic (not the headline)
Outputs models/model.joblib + models/metrics.json for the UI to display.
"""
from __future__ import annotations

import time
from pathlib import Path

import numpy as np
from joblib import dump
from sklearn.decomposition import PCA
from sklearn.ensemble import (ExtraTreesClassifier, RandomForestClassifier,
                              VotingClassifier)
from sklearn.metrics import (accuracy_score, classification_report,
                             confusion_matrix, f1_score)
from sklearn.model_selection import GroupKFold, StratifiedKFold, cross_val_score
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from .config import DATA_DIR, MODEL_DIR

SEED = 7


def _ensemble():
    mlp = Pipeline([
        ("scale", StandardScaler()),
        ("pca", PCA(n_components=8, random_state=SEED)),
        ("mlp", MLPClassifier(hidden_layer_sizes=(64, 32), max_iter=400,
                               random_state=SEED, early_stopping=True)),
    ])
    rf = RandomForestClassifier(n_estimators=300, max_depth=12,
                                random_state=SEED, n_jobs=-1, class_weight="balanced")
    et = ExtraTreesClassifier(n_estimators=300, max_depth=12,
                              random_state=SEED, n_jobs=-1, class_weight="balanced")
    return VotingClassifier(
        [("rf", rf), ("et", et), ("mlp", mlp)],
        voting="soft", weights=(2, 2, 1), n_jobs=-1)


def train(dataset_path: Path | None = None, out_dir: Path | None = None):
    t0 = time.time()
    dataset_path = dataset_path or (DATA_DIR / "dataset.npz")
    out_dir = out_dir or MODEL_DIR
    out_dir.mkdir(parents=True, exist_ok=True)

    d = np.load(dataset_path, allow_pickle=False)
    X, y, src, classes = d["X"], d["y"].astype(int), d["src"], d["classes"]
    groups = (d["groups"] if "groups" in d.files else _groups_from_dataset(d))
    groups = np.asarray([str(g) for g in groups])
    print(f"loaded X{X.shape} n={len(y)} sources={sorted(set(src.tolist()))}")

    # ---- 1. mixed stratified holdout (real+synthetic) ---------------------
    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=SEED)
    tr_idx, te_idx = next(skf.split(X, y))
    m1 = _ensemble().fit(X[tr_idx], y[tr_idx])
    p = m1.predict(X[te_idx])
    holdout_acc = float(accuracy_score(y[te_idx], p))
    holdout_f1 = float(f1_score(y[te_idx], p, average="macro"))
    holdout_rep = classification_report(y[te_idx], p, target_names=list(classes),
                                        output_dict=True, zero_division=0)
    print(f"[mixed holdout] acc={holdout_acc:.3f} macroF1={holdout_f1:.3f}")

    # ---- 2. grouped 5-fold CV (no window leakage across a file) -----------
    gkf = GroupKFold(n_splits=5)
    cv = cross_val_score(_ensemble(), X, y, groups=groups,
                         cv=gkf, scoring="f1_macro", n_jobs=-1)
    print(f"[grouped CV] macroF1 = {cv.mean():.3f} +/- {cv.std():.3f}")

    # ---- 3. domain-transfer diagnostic (synthetic -> real only) ----------
    mask_real = src == "esc50"
    if mask_real.sum() >= 40:
        m3 = _ensemble().fit(X[~mask_real], y[~mask_real])
        p3 = m3.predict(X[mask_real])
        transfer_acc = float(accuracy_score(y[mask_real], p3))
        transfer_f1 = float(f1_score(y[mask_real], p3, average="macro", zero_division=0))
    else:
        transfer_acc = transfer_f1 = -1.0
    print(f"[transfer synth->real diag] acc={transfer_acc:.3f} macroF1={transfer_f1:.3f}")

    # ---- final model on everything ---------------------------------------
    final = _ensemble().fit(X, y)
    cm = confusion_matrix(y, final.predict(X))
    metrics = {
        "trained_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "n_samples": int(len(y)),
        "n_features": int(X.shape[1]),
        "classes": list(classes),
        "holdout_mixed": {"n": int(len(te_idx)), "accuracy": holdout_acc,
                          "macro_f1": holdout_f1, "report": holdout_rep},
        "cv_grouped_macro_f1": {"mean": float(cv.mean()), "std": float(cv.std())},
        "transfer_synth_to_real_diag": {"accuracy": transfer_acc,
                                         "macro_f1": transfer_f1},
        "confusion_train": cm.tolist(),
        "train_seconds": round(time.time() - t0, 1),
    }
    bundle = {"model": final, "classes": list(classes),
              "metrics": metrics, "version": "2.0.0-ensemble"}
    dump(bundle, out_dir / "model.joblib")
    with open(out_dir / "metrics.json", "w") as f:
        import json
        json.dump(metrics, f, indent=2)
    print(f"model -> {out_dir/'model.joblib'}  metrics -> {out_dir/'metrics.json'}")
    return metrics


def _groups_from_dataset(d) -> np.ndarray:
    """Group ids: one per esc50 recording / unique per synthetic clip."""
    src = d["src"]
    n = len(src)
    esc_counter, syn_counter = 0, 0
    groups, cur_esc, seen_esc = [], 0, 0
    # dataset rows are appended esc50-windows-per-file contiguously;
    # use source transitions + window count heuristic (6 per file)
    g = np.zeros(n, dtype=int)
    gid = 0
    prev = None
    win_in_file = 0
    for i in range(n):
        s = str(src[i])
        if s != prev:
            gid += 1 if prev is not None else 0
            win_in_file = 0
            prev = s
        if s == "esc50":
            win_in_file += 1
            if win_in_file > 6:
                gid += 1
                win_in_file = 1
        g[i] = gid
    return g
