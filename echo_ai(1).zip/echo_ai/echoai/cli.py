"""Entry points: python -m echoai.cli <command>

Commands:
    fetch     download the ESC-50 real-audio subset (online)
    dataset   build the feature dataset (synthetic + esc50)
    train     train the ensemble, export model + metrics
    demo-wav  write the demo rescue-scene WAV for file-replay mode
    test      run the offline end-to-end test suite
    launch    start the console (mode = sim|file|live)
"""
from __future__ import annotations

import argparse
import sys


def main(argv=None):
    p = argparse.ArgumentParser(prog="echoai")
    p.add_argument("command", choices=["fetch", "dataset", "train", "demo-wav",
                                      "test", "launch"])
    p.add_argument("--mode", default="sim", help="sim | file | live")
    p.add_argument("--n", type=int, default=400, help="synthetic examples/class")
    p.add_argument("--esc-cap", type=int, default=20, help="ESC-50 files/category")
    args = p.parse_args(argv)

    if args.command == "fetch":
        from .fetch_datasets import download_esc50
        download_esc50(per_category_cap=args.esc_cap)
    elif args.command == "dataset":
        from .build_dataset import build
        build(n_synthetic_per_class=args.n)
    elif args.command == "train":
        from .train import train
        m = train()
        print("mixed holdout acc=%.3f f1=%.3f | grouped CV macroF1=%.3f+-%.3f | transfer diag acc=%.3f" %
              (m["holdout_mixed"]["accuracy"], m["holdout_mixed"]["macro_f1"],
               m["cv_grouped_macro_f1"]["mean"], m["cv_grouped_macro_f1"]["std"],
               m["transfer_synth_to_real_diag"]["accuracy"]))
    elif args.command == "demo-wav":
        from .demo_wav import write_demo
        write_demo()
    elif args.command == "test":
        from pathlib import Path
        import subprocess
        tests = Path(__file__).resolve().parent.parent / "tests" / "test_pipeline.py"
        r = subprocess.run([sys.executable, str(tests)], check=False)
        sys.exit(r.returncode)
    elif args.command == "launch":
        from .app import run
        run(mode=args.mode)


if __name__ == "__main__":
    main()
