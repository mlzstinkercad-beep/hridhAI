#!/usr/bin/env bash
# ECHO-AI one-shot pipeline: fetch online data -> build dataset -> train -> demo wav.
# Safe to re-run; each stage is resumable (files already present are skipped).
set -e
cd "$(dirname "$0")"
PY=${PYTHON:-python3}

echo "== [1/4] Fetching ESC-50 real-audio subset (online) =="
$PY -m echoai.cli fetch --esc-cap 20

echo "== [2/4] Building feature dataset (synthetic physics corpus + ESC-50) =="
$PY -m echoai.cli dataset --n 400

echo "== [3/4] Training ensemble classifier =="
$PY -m echoai.cli train

echo "== [4/4] Writing demo rescue scene WAV =="
$PY -m echoai.cli demo-wav

echo ""
echo "Done. Launch with:  $PY -m echoai.cli launch   (or: launch --mode sim|file|live)"
