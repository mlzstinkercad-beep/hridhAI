# ECHO-AI // Acoustic Intelligence Grid

Post-disaster survivor localization console: listens for structural
(rebar/concrete-transmitted) tap patterns, classifies every transient with a
**trained ML ensemble** (physics features + real-world audio), and auto-drafts
a rescue dispatch briefing the moment a triple-tap distress pattern is
verified.

Built for a MacBook Air 2013-class machine (4 GB RAM): pure CPU NumPy DSP,
no GPU, no internet needed at runtime.

---

## 1. Project structure (arrange files exactly like this)

```
echo_ai/                        <- project root (any folder name works)
├── run.sh                      <- one-shot pipeline (Linux/macOS): fetch -> dataset -> train -> demo
├── run.bat                     <- same pipeline for Windows (double-click, or run in cmd)
├── requirements.txt            <- pip install -r requirements.txt
├── config.yaml                 <- runtime config (mode, sector, LLM toggle)
├── echoai/                     <- the Python package (all logic)
│   ├── __init__.py
│   ├── config.py               <- tunables (thresholds, pattern rules)
│   ├── features.py             <- DSP engine: 16-dim vector (MFCC x10, delta,
│   │                              centroid, flatness, ZCR, band-ratio, onset)
│   ├── synth_corpus.py         <- physics-modeled training corpus generator
│   ├── fetch_datasets.py       <- downloads ESC-50 real recordings (online)
│   ├── build_dataset.py        <- assembles X(1546,16) + labels + groups
│   ├── train.py                <- RF+ET+MLP soft-voting ensemble training
│   ├── classifier.py           <- runtime classifier (+ physics fallback)
│   ├── pattern.py              <- triple-tap SOS state machine (cadence CV)
│   ├── processor.py            <- real-time gate->features->classify->pattern
│   ├── stream.py               <- live mic / file replay / sim streams
│   ├── briefing.py             <- deterministic rescue briefing generator
│   ├── llm_analyst.py          <- OPTIONAL API-key LLM layer (hybrid)
│   ├── persistence.py          <- SQLite event log (taps + briefings)
│   ├── demo_wav.py             <- writes the demo rescue scene WAV
│   ├── cli.py                  <- command dispatcher
│   ├── app.py                  <- PyQt6 mission-control GUI
│   └── ui_widgets.py           <- custom gauges/bars/stepper widgets
├── data/                       <- generated: esc50/, dataset.npz, demo wav
├── models/                     <- generated: model.joblib, metrics.json
├── logs/                       <- generated: echo_events.db
└── tests/
    └── test_pipeline.py        <- 26-check end-to-end suite (offline)
```

## 2. Run order (first time, top to bottom)

```bash
cd echo_ai
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# either the one-shot script...
bash run.sh
# ...or step by step (same thing):
python3 -m echoai.cli fetch      # 1. download 280 real ESC-50 clips (online)
python3 -m echoai.cli dataset    # 2. synthesize physics corpus + build features
python3 -m echoai.cli train      # 3. train ensemble, export model + metrics
python3 -m echoai.cli demo-wav   # 4. write demo scene WAV
python3 -m echoai.cli test       # 5. run the 26-check offline suite

# launch the console:
python3 -m echoai.cli launch              # simulator mode (no mic needed)
python3 -m echoai.cli launch --mode file  # replay demo scene
python3 -m echoai.cli launch --mode live   # real microphone
```

First `fetch` needs internet (~55 MB from GitHub raw); everything after is
fully offline. Re-running any step is safe (files present are skipped).

### Windows notes

Everything above works on Windows too — every dependency ships an official
Windows wheel, and `sounddevice` bundles the PortAudio DLL, so **live mode
needs no extra system packages** (easier than Linux). Only the shell syntax
differs; `run.bat` replaces `run.sh`:

```bat
cd echo_ai
py -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt

run.bat                    :: one-shot pipeline (fetch -> dataset -> train -> demo)
python -m echoai.cli test  :: 26-check offline suite
python -m echoai.cli launch
```

(In PowerShell the venv activates with `.venv\Scripts\Activate.ps1`; if it is
blocked, run `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` once.)

## 3. What the "AI" actually is (no hand-waved labels)

- **Feature engine** (`features.py`): per chunk, 16 features — 10 MFCCs on a
  26-band mel filterbank, delta-MFCC, log spectral centroid, log flatness
  (Wiener entropy), log zero-crossing rate, log 2–8 kHz / 0.1–1.2 kHz band
  ratio, and onset density. Shape features are computed on the **raw** signal
  (pre-emphasis only feeds the cepstrum), energy-weighted over frames so the
  transient — not the room bed — is described.
- **Training data, two sources**:
  - *Real*: 280 ESC-50 environmental recordings fetched online
    (door knocks/claps/footsteps → taps; rain/wind/engines → ambient;
    glass/cans/mouse-clicks → surface clatter).
  - *Synthetic physics*: modal strikes (ringing low modes, Q 15–40),
  low-passed reverb tails, SOS-cadenced bursts inside ambient beds —
  calibrated to the measured real-knock spectrum.
- **Model**: soft-voting ensemble = RandomForest(300) + ExtraTrees(300) +
  MLP(64→32 on PCA-8). Weights 2/2/1. Trained in <60 s on a 2013 CPU.
- **Verified numbers** (5-fold grouped CV — no recording leaks between folds):
  - mixed holdout accuracy **92.9%**, macro-F1 **0.92**
  - grouped CV macro-F1 **0.902 ± 0.032**
  - diagnostic: synthetic-only training → real-audio transfer = 0.23, which is
    exactly why the ensemble is trained on both domains.
- **Runtime confidence** = 0.75 × ensemble P(structural_tap) + 0.25 × a
  calibrated physics prior, so a single bad model can never run away with the
  console. A DSP-only fallback keeps the system alive if the model file is
  missing.
- **Pattern engine**: rising-edge onsets, 0.12 s debounce, 3 verified taps
  within 3 s window ⇒ alert; cadence CV decides "deliberate SOS" vs
  "involuntary tapping" in the briefing. 4 s cooldown re-arms.

## 4. Hybrid LLM layer (optional API key)

The local ensemble is the source of truth. If `ZAI_API_KEY` is exported, the
console additionally calls `glm-4-flash` to (a) append 3–4 tactical lines to
each briefing and (b) answer operator questions in the analyst console.
Without a key the UI shows **LLM OFFLINE** and the deterministic pipeline is
completely unaffected — briefings are always generated locally first.

```bash
export ZAI_API_KEY="..."        # optional; Windows cmd: set ZAI_API_KEY=...
python3 -m echoai.cli launch    # PowerShell: $env:ZAI_API_KEY="..." first
```

## 5. Modes

| mode | source | use |
|---|---|---|
| `sim` (default) | live-synthesized rescue soundscape | demo/judging, no hardware |
| `file` | `data/demo_rescue_scene.wav` replay | reproducible demos |
| `live` | system microphone | the real thing |

## 6. Console layout

Header (status + LLM badge) · left telemetry (AI-confidence donut, mic level
meter, flatness/ZCR/band-ratio bars, confidence history strip, model stats
card) · center (real-time waveform with trigger thresholds, ARM→TAP1→TAP2→SOS
stepper, classification readout) · right (mission event log) · bottom (rescue
dispatch briefing viewer, LLM analyst console with ASK box).

All taps + briefings persist to `logs/echo_events.db` (SQLite) for
post-mission review.

## 7. Dependencies

numpy, scipy, scikit-learn, soundfile, sounddevice (live mode only), PyQt6,
pyqtgraph, PyYAML, requests, joblib — all pip-installable on 4 GB RAM, with
official wheels for Linux, macOS and Windows (nothing to compile anywhere).
