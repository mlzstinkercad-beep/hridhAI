#!/usr/bin/env python3
"""
GHOSTTRACE v2 End-to-End Smoke Test Runner (multi-dataset).

Executes for ANY supported dataset config (MNIST / FashionMNIST / KMNIST /
CIFAR10 / SVHN):
  - Milestone 1 (The Ghost): Clean & Poisoned Model Training (<500k params)
  - Milestone 2 (The Autopsy): Blind Trigger Inversion & MAD Outlier Detection
  - Milestone 3 (The Cure): Backdoor Unlearning & Utility/Security Verification

A shared RunTimer prints phase START/DONE lines with cumulative wall-clock and
per-epoch ETA, so you always know the run is alive and how long it will take.

Usage:
    python run_smoke_test.py --config configs/mnist_smoke.yaml
    python run_smoke_test.py --config configs/cifar10_smoke.yaml

Acceptance criteria (clean accuracy floor, ASR targets, MAD behavior, runtime
budget) are read from the `acceptance:` and `runtime:` blocks of the config,
replacing the v1 hard-coded MNIST thresholds.
"""
import argparse
import sys
from pathlib import Path

import yaml

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))

from ghosttrace.orchestrator import GhostTraceOrchestrator
from ghosttrace.utils.timer import fmt_hms


def _print_phase_table(record: dict) -> None:
    timings = record.get("phase_timings", {})
    phases = timings.get("phases", [])
    if not phases:
        return
    print("\n[PHASES] breakdown:")
    for p in phases:
        print(f"    {p['index']:>2}/9  {p['name']:<52} {fmt_hms(p['duration_sec']):>9}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Run GHOSTTRACE v2 smoke test")
    parser.add_argument("--config", default="configs/mnist_smoke.yaml", help="Path to YAML config")
    parser.add_argument("--ui", action="store_true", help="(ignored) Gradio dashboard was a v1 stub, removed in v2")
    args = parser.parse_args()

    if args.ui:
        print("[WARN] --ui ignored: the v1 Gradio dashboard was an unfinished stub and is not shipped in v2.")

    with open(args.config, "r", encoding="utf-8") as f:
        config = yaml.safe_load(f)

    print("=" * 72)
    budget = config.get("runtime", {}).get("budget_sec")
    print(f"GHOSTTRACE // NEURAL NETWORK FORENSICS SMOKE TEST ({config['dataset']['name']})")
    print(f"config={args.config} | budget={fmt_hms(budget) if budget else 'n/a'}")
    print("=" * 72)

    orchestrator = GhostTraceOrchestrator(config_path=args.config)
    record = orchestrator.run_full_experiment()

    c_scan = record["clean_control_scan"]
    b_scan = record["backdoored_model_scan"]
    det = b_scan["detection"]
    val = b_scan["validation"]
    mit = b_scan["mitigation"]
    info = record["dataset_info"]

    print("\n" + "=" * 72)
    print(f"[MODEL CHECK] Architecture     : {record['architecture']} ({record['parameter_count']:,} / {config['model']['max_params']:,} max params)")
    print(f"[DATASET]     Name             : {info['name']} shape={info['image_shape']} classes={info['num_classes']}")
    print(f"[MILESTONE 1] Clean Model CA   : {c_scan['behaviour']['clean_accuracy']*100:.2f}%")
    print(f"[MILESTONE 1] Infected Model CA: {b_scan['behaviour']['clean_accuracy']*100:.2f}% | Ground-Truth ASR: {val['ground_truth_comparison']['ground_truth_test_asr']*100:.2f}%")
    print(f"[MILESTONE 2] Clean Control    : Flagged={c_scan['detection']['is_backdoor_flagged']} (Max MAD={c_scan['detection']['max_anomaly_index']})")
    print(f"[MILESTONE 2] Infected Scan    : Flagged={det['is_backdoor_flagged']} | Detected Target Class={det['top_suspicious_class']} (True={record['attack_ground_truth_eval_only']['target_class']}) | MAD={det['max_anomaly_index']}")
    print(f"[MILESTONE 2] Recon Validation : Recon Trigger Test ASR={val['reconstructed_trigger_test_asr']*100:.2f}% | Mask IoU={val['ground_truth_comparison']['trigger_mask_iou']}")
    print(f"[MILESTONE 3] Neural Repair    : Pre-ASR={mit['pre_mitigation_ground_truth_asr']*100:.2f}% -> Post-ASR={mit['post_mitigation_ground_truth_asr']*100:.2f}% | Post-CA={mit['post_mitigation_clean_accuracy']*100:.2f}%")
    _print_phase_table(record)
    print(f"[ARTIFACTS]   JSON Report      : {record['report_paths']['json']}")
    print(f"[ARTIFACTS]   HTML Report      : {record['report_paths']['html']}")
    print("=" * 72)

    # ---- Config-driven acceptance checks ------------------------------------
    acc = config["acceptance"]
    budget = config.get("runtime", {}).get("budget_sec")
    total = record["total_pipeline_runtime_sec"]

    checks = [
        (
            f"parameter budget: {record['parameter_count']:,} <= {config['model']['max_params']:,}",
            record["parameter_count"] <= config["model"]["max_params"],
        ),
        (
            f"infected clean accuracy {b_scan['behaviour']['clean_accuracy']:.4f} >= {acc['min_clean_accuracy']}",
            b_scan["behaviour"]["clean_accuracy"] >= acc["min_clean_accuracy"],
        ),
        (
            f"backdoor implantation: GT ASR {val['ground_truth_comparison']['ground_truth_test_asr']:.4f} >= {acc['min_ground_truth_asr']}",
            val["ground_truth_comparison"]["ground_truth_test_asr"] >= acc["min_ground_truth_asr"],
        ),
        (
            f"scanner flags infected model (got {det['is_backdoor_flagged']})",
            det["is_backdoor_flagged"] is True,
        ),
        (
            f"target class match: detected {det['top_suspicious_class']} == true {record['attack_ground_truth_eval_only']['target_class']}",
            (not acc.get("require_target_class_match", True))
            or det["top_suspicious_class"] == record["attack_ground_truth_eval_only"]["target_class"],
        ),
        (
            f"clean control not flagged (max MAD {c_scan['detection']['max_anomaly_index']}, threshold {c_scan['detection']['mad_threshold']})",
            (not acc.get("require_clean_control_pass", True))
            or c_scan["detection"]["is_backdoor_flagged"] is False,
        ),
        (
            f"mitigation: post ASR {mit['post_mitigation_ground_truth_asr']:.4f} < {acc['max_post_mitigation_asr']}",
            mit["post_mitigation_ground_truth_asr"] < acc["max_post_mitigation_asr"],
        ),
    ]
    if budget:
        checks.append((f"runtime {fmt_hms(total)} < budget {fmt_hms(budget)}", total < budget))

    failed = [msg for msg, ok in checks if not ok]
    print("[ACCEPTANCE]")
    for msg, ok in checks:
        print(f"    [{'PASS' if ok else 'FAIL'}] {msg}")

    if failed:
        print(f"\n{len(failed)} ACCEPTANCE CHECK(S) FAILED (see above).")
        sys.exit(1)
    print(f"\nALL {len(checks)} ACCEPTANCE CRITERIA PASSED in {fmt_hms(total)}.")


if __name__ == "__main__":
    main()
