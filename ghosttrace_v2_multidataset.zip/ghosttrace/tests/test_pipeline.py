"""GHOSTTRACE v2 test suite.

Fast unit tests (no training): shape adaptivity, parameter budgets,
trigger math, checkpoint round-trips, MAD detection, config validity.
Data-dependent tests auto-skip when a dataset is not downloaded locally.

Run:  pytest -q   (expect < 1-2 min on a laptop CPU)
"""
import sys
from pathlib import Path

import pytest
import torch
import yaml

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from ghosttrace.data.generic_data import ImageClassificationDataManager, SUPPORTED_DATASETS
from ghosttrace.data.mnist_ram import InMemoryTensorDataset
from ghosttrace.attacks.backdoor_lab import create_patch_trigger, poison_dataset
from ghosttrace.detection.anomaly_mad import compute_mad_anomaly_ranking
from ghosttrace.models.lenet_forensic import (
    ForensicCNN,
    count_parameters,
    load_forensic_checkpoint,
    save_forensic_checkpoint,
    validate_model_constraints,
)
from ghosttrace.reconstruction.trigger_inverter import ReconstructedTrigger, reconstruct_trigger_for_class

CONFIG_DIR = Path(__file__).resolve().parents[1] / "configs"
CONFIG_PATHS = sorted(CONFIG_DIR.glob("*.yaml"))


# --------------------------------------------------------------------------
# Model: shape adaptivity + parameter budgets
# --------------------------------------------------------------------------
def test_mnist_architecture_unchanged_from_v1():
    """Regression guard: (1,28,28) model must stay identical to the v1 baseline."""
    model = ForensicCNN(num_classes=10, in_channels=1, image_size=28)
    assert count_parameters(model) == 257_482
    out = model(torch.zeros(2, 1, 28, 28))
    assert out.shape == (2, 10)


def test_cifar_shape_adaptive_and_within_budget():
    model = ForensicCNN(num_classes=10, in_channels=3, image_size=32)
    params = count_parameters(model)
    assert params < 500_000, f"CIFAR shape exceeds budget: {params}"
    out = model(torch.zeros(2, 3, 32, 32))
    assert out.shape == (2, 10)


def test_odd_square_shape_adaptive():
    model = ForensicCNN(num_classes=10, in_channels=1, image_size=26)
    out = model(torch.zeros(2, 1, 26, 26))
    assert out.shape == (2, 10)


def test_validate_model_constraints_auto_infers_shape():
    model = ForensicCNN(num_classes=10, in_channels=3, image_size=32)
    meta = validate_model_constraints(model, max_params=500_000)
    assert meta["validated"] is True
    assert meta["input_shape"] == [3, 32, 32]


# --------------------------------------------------------------------------
# Triggers: arbitrary shapes, auto position, clamping
# --------------------------------------------------------------------------
def test_patch_trigger_auto_bottom_right_32x32_3ch():
    trig = create_patch_trigger(
        image_shape=(3, 32, 32), trigger_size=4, trigger_pos=None, target_class=3
    )
    assert trig.trigger_pos == (28, 28)
    x = torch.zeros((2, 3, 32, 32))
    stamped = trig.apply(x)
    assert stamped[:, :, 28:32, 28:32].mean().item() == 1.0
    assert stamped[:, :, :20, :20].mean().item() == 0.0


def test_patch_trigger_clamps_out_of_bounds_position():
    trig = create_patch_trigger(image_shape=(1, 28, 28), trigger_size=4, trigger_pos=(40, 40))
    assert trig.trigger_pos == (24, 24)  # clamped to bottom-right


def test_patch_trigger_rejects_oversize_patch():
    with pytest.raises(ValueError):
        create_patch_trigger(image_shape=(1, 28, 28), trigger_size=64)


def test_poison_dataset_generic_counts():
    images = torch.rand(100, 3, 8, 8)
    labels = torch.randint(0, 3, (100,))
    ds = InMemoryTensorDataset(images, labels)
    trig = create_patch_trigger(image_shape=(3, 8, 8), trigger_size=2, target_class=2, poison_rate=0.1)
    poisoned, n = poison_dataset(ds, trig, seed=0)
    assert n == 10
    # exactly the 10 poisoned rows changed, and all of them carry the target patch
    changed = (poisoned.images - images).abs().sum(dim=(1, 2, 3)) > 0
    assert int(changed.sum().item()) == 10
    assert int((poisoned.labels[changed] == 2).sum().item()) == 10


# --------------------------------------------------------------------------
# Checkpoints: input_shape stored + round-trip + v1 backward compatibility
# --------------------------------------------------------------------------
def test_checkpoint_roundtrip_cifar_shape(tmp_path):
    model = ForensicCNN(num_classes=10, in_channels=3, image_size=32)
    ckpt = tmp_path / "m.pt"
    save_forensic_checkpoint(model, ckpt, {"role": "test"}, input_shape=(3, 32, 32))
    loaded, meta = load_forensic_checkpoint(ckpt, max_params=500_000)
    assert meta["input_shape"] == [3, 32, 32]
    x = torch.rand(2, 3, 32, 32)
    assert torch.equal(model(x), loaded(x))


def test_checkpoint_backward_compatible_with_v1_payload(tmp_path):
    """A v1-style payload (no input_shape key) must default to MNIST arch."""
    model = ForensicCNN(num_classes=10, in_channels=1, image_size=28)
    payload = {
        "state_dict": {k: v.cpu() for k, v in model.state_dict().items()},
        "num_classes": 10,
        "metadata": {"role": "legacy"},
    }
    ckpt = tmp_path / "v1.pt"
    torch.save(payload, ckpt)
    loaded, meta = load_forensic_checkpoint(ckpt)
    assert meta["input_shape"] == [1, 28, 28]


# --------------------------------------------------------------------------
# MAD detection (unchanged core logic)
# --------------------------------------------------------------------------
def test_mad_anomaly_detection_flags_small_norm_outlier():
    candidates = {}
    for c in range(10):
        norm = 3.2 if c == 7 else 28.0 + (c * 0.5)
        candidates[c] = ReconstructedTrigger(
            target_class=c,
            mask=torch.zeros((1, 28, 28)),
            pattern=torch.zeros((1, 28, 28)),
            l1_norm=norm,
            final_asr_on_ref=0.99,
            loss_history=[1.0, 0.1],
        )
    res = compute_mad_anomaly_ranking(candidates, mad_threshold=2.0)
    assert res["is_backdoor_flagged"] is True
    assert res["top_suspicious_class"] == 7
    assert res["max_anomaly_index"] > 4.0


# --------------------------------------------------------------------------
# Trigger inversion: shape inference (v1 bug fix)
# --------------------------------------------------------------------------
class _TinyCNN(torch.nn.Module):
    def __init__(self, in_ch=1, size=8, nc=2):
        super().__init__()
        self.num_classes = nc
        flat = in_ch * size * size
        self.net = torch.nn.Sequential(torch.nn.Flatten(), torch.nn.Linear(flat, 16),
                                       torch.nn.ReLU(), torch.nn.Linear(16, nc))

    def forward(self, x):
        return self.net(x)


def test_trigger_inverter_infers_non_mnist_shape():
    torch.manual_seed(0)
    model = _TinyCNN(in_ch=1, size=8, nc=2)
    ds = InMemoryTensorDataset(torch.rand(48, 1, 8, 8), torch.randint(0, 2, (48,)))
    trig = reconstruct_trigger_for_class(
        model, ds, target_class=1, steps=3, batch_size=16, lr=0.2
    )
    assert trig.mask.shape == (1, 8, 8)
    assert trig.pattern.shape == (1, 8, 8)


# --------------------------------------------------------------------------
# Config validity (pure lint, no data download)
# --------------------------------------------------------------------------
REQUIRED_KEYS = {
    "experiment_id", "seed", "runtime", "dataset", "model", "attack",
    "scanner", "mitigation", "acceptance",
}


@pytest.mark.parametrize("cfg_path", CONFIG_PATHS, ids=lambda p: p.stem)
def test_dataset_config_valid_and_within_budget(cfg_path):
    cfg = yaml.safe_load(cfg_path.read_text(encoding="utf-8"))
    assert REQUIRED_KEYS.issubset(cfg.keys()), f"{cfg_path.name}: missing keys"
    assert cfg["runtime"]["budget_sec"] > 0
    assert cfg["runtime"]["show_progress"] is True

    d = cfg["dataset"]
    assert d["name"] in SUPPORTED_DATASETS
    c, h, w = d["image_shape"]
    assert h == w, f"{cfg_path.name}: ForensicCNN v2 requires square images"

    # trigger fits the image and position is in bounds (or auto)
    ts = cfg["attack"]["trigger_size"]
    pos = cfg["attack"].get("trigger_pos")
    if pos is not None:
        r0 = min(max(pos[0], 0), h - ts)
        c0 = min(max(pos[1], 0), w - ts)
        assert [r0, c0] == list(pos), f"{cfg_path.name}: trigger_pos out of bounds"
    assert 0 <= cfg["attack"]["target_class"] < d["num_classes"]

    # model builds for this shape and respects the budget
    model = ForensicCNN(num_classes=d["num_classes"], in_channels=c, image_size=h)
    assert count_parameters(model) <= cfg["model"]["max_params"], (
        f"{cfg_path.name}: param budget exceeded"
    )

    acc = cfg["acceptance"]
    assert {"min_clean_accuracy", "min_ground_truth_asr", "max_post_mitigation_asr"}.issubset(acc)


# --------------------------------------------------------------------------
# Data manager (skips automatically when data is not local)
# --------------------------------------------------------------------------
def _load_or_skip(name: str):
    try:
        return ImageClassificationDataManager(name, data_dir="./data", scanner_ref_count=500, seed=0).load_splits()
    except Exception as e:  # noqa: BLE001 - offline / no data dir
        pytest.skip(f"{name} not available locally and download failed: {e}")


def test_mnist_manager_shapes_and_splits():
    splits = _load_or_skip("MNIST")
    info = splits["info"]
    assert info["image_shape"] == [1, 28, 28]
    assert info["num_classes"] == 10
    assert splits["train"].images.shape[1:] == (1, 28, 28)
    assert splits["scanner_ref"].num_samples == 500
    assert float(splits["test"].images.max().item()) <= 1.0


def test_fashionmnist_manager_if_available():
    splits = _load_or_skip("FashionMNIST")
    assert splits["info"]["num_classes"] == 10


def test_cifar10_manager_if_available():
    splits = _load_or_skip("CIFAR10")
    info = splits["info"]
    assert info["image_shape"] == [3, 32, 32]
    assert info["num_classes"] == 10
