"""Multi-dataset loader.

Loads torchvision image-classification datasets fully into RAM as float32
tensors in [0, 1] with shape (N, C, H, W), then splits them into train /
scanner-reference / held-out test partitions. Works offline once the raw
files are present under `data_dir` (v1-style MNIST data is reused as-is).
"""
from typing import Any, Dict
import numpy as np
import torch
from torchvision import datasets as tvd

from .mnist_ram import InMemoryTensorDataset

SUPPORTED_DATASETS = ("MNIST", "FashionMNIST", "KMNIST", "CIFAR10", "CIFAR100", "SVHN")


class ImageClassificationDataManager:
    """Unified in-RAM loader for all supported dataset families.

    `scanner_ref_count` samples are carved out of the official train split
    (deterministic permutation seeded by `seed`) and never used for training;
    the scanner later subsamples its clean reference set from this pool.
    """

    def __init__(
        self,
        name: str = "MNIST",
        data_dir: str = "./data",
        scanner_ref_count: int = 5000,
        seed: int = 42,
    ):
        if name not in SUPPORTED_DATASETS:
            raise ValueError(
                f"Unsupported dataset '{name}'. Supported: {', '.join(SUPPORTED_DATASETS)}"
            )
        self.name = name
        self.data_dir = data_dir
        self.scanner_ref_count = int(scanner_ref_count)
        self.seed = int(seed)

    # -- raw loading ---------------------------------------------------------
    def _load_split(self, train: bool):
        if self.name in ("MNIST", "FashionMNIST", "KMNIST"):
            cls = {"MNIST": tvd.MNIST, "FashionMNIST": tvd.FashionMNIST, "KMNIST": tvd.KMNIST}[self.name]
            ds = cls(self.data_dir, train=train, download=True)
            images = ds.data.unsqueeze(1).to(torch.float32).div_(255.0)  # (N,1,H,W)
            labels = ds.targets.to(torch.long)
        elif self.name == "CIFAR10":
            ds = tvd.CIFAR10(self.data_dir, train=train, download=True)
            images = torch.from_numpy(np.asarray(ds.data)).permute(0, 3, 1, 2).to(torch.float32).div_(255.0)
            labels = torch.as_tensor(np.asarray(ds.targets), dtype=torch.long)
        elif self.name == "CIFAR100":
            ds = tvd.CIFAR100(self.data_dir, train=train, download=True)
            images = torch.from_numpy(np.asarray(ds.data)).permute(0, 3, 1, 2).to(torch.float32).div_(255.0)
            labels = torch.as_tensor(np.asarray(ds.targets), dtype=torch.long)
        elif self.name == "SVHN":
            ds = tvd.SVHN(self.data_dir, split="train" if train else "test", download=True)
            images = torch.from_numpy(np.asarray(ds.data)).to(torch.float32).div_(255.0)  # (N,3,32,32)
            # SVHN raw labels use 10 to encode digit '0' -> remap to a clean 0..9 range
            labels = torch.as_tensor(np.asarray(ds.labels), dtype=torch.long) % 10
        else:  # guarded by __init__, unreachable
            raise ValueError(self.name)
        return images, labels

    # -- splits --------------------------------------------------------------
    def load_splits(self) -> Dict[str, Any]:
        train_x, train_y = self._load_split(train=True)
        test_x, test_y = self._load_split(train=False)

        n_train = train_x.shape[0]
        n_ref = min(self.scanner_ref_count, max(1, n_train // 10))

        g = torch.Generator().manual_seed(self.seed)
        perm = torch.randperm(n_train, generator=g)
        train_idx, ref_idx = perm[: n_train - n_ref], perm[n_train - n_ref :]

        image_shape = [int(v) for v in train_x.shape[1:]]
        num_classes = int(max(train_y.max().item(), test_y.max().item())) + 1

        info = {
            "name": self.name,
            "image_shape": image_shape,
            "num_classes": num_classes,
            "train_samples": int(train_idx.numel()),
            "scanner_ref_samples": int(ref_idx.numel()),
            "test_samples": int(test_x.shape[0]),
        }

        return {
            "train": InMemoryTensorDataset(train_x[train_idx], train_y[train_idx]),
            "scanner_ref": InMemoryTensorDataset(train_x[ref_idx], train_y[ref_idx]),
            "test": InMemoryTensorDataset(test_x, test_y),
            "info": info,
        }


def build_data_manager(config: Dict[str, Any], seed: int = 42) -> ImageClassificationDataManager:
    """Factory from the `dataset:` block of an experiment config."""
    d_cfg = config["dataset"]
    return ImageClassificationDataManager(
        name=d_cfg["name"],
        data_dir=d_cfg.get("data_dir", "./data"),
        scanner_ref_count=d_cfg.get("scanner_ref_count", 5000),
        seed=seed,
    )
