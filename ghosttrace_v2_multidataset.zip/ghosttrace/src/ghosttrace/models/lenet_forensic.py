from pathlib import Path
from typing import Any, Dict, Optional, Tuple
import torch
import torch.nn as nn


class ForensicCNN(nn.Module):
    """Compact 3-block CNN, shape-adaptive for any square input.

    MNIST-family (1, 28, 28)  : 257,482 parameters (identical to v1 baseline).
    CIFAR/SVHN   (3, 32, 32)  : 319,498 parameters.
    Both stay strictly under the 500,000 parameter budget.
    """

    def __init__(self, num_classes: int = 10, in_channels: int = 1, image_size: int = 28):
        super().__init__()
        if image_size < 8:
            raise ValueError(f"image_size {image_size} too small for 3-block CNN (min 8)")
        self.num_classes = int(num_classes)
        self.in_channels = int(in_channels)
        self.image_size = int(image_size)

        flat_hw = image_size // 4  # after two 2x2 max-pools (floor division)

        self.features = nn.Sequential(
            # Block 1: C x S x S -> 32 x S/2 x S/2
            nn.Conv2d(in_channels, 32, kernel_size=3, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),
            # Block 2: 32 x S/2 x S/2 -> 64 x S/4 x S/4
            nn.Conv2d(32, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),
            # Block 3: 64 x S/4 x S/4 -> 64 x S/4 x S/4
            nn.Conv2d(64, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
        )
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(64 * flat_hw * flat_hw, 64),
            nn.ReLU(inplace=True),
            nn.Linear(64, self.num_classes),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.features(x)
        return self.classifier(x)


def count_parameters(model: nn.Module) -> int:
    """Return total number of trainable parameters."""
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


def validate_model_constraints(
    model: nn.Module,
    max_params: int = 500000,
    input_shape: Optional[Tuple[int, int, int]] = None,
    num_classes: Optional[int] = None,
    device: torch.device = torch.device("cpu"),
) -> Dict[str, Any]:
    """FR-01: Validate parameter budget, input dimensions, and output class count."""
    if input_shape is None:
        input_shape = (model.in_channels, model.image_size, model.image_size)
    if num_classes is None:
        num_classes = getattr(model, "num_classes", 10)

    param_count = count_parameters(model)
    if param_count > max_params:
        raise ValueError(f"Model exceeds parameter budget: {param_count} > {max_params}")

    model.eval()
    dummy = torch.zeros((2, *input_shape), device=device)
    with torch.no_grad():
        out = model(dummy)

    if out.shape != (2, num_classes):
        raise ValueError(f"Invalid output shape {out.shape}; expected (2, {num_classes})")

    return {
        "architecture": model.__class__.__name__,
        "parameter_count": param_count,
        "max_parameter_budget": max_params,
        "input_shape": list(input_shape),
        "num_classes": num_classes,
        "validated": True,
    }


def save_forensic_checkpoint(
    model: nn.Module,
    path: str | Path,
    metadata: Dict[str, Any] | None = None,
    input_shape: Optional[Tuple[int, int, int]] = None,
) -> None:
    """Save weights plus non-executable metadata (incl. input shape) for safe reload."""
    if input_shape is None:
        input_shape = (model.in_channels, model.image_size, model.image_size)
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "state_dict": {k: v.cpu() for k, v in model.state_dict().items()},
        "num_classes": getattr(model, "num_classes", 10),
        "input_shape": [int(v) for v in input_shape],
        "architecture": model.__class__.__name__,
        "metadata": metadata or {},
    }
    torch.save(payload, path)


def load_forensic_checkpoint(
    path: str | Path,
    device: torch.device = torch.device("cpu"),
    max_params: int = 500000,
) -> Tuple[ForensicCNN, Dict[str, Any]]:
    """
    FR-01: Safely load model weights using weights_only=True to prevent
    arbitrary code execution from untrusted pickle streams.

    Backward compatible with v1 checkpoints (no stored input shape ->
    defaults to the (1, 28, 28) MNIST architecture).
    """
    payload = torch.load(path, map_location=device, weights_only=True)
    num_classes = int(payload.get("num_classes", 10))
    input_shape = tuple(payload.get("input_shape", [1, 28, 28]))

    model = ForensicCNN(
        num_classes=num_classes,
        in_channels=int(input_shape[0]),
        image_size=int(input_shape[1]),
    ).to(device)
    model.load_state_dict(payload["state_dict"])
    model.eval()

    validation_meta = validate_model_constraints(
        model,
        max_params=max_params,
        input_shape=input_shape,
        num_classes=num_classes,
        device=device,
    )
    validation_meta["checkpoint_metadata"] = payload.get("metadata", {})
    return model, validation_meta
