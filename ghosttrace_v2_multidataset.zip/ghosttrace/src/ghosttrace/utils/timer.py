"""GHOSTTRACE v2 run timer.

Makes long forensic phases visibly "alive" on the console:
  - phase START / DONE lines with cumulative wall-clock and budget usage
  - per-unit progress lines (training epochs, inversion classes) with ETA
All output is flushed immediately so it works under `python -u`, nohup,
and pipe redirection.
"""
import sys
import time
from contextlib import contextmanager
from typing import Any, Dict, List, Optional


def fmt_hms(seconds: float) -> str:
    """Format seconds as HH:MM:SS (hours omitted under one hour)."""
    s = int(round(max(seconds, 0)))
    h, rem = divmod(s, 3600)
    m, sec = divmod(rem, 60)
    if h:
        return f"{h:02d}:{m:02d}:{sec:02d}"
    return f"{m:02d}:{sec:02d}"


class RunTimer:
    """Wall-clock progress tracker shared by every pipeline phase."""

    def __init__(
        self,
        budget_sec: Optional[float] = None,
        enabled: bool = True,
        stream: Any = None,
    ):
        self.budget_sec = float(budget_sec) if budget_sec else None
        self.enabled = bool(enabled)
        self.stream = stream or sys.stdout
        self.phases: List[Dict[str, Any]] = []
        self._t0 = time.perf_counter()
        self._phase_start: Optional[float] = None
        self._phase_name: str = ""

    # -- lifecycle -----------------------------------------------------------
    def reset(self) -> None:
        self._t0 = time.perf_counter()
        self.phases = []
        self._phase_start = None
        self._phase_name = ""

    @property
    def elapsed(self) -> float:
        return time.perf_counter() - self._t0

    @property
    def elapsed_str(self) -> str:
        return fmt_hms(self.elapsed)

    def _budget_note(self) -> str:
        if not self.budget_sec:
            return ""
        pct = 100.0 * self.elapsed / self.budget_sec
        return f" | budget {fmt_hms(self.budget_sec)}: {pct:.0f}% used"

    def stamp(self, msg: str) -> None:
        if self.enabled:
            print(f"[GHOSTTRACE {self.elapsed_str}] {msg}", file=self.stream, flush=True)

    # -- phases --------------------------------------------------------------
    @contextmanager
    def phase(self, index: int, total: int, name: str):
        """Context manager logging START / DONE for one pipeline phase."""
        self.stamp(f"START [{index}/{total}] {name}")
        self._phase_start = time.perf_counter()
        self._phase_name = name
        try:
            yield self
        finally:
            duration = time.perf_counter() - (self._phase_start or self._t0)
            self.phases.append(
                {"index": index, "name": name, "duration_sec": round(duration, 3)}
            )
            self.stamp(
                f"DONE  [{index}/{total}] {name} in {fmt_hms(duration)}"
                f" | total {self.elapsed_str}{self._budget_note()}"
            )
            if self.budget_sec and self.elapsed > self.budget_sec:
                self.stamp(
                    f"WARNING: runtime budget exceeded"
                    f" ({self.elapsed_str} > {fmt_hms(self.budget_sec)})"
                )
            self._phase_start = None
            self._phase_name = ""

    def progress(self, label: str, step: int, total: int, note: str = "") -> None:
        """Report completion of unit `step` of `total` within the open phase.

        ETA is extrapolated from average unit time, so it self-corrects each call.
        """
        if not self.enabled:
            return
        unit_elapsed = (
            time.perf_counter() - self._phase_start
            if self._phase_start is not None
            else self.elapsed
        )
        eta = (unit_elapsed / max(step, 1)) * max(total - step, 0)
        suffix = f" ({note})" if note else ""
        print(
            f"  -> {label} {step}/{total}{suffix}"
            f" | elapsed {fmt_hms(unit_elapsed)} | eta {fmt_hms(eta)}"
            f" | total {self.elapsed_str}",
            file=self.stream,
            flush=True,
        )

    # -- reporting -----------------------------------------------------------
    def snapshot(self) -> Dict[str, Any]:
        return {
            "total_runtime_sec": round(self.elapsed, 3),
            "budget_sec": self.budget_sec,
            "budget_utilization": (
                round(self.elapsed / self.budget_sec, 4) if self.budget_sec else None
            ),
            "phases": list(self.phases),
        }
