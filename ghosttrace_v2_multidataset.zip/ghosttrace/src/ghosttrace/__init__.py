"""GHOSTTRACE v2: Neural Network Forensics & Backdoor Detection System.

v2 adds multi-dataset support (MNIST, FashionMNIST, KMNIST, CIFAR-10, SVHN),
a visible run timer with per-phase ETA reporting, and shape-adaptive model
construction. The parameter budget stays under 500k for every supported shape.
"""

__version__ = "2.0.0"
