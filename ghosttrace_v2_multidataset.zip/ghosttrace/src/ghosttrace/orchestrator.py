from pathlib import Path
from typing import Any, Dict
import torch
import yaml

from .analysis.behaviour import evaluate_clean_behaviour
from .attacks.backdoor_lab import create_patch_trigger, poison_dataset, train_model
from .data.generic_data import build_data_manager
from .detection.anomaly_mad import compute_mad_anomaly_ranking
from .mitigation.repair_engine import mitigate_backdoor_unlearning
from .models.lenet_forensic import (
    ForensicCNN,
    load_forensic_checkpoint,
    save_forensic_checkpoint,
)
from .reconstruction.trigger_inverter import scan_all_classes
from .reporting.forensic_reporter import export_forensic_reports
from .utils.reproducibility import (
    compute_config_hash,
    get_runtime_metadata,
    set_deterministic_seed,
)
from .utils.timer import RunTimer
from .validation.validator import validate_reconstructed_trigger

TOTAL_PHASES = 9


class GhostTraceOrchestrator:
    """
    End-to-end orchestrator implementing Milestones 1 (The Ghost),
    2 (The Autopsy), and 3 (The Cure) with strict ground-truth isolation.

    v2: dataset-agnostic (config-driven), shape-adaptive model, and a shared
    RunTimer that prints START/DONE lines and per-epoch ETA so every phase
    is visibly alive on the console.
    """

    def __init__(self, config_path: str | Path = "configs/mnist_smoke.yaml"):
        with open(config_path, "r", encoding="utf-8") as f:
            self.config: Dict[str, Any] = yaml.safe_load(f)
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        runtime_cfg = self.config.get("runtime", {})
        self.timer = RunTimer(
            budget_sec=runtime_cfg.get("budget_sec"),
            enabled=runtime_cfg.get("show_progress", True),
        )
        self.artifacts_dir = Path("./artifacts")
        self.artifacts_dir.mkdir(parents=True, exist_ok=True)
        self.latest_state: Dict[str, Any] = {}

    # ------------------------------------------------------------------
    def _build_model(self, num_classes: int, image_shape) -> ForensicCNN:
        c, h, w = (int(v) for v in image_shape)
        if h != w:
            raise ValueError(f"ForensicCNN v2 requires square images, got {image_shape}")
        return ForensicCNN(num_classes=num_classes, in_channels=c, image_size=h)

    def run_full_experiment(self) -> Dict[str, Any]:
        timer = self.timer
        timer.reset()
        seed = int(self.config.get("seed", 42))
        set_deterministic_seed(seed)

        m_cfg = self.config["model"]
        a_cfg = self.config["attack"]
        s_cfg = self.config["scanner"]
        mit_cfg = self.config["mitigation"]

        # -- Phase 1: Load In-RAM Dataset Splits ---------------------------
        with timer.phase(1, TOTAL_PHASES, "load dataset splits into RAM"):
            dm = build_data_manager(self.config, seed=seed)
            splits = dm.load_splits()
            info = splits["info"]

            if self.config["dataset"].get("name") != info["name"]:
                raise ValueError("Config dataset name mismatch.")
            cfg_shape = list(self.config["dataset"].get("image_shape") or [])
            if cfg_shape and cfg_shape != info["image_shape"]:
                raise ValueError(
                    f"config image_shape {cfg_shape} != detected {info['image_shape']}"
                )
            if int(self.config["dataset"]["num_classes"]) != info["num_classes"]:
                raise ValueError(
                    f"config num_classes {self.config['dataset']['num_classes']}"
                    f" != detected {info['num_classes']}"
                )

            image_shape = tuple(info["image_shape"])
            num_classes = info["num_classes"]
            scanner_ref = splits["scanner_ref"].subset(
                s_cfg["clean_reference_samples"], seed=seed
            )
            timer.stamp(
                f"dataset={info['name']} shape={image_shape} classes={num_classes}"
                f" | train={info['train_samples']} ref={info['scanner_ref_samples']}"
                f" test={info['test_samples']} | device={self.device}"
            )

        # -- Milestone 1 (The Ghost) ---------------------------------------
        gt_trigger = create_patch_trigger(
            image_shape=image_shape,
            trigger_size=a_cfg["trigger_size"],
            trigger_pos=a_cfg.get("trigger_pos"),
            trigger_value=a_cfg["trigger_value"],
            target_class=a_cfg["target_class"],
            poison_rate=a_cfg["poison_rate"],
        )

        with timer.phase(2, TOTAL_PHASES, "train clean control model (The Ghost)"):
            clean_model = self._build_model(num_classes, image_shape)
            clean_train_stats = train_model(
                clean_model,
                splits["train"],
                epochs=m_cfg["epochs"],
                batch_size=m_cfg["batch_size"],
                lr=m_cfg["learning_rate"],
                device=self.device,
                timer=timer,
                label="clean model epoch",
            )
            clean_ckpt = self.artifacts_dir / "clean_model.pt"
            save_forensic_checkpoint(
                clean_model, clean_ckpt, {"role": "clean_control"}, input_shape=image_shape
            )

        with timer.phase(3, TOTAL_PHASES, "poison + train backdoored model"):
            poisoned_train, n_poisoned = poison_dataset(splits["train"], gt_trigger, seed=seed)
            timer.stamp(
                f"poisoned {n_poisoned}/{info['train_samples']} samples"
                f" (rate={a_cfg['poison_rate']}) -> target class {a_cfg['target_class']}"
            )
            infected_model = self._build_model(num_classes, image_shape)
            infected_train_stats = train_model(
                infected_model,
                poisoned_train,
                epochs=m_cfg["epochs"],
                batch_size=m_cfg["batch_size"],
                lr=m_cfg["learning_rate"],
                device=self.device,
                timer=timer,
                label="infected model epoch",
            )
            infected_ckpt = self.artifacts_dir / "backdoored_model.pt"
            save_forensic_checkpoint(
                infected_model, infected_ckpt, {"role": "backdoored_target"}, input_shape=image_shape
            )

        # -- Milestone 2 (The Autopsy): Blind Forensic Scan on Both Models --
        # Notice: gt_trigger is NOT passed to scan_all_classes or compute_mad_anomaly_ranking
        with timer.phase(4, TOTAL_PHASES, "blind forensic scan - clean control"):
            loaded_clean, clean_meta = load_forensic_checkpoint(
                clean_ckpt, device=self.device, max_params=m_cfg["max_params"]
            )
            clean_behaviour = evaluate_clean_behaviour(loaded_clean, splits["test"], device=self.device)
            clean_candidates, clean_scan_sec = scan_all_classes(
                loaded_clean,
                scanner_ref,
                steps=s_cfg["inversion_steps"],
                batch_size=s_cfg["inversion_batch_size"],
                lr=s_cfg["inversion_lr"],
                init_lambda=s_cfg["init_lambda"],
                device=self.device,
                timer=timer,
            )
            clean_detection = compute_mad_anomaly_ranking(clean_candidates, s_cfg["mad_threshold"])
            timer.stamp(
                f"clean control verdict: flagged={clean_detection['is_backdoor_flagged']}"
                f" (max MAD={clean_detection['max_anomaly_index']},"
                f" threshold={s_cfg['mad_threshold']})"
            )

        with timer.phase(5, TOTAL_PHASES, "blind forensic scan - backdoored model"):
            loaded_infected, infected_meta = load_forensic_checkpoint(
                infected_ckpt, device=self.device, max_params=m_cfg["max_params"]
            )
            infected_behaviour = evaluate_clean_behaviour(
                loaded_infected, splits["test"], device=self.device
            )
            infected_candidates, infected_scan_sec = scan_all_classes(
                loaded_infected,
                scanner_ref,
                steps=s_cfg["inversion_steps"],
                batch_size=s_cfg["inversion_batch_size"],
                lr=s_cfg["inversion_lr"],
                init_lambda=s_cfg["init_lambda"],
                device=self.device,
                timer=timer,
            )
            infected_detection = compute_mad_anomaly_ranking(
                infected_candidates, s_cfg["mad_threshold"]
            )
            flagged_class = infected_detection["top_suspicious_class"]
            flagged_trigger = infected_candidates[flagged_class]
            timer.stamp(
                f"infected verdict: flagged={infected_detection['is_backdoor_flagged']}"
                f" top_class={flagged_class} (max MAD={infected_detection['max_anomaly_index']})"
            )

        # -- Held-out Validation Harness (Ground-Truth used only for scoring) --
        with timer.phase(6, TOTAL_PHASES, "validate reconstructed trigger (held-out)"):
            validation_metrics = validate_reconstructed_trigger(
                loaded_infected,
                splits["test"],
                recon_trigger=flagged_trigger,
                ground_truth=gt_trigger,
                device=self.device,
            )
            gt_cmp = validation_metrics.get("ground_truth_comparison", {})
            timer.stamp(
                f"recon ASR={validation_metrics['reconstructed_trigger_test_asr']*100:.2f}%"
                f" | GT ASR={gt_cmp.get('ground_truth_test_asr', 0)*100:.2f}%"
                f" | mask IoU={gt_cmp.get('trigger_mask_iou', 'n/a')}"
            )

        # -- Milestone 3 (The Cure) -----------------------------------------
        with timer.phase(7, TOTAL_PHASES, "mitigation: reconstructed-trigger unlearning (The Cure)"):
            repaired_model, mitigation_metrics = mitigate_backdoor_unlearning(
                loaded_infected,
                clean_ref_dataset=scanner_ref,
                test_dataset=splits["test"],
                recon_trigger=flagged_trigger,
                ground_truth_trigger=gt_trigger,
                epochs=mit_cfg["epochs"],
                batch_size=mit_cfg["batch_size"],
                lr=mit_cfg["learning_rate"],
                unlearn_ratio=mit_cfg["unlearn_ratio"],
                device=self.device,
                timer=timer,
            )
            timer.stamp(
                f"repair: GT ASR {mitigation_metrics['pre_mitigation_ground_truth_asr']*100:.2f}%"
                f" -> {mitigation_metrics['post_mitigation_ground_truth_asr']*100:.2f}%"
                f" | CA {mitigation_metrics['post_mitigation_clean_accuracy']*100:.2f}%"
            )

        with timer.phase(8, TOTAL_PHASES, "save repaired checkpoint + assemble record"):
            repaired_ckpt = self.artifacts_dir / "repaired_model.pt"
            save_forensic_checkpoint(
                repaired_model, repaired_ckpt, {"role": "repaired_model"}, input_shape=image_shape
            )

        total_runtime = timer.elapsed

        record: Dict[str, Any] = {
            "experiment_id": self.config["experiment_id"],
            "seed": seed,
            "config_hash": compute_config_hash(self.config),
            "total_pipeline_runtime_sec": round(total_runtime, 3),
            "phase_timings": timer.snapshot(),
            "dataset_info": info,
            "architecture": infected_meta["architecture"],
            "parameter_count": infected_meta["parameter_count"],
            "attack_ground_truth_eval_only": {
                "family": a_cfg["family"],
                "poison_rate": a_cfg["poison_rate"],
                "poisoned_samples": n_poisoned,
                "target_class": a_cfg["target_class"],
                "trigger_size": a_cfg["trigger_size"],
                "trigger_pos": list(gt_trigger.trigger_pos),
            },
            "clean_control_scan": {
                "model_validation": clean_meta,
                "train_stats": clean_train_stats,
                "scan_time_sec": clean_scan_sec,
                "behaviour": clean_behaviour,
                "detection": clean_detection,
            },
            "backdoored_model_scan": {
                "model_validation": infected_meta,
                "train_stats": infected_train_stats,
                "scan_time_sec": infected_scan_sec,
                "behaviour": infected_behaviour,
                "detection": infected_detection,
                "validation": validation_metrics,
                "mitigation": mitigation_metrics,
            },
            "software": get_runtime_metadata(),
            "limitations": (
                "Prototype evaluated on localized static patch triggers in image classification. "
                "Does not certify universal absence of dynamic, frequency-domain, or multi-trigger backdoors."
            ),
        }

        with timer.phase(9, TOTAL_PHASES, "export JSON + HTML forensic reports"):
            json_path, html_path = export_forensic_reports(record, self.artifacts_dir)
            record["report_paths"] = {"json": str(json_path), "html": str(html_path)}

        timer.stamp(f"reports written: {json_path}")

        # Cache tensors for downstream visualization
        self.latest_state = {
            "record": record,
            "test_split": splits["test"],
            "gt_trigger": gt_trigger,
            "infected_candidates": infected_candidates,
            "clean_candidates": clean_candidates,
            "infected_model": loaded_infected,
            "repaired_model": repaired_model,
        }
        return record
