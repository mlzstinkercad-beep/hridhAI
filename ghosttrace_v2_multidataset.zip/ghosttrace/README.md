# GHOSTTRACE v2 — Neural Network Backdoor Forensics (multi-dataset)

Detect, reconstruct, and repair BadNets-style backdoors in small image
classifiers. v1 was MNIST-only; **v2 generalizes the full pipeline to any
supported dataset via config**, keeps the model under the 500k parameter
budget, and prints a live wall-clock timer with ETA for every phase.

## Milestones

1. **The Ghost** — train a clean control model and a backdoored twin
   (fixed patch trigger, poisoned subset relabeled to the target class).
2. **The Autopsy** — blind per-class trigger inversion (tanh-space mask +
   pattern optimization) and MAD outlier ranking over reconstructed trigger
   L1 norms. Ground truth is never touched during detection.
3. **The Cure** — unlearning: clean reference samples are stamped with the
   *reconstructed* trigger while keeping their true labels, dropping the
   attack success rate without retraining from scratch.

## Supported datasets

| Dataset | Shape | Classes | Config | Model params | Est. laptop CPU runtime* |
|---|---|---|---|---|---|
| MNIST | 1×28×28 | 10 | `configs/mnist_smoke.yaml` | 257,482 | ~8 min (measured v1) |
| FashionMNIST | 1×28×28 | 10 | `configs/fashionmnist_smoke.yaml` | 257,482 | ~8 min (est.) |
| KMNIST | 1×28×28 | 10 | `configs/kmnist_smoke.yaml` | 257,482 | ~8 min (est.) |
| CIFAR10 | 3×32×32 | 10 | `configs/cifar10_smoke.yaml` | 319,498 | ~15-25 min (est.) |
| SVHN | 3×32×32 | 10 | `configs/svhn_smoke.yaml` | 319,498 | ~25-40 min (est., heavy) |

\* MNIST figure measured on the v1 baseline hardware; others are estimates —
the timer prints live ETAs so you can extrapolate after the first epoch.
CIFAR10/SVHN need ~1.2 GB free RAM (splits held in float32) and download
their raw data (~170-240 MB) into `./data` on first run. If you still have
the v1 `data/` folder (MNIST), copy it here to run MNIST fully offline.

## Quickstart

```bash
pip install -r requirements.txt          # torch, torchvision, numpy, pyyaml, pytest
python run_smoke_test.py --config configs/mnist_smoke.yaml
python run_smoke_test.py --config configs/cifar10_smoke.yaml
```

Optional `--ui` is accepted but ignored: the v1 Gradio dashboard was an
unfinished stub and is not shipped in v2.

## What the timer looks like while running

```
[GHOSTTRACE 00:00] START [3/9] poison + train backdoored model
  -> infected model epoch 1/3 (loss=0.4812) | elapsed 00:47 | eta 01:34 | total 02:31
  -> infected model epoch 2/3 (loss=0.1304) | elapsed 01:33 | eta 00:46 | total 03:17
[GHOSTTRACE 04:04] DONE  [3/9] poison + train backdoored model in 01:33 | total 04:04 | budget 15:00: 27% used
```

Every phase reports START/DONE with cumulative wall-clock, budget usage,
and (inside long phases) per-unit ETA that self-corrects each epoch/class.
The final JSON/HTML report includes a full phase runtime breakdown.

## Acceptance checks (per-dataset, config-driven)

`run_smoke_test.py` no longer hard-codes MNIST thresholds. Each config has an
`acceptance:` block (clean-accuracy floor, minimum ground-truth ASR, maximum
post-repair ASR, target-class match, clean-control must stay unflagged) plus
a `runtime.budget_sec` ceiling. Output ends with a PASS/FAIL table; non-zero
exit code on failure.

## Tuning guidance for new datasets

- **MAD threshold**: after a run, compare
  `clean_control_scan.detection.max_anomaly_index` vs the infected model's
  `max_anomaly_index`. Set `scanner.mad_threshold` between the two margins.
  v1 MNIST margins were 0.93 (clean) vs 1.53 (infected) at threshold 1.3.
  For harder tasks (CIFAR/SVHN) start at 1.5 and retune.
- **Trigger position**: `attack.trigger_pos: null` auto-pins the patch to the
  bottom-right corner (default `(H-size, W-size)`); positions are clamped to
  stay in bounds.
- **Runtime**: lower `model.epochs` (CIFAR: 3 → 2) to halve training; then
  relax `acceptance.min_clean_accuracy` accordingly.

## Adding a new dataset

1. Add its torchvision class to `SUPPORTED_DATASETS` /
   `ImageClassificationDataManager._load_split`
   (`src/ghosttrace/data/generic_data.py`) if it is not one of the six
   already supported (MNIST, FashionMNIST, KMNIST, CIFAR10, CIFAR100, SVHN).
2. Copy any config YAML, set `dataset.name`, `image_shape`, `num_classes`,
   `attack.trigger_pos`, and sane `acceptance` floors.
3. The orchestrator cross-checks config vs detected shape/classes at load
   time and refuses to start on mismatch. CIFAR100 works but is research-only
   (100 classes → 100 inversion scans per model; expect a very long run).

## Tests

```bash
pytest -q        # no training involved; < 2 min
```

Covers shape adaptivity, exact v1 parameter regression (257,482 for MNIST),
trigger math on 32×32×3, checkpoint round-trips (incl. v1 payload backward
compatibility), MAD scoring, inverter shape inference, and config linting.
Data-dependent tests auto-skip when a dataset is missing locally.

## v1 review findings (fixed in v2)

See `REVIEW.md`. Headlines: 4 sites hard-coded MNIST (incl. a silent
`(1,28,28)` mask-shape bug in the inverter), checkpoints missing
`input_shape`, MNIST-tuned acceptance thresholds, unfinished dashboard stub,
leftover Windows scaffold script, no live progress output.

## Scope & limitations

Prototype threat model: single localized static patch trigger (BadNets).
Does not certify absence of dynamic, blended, frequency-domain, or
multi-trigger backdoors. Clean-control MAD margins should be re-tuned per
dataset (see tuning guidance).
