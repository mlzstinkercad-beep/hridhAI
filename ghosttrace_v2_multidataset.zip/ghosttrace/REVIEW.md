# GHOSTTRACE v1 Code Review → v2 Fixes

Review performed on the v1 zip (`ghosttrace.zip`, MNIST smoke baseline with
artifacts). Baseline evidence: `artifacts/ghosttrace-mnist-smoke-v1_report.json`
— total runtime 482.3s, ForensicCNN 257,482 params, clean control max MAD 0.93
(unflagged), infected max MAD 1.53 flagged class 7, GT ASR 99.99%, post-repair
ASR 3.51% @ CA 94.46%. The v1 pipeline logic is sound; all issues below are
about generalization, packaging, and observability.

## Findings and resolutions

| # | Severity | v1 finding | v2 resolution |
|---|----------|------------|---------------|
| 1 | High | MNIST hard-coded in 4 places: `MNISTDataManager` (fixed 55000/5000 split), `ForensicCNN` flatten (`64*7*7`), `reconstruct_trigger_for_class` (`img_shape = (1, 28, 28)` line 43 — would silently corrupt mask shapes on other datasets), `trigger_pos` assumptions | New `data/generic_data.py` registry (MNIST/FashionMNIST/KMNIST/CIFAR10/CIFAR100/SVHN) with config-driven ref-pool split; `ForensicCNN(num_classes, in_channels, image_size)` computes flatten dim from shape; inverter infers shape from reference data; trigger position optional (`null` → bottom-right) and clamped |
| 2 | High | Checkpoints did not store `input_shape`; `load_forensic_checkpoint` assumed 28×28 | Checkpoint payload now stores `input_shape` + `architecture`; loader rebuilds the right model. **v1 checkpoints remain loadable** (default 1×28×28) |
| 3 | Medium | `run_smoke_test.py` acceptance asserts tuned to MNIST (`CA ≥ 0.96`, runtime `< 600s`) — CIFAR with 3 epochs can never pass | Per-dataset `acceptance:` block in every config; runner prints a PASS/FAIL table and exits non-zero on failure; `runtime.budget_sec` replaces the fixed 600s ceiling |
| 4 | Medium | No progress output during multi-minute phases; only end-of-run timings | `utils/timer.py` `RunTimer`: 9-phase START/DONE lines with cumulative wall-clock + budget %, per-epoch/per-class progress with self-correcting ETA, all `flush=True` |
| 5 | Low | `src/ghosttrace/app/dashboard.py` is an unfinished stub: `create_dashboard` builds tensors but never constructs the Gradio UI and returns `None` → `--ui` would crash | Stub and dead `app.py` scaffold script removed; `--ui` flag still accepted but prints a clear notice |
| 6 | Low | Clean-control detection margin thin (0.93 vs 1.53 at threshold 1.3) — generalization risk | `mad_threshold` per-dataset config; README documents margin-based retuning procedure |
| 7 | Low | `app.py` was a leftover Windows-only scaffold writing to `C:\Users\Admin\Desktop\GHOSTTRACE` | Removed |
| 8 | Low | `requirements.txt` pulled pandas/plotly/gradio (only used by the dead stub) | Slimmed to torch/torchvision/numpy/pyyaml/pytest |

## Kept intentionally unchanged

- ForensicCNN capacity (still < 500k params; exact 257,482 regression-tested
  for MNIST, 319,498 for 3×32×32).
- In-RAM float32 tensor store (`mnist_ram.InMemoryTensorDataset`) — it is the
  speed trick; v1 measured 482s total.
- MAD scoring math, tanh-space inversion, adaptive lambda controller,
  unlearning strategy — core science untouched.
- Ground-truth isolation: `gt_trigger` never enters detection, only the
  scoring harness and repair evaluation.

## Suggested next experiments on your laptop

1. `python run_smoke_test.py` (MNIST) — verify identical behavior + timer.
2. `python run_smoke_test.py --config configs/fashionmnist_smoke.yaml` —
   same shape, different data distribution.
3. `python run_smoke_test.py --config configs/cifar10_smoke.yaml` —
   3-channel 32×32 generalization probe; watch clean-control MAD margins and
   retune `mad_threshold` if the clean control gets flagged.
4. `pytest -q` — 20 fast tests, no training.
